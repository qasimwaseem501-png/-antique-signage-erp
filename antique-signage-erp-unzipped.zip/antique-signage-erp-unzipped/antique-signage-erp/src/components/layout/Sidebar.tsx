"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  LayoutDashboard,
  Users,
  LogOut,
  Building2,
  FileText,
  FolderKanban,
  Factory,
  Truck,
  Wallet,
  Percent,
  UserCog,
  Settings,
  CreditCard,
  Boxes,
  ClipboardList,
  BarChart3
} from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { isAdmin } from "@/lib/auth";
import type { Profile, UserRole } from "@/types/database";
import { ThemeToggle } from "./ThemeToggle";

interface NavItem {
  href: string;
  label: string;
  icon: typeof LayoutDashboard;
  roles?: UserRole[]; // if omitted, visible to all roles
}

const NAV_ITEMS: NavItem[] = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/leads", label: "Leads", icon: Users, roles: ["owner", "admin", "sales"] },
  { href: "/quotations", label: "Quotations", icon: FileText, roles: ["owner", "admin", "sales", "accounts"] },
  { href: "/projects", label: "Projects", icon: FolderKanban },
  { href: "/production", label: "Production", icon: Factory, roles: ["owner", "admin", "designer", "production", "packing"] },
  { href: "/tasks", label: "Tasks", icon: ClipboardList },
  { href: "/payments", label: "Payments", icon: CreditCard, roles: ["owner", "admin", "accounts"] },
  { href: "/shipping", label: "Shipping", icon: Truck, roles: ["owner", "admin", "packing", "accounts"] },
  { href: "/expenses", label: "Expenses", icon: Wallet, roles: ["owner", "admin", "accounts", "production", "packing"] },
  { href: "/commissions", label: "Commissions", icon: Percent, roles: ["owner", "admin", "sales", "accounts"] },
  { href: "/inventory", label: "Inventory", icon: Boxes, roles: ["owner", "admin", "production", "packing"] },
  { href: "/reports", label: "Reports", icon: BarChart3, roles: ["owner", "admin", "accounts"] },
  { href: "/team", label: "Team", icon: UserCog, roles: ["owner", "admin"] },
  { href: "/settings", label: "Settings", icon: Settings, roles: ["owner", "admin"] }
];

export function Sidebar({ profile }: { profile: Profile }) {
  const pathname = usePathname();
  const router = useRouter();
  const supabase = createClient();
  const admin = isAdmin(profile);

  const visibleItems = NAV_ITEMS.filter(
    (item) => !item.roles || admin || item.roles.includes(profile.role)
  );

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push("/login");
    router.refresh();
  }

  return (
    <aside className="flex h-screen w-64 flex-col border-r border-slate-200 bg-brand-black dark:border-slate-800">
      <div className="flex items-center gap-2 px-5 py-6">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-blue-600">
          <Building2 className="h-5 w-5 text-white" />
        </div>
        <div>
          <p className="text-sm font-semibold text-white leading-tight">Antique Signage</p>
          <p className="text-xs text-slate-400 leading-tight">&amp; Advertising</p>
        </div>
      </div>

      <nav className="flex-1 space-y-1 overflow-y-auto px-3">
        {visibleItems.map(({ href, label, icon: Icon }) => {
          const active = pathname.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                active
                  ? "bg-brand-blue-600 text-white"
                  : "text-slate-300 hover:bg-white/5 hover:text-white"
              }`}
            >
              <Icon className="h-4 w-4" />
              {label}
            </Link>
          );
        })}
      </nav>

      <div className="border-t border-white/10 px-3 py-4">
        <div className="mb-3 px-2">
          <p className="text-sm font-medium text-white truncate">{profile.full_name}</p>
          <p className="text-xs capitalize text-slate-400">{profile.role.replace("_", " ")}</p>
        </div>
        <ThemeToggle />
        <button
          onClick={handleLogout}
          className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-slate-300 transition-colors hover:bg-white/5 hover:text-white"
        >
          <LogOut className="h-4 w-4" />
          Sign out
        </button>
      </div>
    </aside>
  );
}
