"use client";

import { useState, useTransition } from "react";
import { updateIntegration } from "@/app/(app)/settings/actions";
import type { IntegrationConfig } from "@/types/database";

export function IntegrationRow({ integration }: { integration: IntegrationConfig }) {
  const [apiKey, setApiKey] = useState(integration.api_key ?? "");
  const [enabled, setEnabled] = useState(integration.is_enabled);
  const [isPending, startTransition] = useTransition();

  function handleSave() {
    startTransition(() => updateIntegration(integration.service_name, apiKey, enabled));
  }

  return (
    <div className="flex flex-wrap items-center gap-3 rounded-lg border border-slate-100 p-3">
      <span className="w-40 shrink-0 text-sm font-medium text-slate-900">{integration.display_name}</span>
      <input
        type="password"
        className="input max-w-xs"
        placeholder="API key (not yet connected)"
        value={apiKey}
        onChange={(e) => setApiKey(e.target.value)}
      />
      <label className="flex items-center gap-2 text-sm text-slate-600">
        <input type="checkbox" checked={enabled} onChange={(e) => setEnabled(e.target.checked)} />
        Enabled
      </label>
      <button onClick={handleSave} disabled={isPending} className="btn-secondary ml-auto">
        Save
      </button>
    </div>
  );
}
