import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import type { ProjectPaymentSummary } from "@/types/database";

export default async function PaymentsPage() {
  const supabase = createClient();
  const { data } = await supabase
    .from("project_payment_summary")
    .select("*")
    .order("balance_pending", { ascending: false });

  const rows = (data ?? []) as ProjectPaymentSummary[];
  const totalPending = rows.reduce((sum, r) => sum + Math.max(r.balance_pending, 0), 0);
  const totalReceived = rows.reduce((sum, r) => sum + r.total_received, 0);

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Payments</h1>
        <p className="text-sm text-slate-500">Advance/balance tracking across all projects</p>
      </div>

      <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="card p-5">
          <p className="text-sm text-slate-500">Total Received</p>
          <p className="mt-1 text-xl font-bold text-emerald-600">${totalReceived.toLocaleString()}</p>
        </div>
        <div className="card p-5">
          <p className="text-sm text-slate-500">Total Pending Balance</p>
          <p className="mt-1 text-xl font-bold text-amber-600">${totalPending.toLocaleString()}</p>
        </div>
      </div>

      <div className="card overflow-hidden overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase text-slate-500">
            <tr>
              <th className="px-4 py-3 font-medium">Project</th>
              <th className="px-4 py-3 font-medium">Sale Amount</th>
              <th className="px-4 py-3 font-medium">Received</th>
              <th className="px-4 py-3 font-medium">Balance Pending</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((r) => (
              <tr key={r.project_id} className="hover:bg-slate-50">
                <td className="px-4 py-3">
                  <Link href={`/projects/${r.project_id}`} className="font-medium text-brand-blue-600 hover:underline">
                    {r.project_code}
                  </Link>
                </td>
                <td className="px-4 py-3 text-slate-600">${r.sale_amount.toLocaleString()}</td>
                <td className="px-4 py-3 text-emerald-600">${r.total_received.toLocaleString()}</td>
                <td className={`px-4 py-3 font-medium ${r.balance_pending > 0 ? "text-amber-600" : "text-slate-400"}`}>
                  ${r.balance_pending.toLocaleString()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {rows.length === 0 && <div className="p-10 text-center text-sm text-slate-500">No projects yet.</div>}
      </div>
    </div>
  );
}
