-- =========================================================
-- Phase 4 — Migration 0023
-- Supplier & Purchase Order Management
-- =========================================================

create table public.suppliers (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  contact_person text,
  phone text,
  email text,
  address text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create trigger trg_suppliers_updated_at before update on public.suppliers
  for each row execute function public.set_updated_at();

create type po_status as enum ('draft', 'ordered', 'received', 'cancelled');
create sequence if not exists po_number_seq start 1;

create or replace function public.generate_po_number()
returns text
language plpgsql
as $$
declare
  next_val int;
begin
  next_val := nextval('po_number_seq');
  return 'PO-' || to_char(now(), 'YYYY') || '-' || lpad(next_val::text, 4, '0');
end;
$$;

create table public.purchase_orders (
  id uuid primary key default uuid_generate_v4(),
  po_number text not null unique default public.generate_po_number(),
  supplier_id uuid references public.suppliers(id) on delete set null,
  status po_status not null default 'draft',
  order_date date not null default current_date,
  expected_date date,
  total_amount numeric(12,2) not null default 0,
  notes text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_purchase_orders_supplier on public.purchase_orders (supplier_id);
create index idx_purchase_orders_status on public.purchase_orders (status);

create trigger trg_purchase_orders_updated_at before update on public.purchase_orders
  for each row execute function public.set_updated_at();

create table public.purchase_order_items (
  id uuid primary key default uuid_generate_v4(),
  po_id uuid not null references public.purchase_orders(id) on delete cascade,
  inventory_item_id uuid references public.inventory_items(id),
  description text not null,
  quantity numeric(12,2) not null,
  unit_cost numeric(12,2) not null default 0,
  line_total numeric(12,2) not null default 0,
  created_at timestamptz not null default now()
);

create index idx_po_items_po on public.purchase_order_items (po_id);

create or replace function public.calc_po_item_total()
returns trigger
language plpgsql
as $$
begin
  new.line_total := new.quantity * new.unit_cost;
  return new;
end;
$$;

create trigger trg_po_items_calc_total
  before insert or update on public.purchase_order_items
  for each row execute function public.calc_po_item_total();

create or replace function public.recalc_po_total()
returns trigger
language plpgsql
as $$
declare
  target_po_id uuid;
  new_total numeric(12,2);
begin
  target_po_id := coalesce(new.po_id, old.po_id);

  select coalesce(sum(line_total), 0) into new_total
  from public.purchase_order_items
  where po_id = target_po_id;

  update public.purchase_orders set total_amount = new_total where id = target_po_id;

  return coalesce(new, old);
end;
$$;

create trigger trg_recalc_po_total
  after insert or update or delete on public.purchase_order_items
  for each row execute function public.recalc_po_total();

create or replace function public.handle_po_received()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  item record;
begin
  if new.status = 'received' and old.status is distinct from 'received' then
    for item in select * from public.purchase_order_items where po_id = new.id and inventory_item_id is not null loop
      insert into public.inventory_transactions (item_id, transaction_type, quantity, notes, created_by)
      values (item.inventory_item_id, 'in', item.quantity, 'Received via ' || new.po_number, auth.uid());
    end loop;
  end if;
  return new;
end;
$$;

create trigger trg_po_received_stock_in
  after update on public.purchase_orders
  for each row execute function public.handle_po_received();

alter table public.suppliers enable row level security;
alter table public.purchase_orders enable row level security;
alter table public.purchase_order_items enable row level security;

create policy suppliers_select_authenticated
  on public.suppliers for select
  using (auth.uid() is not null and public.current_role() != 'client');

create policy suppliers_write_admin_or_production
  on public.suppliers for all
  using (public.is_admin() or public.current_role() in ('production', 'packing'))
  with check (public.is_admin() or public.current_role() in ('production', 'packing'));

create policy purchase_orders_select_authenticated
  on public.purchase_orders for select
  using (auth.uid() is not null and public.current_role() != 'client');

create policy purchase_orders_write_admin_or_production
  on public.purchase_orders for all
  using (public.is_admin() or public.current_role() in ('production', 'packing'))
  with check (public.is_admin() or public.current_role() in ('production', 'packing'));

create policy po_items_select_via_po
  on public.purchase_order_items for select
  using (auth.uid() is not null and public.current_role() != 'client');

create policy po_items_write_admin_or_production
  on public.purchase_order_items for all
  using (public.is_admin() or public.current_role() in ('production', 'packing'))
  with check (public.is_admin() or public.current_role() in ('production', 'packing'));
