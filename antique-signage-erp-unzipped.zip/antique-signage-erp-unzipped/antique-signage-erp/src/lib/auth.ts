import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import type { Profile } from "@/types/database";

export async function getCurrentProfile(): Promise<Profile> {
  const supabase = createClient();

  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  const { data: profile, error } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single();

  if (error || !profile) {
    redirect("/login");
  }

  return profile as Profile;
}

export function isOwner(profile: Profile) {
  return profile.role === "owner" || profile.role === "admin";
}

// Phase 2 standard name — identical check, kept as a separate export
// so new code reads clearly while old code using isOwner() still works.
export function isAdmin(profile: Profile) {
  return profile.role === "owner" || profile.role === "admin";
}
