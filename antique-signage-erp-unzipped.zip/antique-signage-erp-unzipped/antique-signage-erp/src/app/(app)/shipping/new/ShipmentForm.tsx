"use client";

import { useMemo, useState, useTransition } from "react";
import { Plus, Trash2, AlertTriangle } from "lucide-react";
import { createShipment, type BoxInput } from "../actions";
import type { Project, ShippingRate } from "@/types/database";

const emptyBox = (): BoxInput => ({ length_cm: 0, width_cm: 0, height_cm: 0, actual_weight_kg: 0 });

function calcBox(box: BoxInput) {
  const volumetric = (box.length_cm * box.width_cm * box.height_cm) / 5000;
  const chargeable = Math.max(box.actual_weight_kg, volumetric);
  const oversize = box.length_cm > 100 || box.width_cm > 100 || box.height_cm > 100;
  const overweight = box.actual_weight_kg > 25;
  return { volumetric, chargeable, oversize, overweight };
}

export function ShipmentForm({ projects, rates }: { projects: Project[]; rates: ShippingRate[] }) {
  const [projectId, setProjectId] = useState("");
  const [country, setCountry] = useState("");
  const [courier, setCourier] = useState("");
  const [trackingNumber, setTrackingNumber] = useState("");
  const [oversizeCharge, setOversizeCharge] = useState(0);
  const [overweightCharge, setOverweightCharge] = useState(0);
  const [boxes, setBoxes] = useState<BoxInput[]>([emptyBox()]);
  const [error, setError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  const selectedRate = rates.find((r) => r.country === country);

  const boxCalcs = useMemo(() => boxes.map(calcBox), [boxes]);
  const totalChargeable = boxCalcs.reduce((sum, b) => sum + b.chargeable, 0);
  const hasOversize = boxCalcs.some((b) => b.oversize);
  const hasOverweight = boxCalcs.some((b) => b.overweight);
  const estimatedCost = selectedRate
    ? totalChargeable * selectedRate.rate_pkr_per_kg + oversizeCharge + overweightCharge
    : null;

  function updateBox(index: number, patch: Partial<BoxInput>) {
    setBoxes((prev) => prev.map((b, i) => (i === index ? { ...b, ...patch } : b)));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (!projectId || !country) {
      setError("Project and country are required.");
      return;
    }

    startTransition(async () => {
      try {
        await createShipment({
          project_id: projectId,
          country,
          courier,
          tracking_number: trackingNumber,
          duty_status: selectedRate?.duty_status ?? "not_applicable",
          oversize_charge: oversizeCharge,
          overweight_charge: overweightCharge,
          boxes
        });
      } catch (err) {
        if (err instanceof Error && err.message === "NEXT_REDIRECT") throw err;
        setError(err instanceof Error ? err.message : "Failed to create shipment");
      }
    });
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error && <div className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>}

      <div className="card space-y-4 p-6">
        <div>
          <label className="label">Project *</label>
          <select className="input" value={projectId} onChange={(e) => setProjectId(e.target.value)} required>
            <option value="" disabled>Select project</option>
            {projects.map((p) => (
              <option key={p.id} value={p.id}>{p.project_code} · {p.client_name}</option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label">Country *</label>
            <select className="input" value={country} onChange={(e) => setCountry(e.target.value)} required>
              <option value="" disabled>Select country</option>
              {rates.map((r) => (
                <option key={r.country} value={r.country}>{r.country} — {r.rate_pkr_per_kg} PKR/kg</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">Courier</label>
            <input className="input" value={courier} onChange={(e) => setCourier(e.target.value)} placeholder="DHL, FedEx, UPS..." />
          </div>
        </div>

        <div>
          <label className="label">Tracking Number</label>
          <input className="input" value={trackingNumber} onChange={(e) => setTrackingNumber(e.target.value)} />
        </div>
      </div>

      <div className="card p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-sm font-semibold text-slate-900">Boxes</h2>
          <button type="button" onClick={() => setBoxes((prev) => [...prev, emptyBox()])} className="btn-secondary">
            <Plus className="h-4 w-4" />
            Add Box
          </button>
        </div>

        <div className="space-y-4">
          {boxes.map((box, index) => {
            const calc = boxCalcs[index];
            return (
              <div key={index} className="rounded-lg border border-slate-200 p-4">
                <div className="mb-3 flex items-center justify-between">
                  <span className="text-xs font-medium uppercase text-slate-400">Box {index + 1}</span>
                  {boxes.length > 1 && (
                    <button type="button" onClick={() => setBoxes((prev) => prev.filter((_, i) => i !== index))} className="text-red-500 hover:text-red-700">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </div>
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                  <div>
                    <label className="label">Length (cm)</label>
                    <input type="number" step="0.1" className="input" value={box.length_cm || ""} onChange={(e) => updateBox(index, { length_cm: Number(e.target.value) })} />
                  </div>
                  <div>
                    <label className="label">Width (cm)</label>
                    <input type="number" step="0.1" className="input" value={box.width_cm || ""} onChange={(e) => updateBox(index, { width_cm: Number(e.target.value) })} />
                  </div>
                  <div>
                    <label className="label">Height (cm)</label>
                    <input type="number" step="0.1" className="input" value={box.height_cm || ""} onChange={(e) => updateBox(index, { height_cm: Number(e.target.value) })} />
                  </div>
                  <div>
                    <label className="label">Actual Weight (kg)</label>
                    <input type="number" step="0.1" className="input" value={box.actual_weight_kg || ""} onChange={(e) => updateBox(index, { actual_weight_kg: Number(e.target.value) })} />
                  </div>
                </div>
                <div className="mt-3 flex flex-wrap items-center gap-3 text-xs">
                  <span className="text-slate-500">Volumetric: {calc.volumetric.toFixed(2)}kg</span>
                  <span className="font-medium text-slate-700">Chargeable: {calc.chargeable.toFixed(2)}kg</span>
                  {calc.oversize && (
                    <span className="flex items-center gap-1 rounded-full bg-red-100 px-2 py-0.5 font-medium text-red-700">
                      <AlertTriangle className="h-3 w-3" /> Oversize
                    </span>
                  )}
                  {calc.overweight && (
                    <span className="flex items-center gap-1 rounded-full bg-red-100 px-2 py-0.5 font-medium text-red-700">
                      <AlertTriangle className="h-3 w-3" /> Overweight
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="card space-y-4 p-6">
        <h2 className="text-sm font-semibold text-slate-900">Surcharges</h2>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label">
              Oversize Charge (PKR) {hasOversize && <span className="text-red-600">— required</span>}
            </label>
            <input type="number" min={0} className="input" value={oversizeCharge || ""} onChange={(e) => setOversizeCharge(Number(e.target.value))} />
          </div>
          <div>
            <label className="label">
              Overweight Charge (PKR) {hasOverweight && <span className="text-red-600">— required</span>}
            </label>
            <input type="number" min={0} className="input" value={overweightCharge || ""} onChange={(e) => setOverweightCharge(Number(e.target.value))} />
          </div>
        </div>

        <div className="border-t border-slate-100 pt-4 text-right">
          <p className="text-sm text-slate-500">Total Chargeable Weight: {totalChargeable.toFixed(2)}kg</p>
          {estimatedCost !== null && (
            <p className="text-lg font-bold text-slate-900">Estimated Cost: {estimatedCost.toLocaleString()} PKR</p>
          )}
        </div>
      </div>

      <div className="flex justify-end">
        <button type="submit" disabled={isPending} className="btn-primary">
          {isPending ? "Creating..." : "Create Shipment"}
        </button>
      </div>
    </form>
  );
}
