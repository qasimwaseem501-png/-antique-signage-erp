import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./src/app/**/*.{ts,tsx}",
    "./src/components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          blue: {
            50: "#eef4ff",
            100: "#d9e6ff",
            200: "#b3ccff",
            300: "#80a8ff",
            400: "#4d80ff",
            500: "#1a56ff",
            600: "#0040e6",
            700: "#0033b3",
            800: "#002680",
            900: "#001a5c",
            950: "#000d33"
          },
          black: "#0a0a0a",
          white: "#ffffff"
        },
        status: {
          new: "#3b82f6",
          contacted: "#6366f1",
          quoteRequested: "#8b5cf6",
          quoteSent: "#a855f7",
          negotiation: "#f59e0b",
          depositReceived: "#eab308",
          confirmed: "#22c55e",
          production: "#f97316",
          packing: "#0ea5e9",
          shipping: "#06b6d4",
          delivered: "#10b981",
          completed: "#059669",
          lost: "#ef4444"
        }
      },
      fontFamily: {
        sans: ["var(--font-inter)", "system-ui", "sans-serif"]
      },
      boxShadow: {
        card: "0 1px 3px 0 rgba(0,0,0,0.06), 0 1px 2px -1px rgba(0,0,0,0.06)",
        elevated: "0 4px 16px -4px rgba(0,64,230,0.12)"
      }
    }
  },
  plugins: []
};

export default config;
