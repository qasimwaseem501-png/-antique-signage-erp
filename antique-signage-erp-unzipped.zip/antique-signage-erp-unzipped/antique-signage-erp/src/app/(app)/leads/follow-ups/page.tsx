import Link from "next/link";
import { ArrowLeft, Phone, MessageCircle } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile, isOwner } from "@/lib/auth";
import { StatusBadge } from "@/components/leads/StatusBadge";
import type { Lead } from "@/types/database";

export default async function FollowUpsPage() {
  const profile = await getCurrentProfile();
  const owner = isOwner(profile);
  const supabase = createClient();

  const today = new Date().toISOString().slice(0, 10);

  let query = supabase
    .from("leads")
    .select("*")
    .lte("follow_up_date", today)
    .not("follow_up_date", "is", null)
    .not("status", "in", "(closed_won,closed_lost)")
    .order("follow_up_date", { ascending: true });

  if (!owner) {
    query = query.eq("assigned_to", profile.id);
  }

  const { data } = await query;
  const leads = (data ?? []) as Lead[];

  const overdue = leads.filter((l) => l.follow_up_date! < today);
  const dueToday = leads.filter((l) => l.follow_up_date === today);

  return (
    <div>
      <Link href="/leads" className="mb-4 inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-900">
        <ArrowLeft className="h-4 w-4" />
        Back to Leads
      </Link>

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Follow-up Reminders</h1>
        <p className="text-sm text-slate-500">
          {owner ? "All follow-ups due across the team" : "Your follow-ups due"}
        </p>
      </div>

      {overdue.length > 0 && (
        <div className="mb-6">
          <h2 className="mb-2 text-sm font-semibold text-red-600">Overdue ({overdue.length})</h2>
          <LeadFollowUpList leads={overdue} />
        </div>
      )}

      <div>
        <h2 className="mb-2 text-sm font-semibold text-slate-700">Due Today ({dueToday.length})</h2>
        <LeadFollowUpList leads={dueToday} />
      </div>

      {leads.length === 0 && (
        <div className="card p-10 text-center text-sm text-slate-500">
          No follow-ups due right now. Nice work staying on top of things.
        </div>
      )}
    </div>
  );
}

function LeadFollowUpList({ leads }: { leads: Lead[] }) {
  if (leads.length === 0) {
    return <p className="text-sm text-slate-400">None.</p>;
  }

  return (
    <div className="space-y-2">
      {leads.map((lead) => {
        const whatsappNumber = lead.whatsapp?.replace(/[^\d]/g, "");
        return (
          <div key={lead.id} className="card flex flex-wrap items-center justify-between gap-3 p-4">
            <div>
              <Link href={`/leads/${lead.id}`} className="font-medium text-brand-blue-600 hover:underline">
                {lead.client_name}
              </Link>
              <p className="text-xs text-slate-500">{lead.lead_code} · Follow-up: {lead.follow_up_date}</p>
              {lead.next_action && <p className="mt-1 text-sm text-slate-600">{lead.next_action}</p>}
            </div>
            <div className="flex items-center gap-3">
              <StatusBadge status={lead.status} />
              {lead.phone && (
                <a href={`tel:${lead.phone}`} className="text-slate-400 hover:text-slate-700" title="Call">
                  <Phone className="h-4 w-4" />
                </a>
              )}
              {whatsappNumber && (
                <a
                  href={`https://wa.me/${whatsappNumber}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-slate-400 hover:text-emerald-600"
                  title="WhatsApp"
                >
                  <MessageCircle className="h-4 w-4" />
                </a>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
