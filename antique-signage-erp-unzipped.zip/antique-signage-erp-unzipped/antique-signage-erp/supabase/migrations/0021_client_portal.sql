-- =========================================================
-- Phase 4 — Migration 0021
-- Client Portal: clients get their own login, scoped to their
-- own quotations/projects/payments/shipments only.
-- =========================================================

alter type user_role add value if not exists 'client';

alter table public.profiles
  add column if not exists client_id uuid references public.clients(id);

create index if not exists idx_profiles_client_id on public.profiles (client_id);

create or replace function public.current_client_id()
returns uuid
language sql
security definer
stable
set search_path = public
as $$
  select client_id from public.profiles where id = auth.uid();
$$;

-- ---------------------------------------------------------
-- Client <-> Team messaging
-- ---------------------------------------------------------

create table public.client_messages (
  id uuid primary key default uuid_generate_v4(),
  project_id uuid not null references public.projects(id) on delete cascade,
  sender_id uuid references public.profiles(id),
  is_from_client boolean not null default false,
  message text not null,
  created_at timestamptz not null default now()
);

create index idx_client_messages_project on public.client_messages (project_id, created_at);

alter table public.client_messages enable row level security;

-- ---------------------------------------------------------
-- Helper: does this project belong to the currently logged-in client?
-- Matched via the client's linked clients.id against the project's
-- client_name snapshot (set consistently at lead/quotation creation).
-- ---------------------------------------------------------
create or replace function public.project_belongs_to_current_client(p_project_id uuid)
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1 from public.projects p
    join public.clients c on c.id = public.current_client_id()
    where p.id = p_project_id and p.client_name = c.client_name
  );
$$;

create policy client_messages_select_scoped
  on public.client_messages for select
  using (
    public.is_admin()
    or public.current_role() = 'accounts'
    or exists (
      select 1 from public.projects p
      left join public.leads l on l.id = p.lead_id
      where p.id = client_messages.project_id and l.assigned_to = auth.uid()
    )
    or (public.current_role() = 'client' and public.project_belongs_to_current_client(project_id))
  );

create policy client_messages_insert_scoped
  on public.client_messages for insert
  with check (
    public.is_admin()
    or exists (
      select 1 from public.projects p
      left join public.leads l on l.id = p.lead_id
      where p.id = client_messages.project_id and l.assigned_to = auth.uid()
    )
    or (public.current_role() = 'client' and public.project_belongs_to_current_client(project_id))
  );

-- ---------------------------------------------------------
-- RLS: 'client' role read-only access to their own data
-- ---------------------------------------------------------

create policy projects_select_client
  on public.projects for select
  using (public.current_role() = 'client' and public.project_belongs_to_current_client(id));

create policy quotations_select_client
  on public.quotations for select
  using (
    public.current_role() = 'client'
    and exists (
      select 1 from public.clients c
      where c.id = public.current_client_id() and c.client_name = quotations.client_name
    )
  );

create policy payments_select_client
  on public.payments for select
  using (public.current_role() = 'client' and public.project_belongs_to_current_client(project_id));

create policy shipments_select_client
  on public.shipments for select
  using (public.current_role() = 'client' and public.project_belongs_to_current_client(project_id));

create policy project_files_select_client
  on public.project_files for select
  using (public.current_role() = 'client' and public.project_belongs_to_current_client(project_id));

create policy design_approvals_select_client
  on public.design_approvals for select
  using (public.current_role() = 'client' and public.project_belongs_to_current_client(project_id));

-- Clients can respond to their own project's design (Approve / Changes Required)
create policy design_approvals_insert_client
  on public.design_approvals for insert
  with check (public.current_role() = 'client' and public.project_belongs_to_current_client(project_id));

create policy clients_select_own
  on public.clients for select
  using (public.current_role() = 'client' and id = public.current_client_id());
