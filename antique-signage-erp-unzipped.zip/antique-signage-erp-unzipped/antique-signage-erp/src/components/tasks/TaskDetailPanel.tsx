"use client";

import { useState, useTransition } from "react";
import { updateTaskStatus, addTaskComment } from "@/app/(app)/tasks/actions";
import { TASK_STATUS_LABELS, type TaskComment, type Profile } from "@/types/database";

export function TaskDetailPanel({
  taskId,
  currentStatus,
  comments,
  authors
}: {
  taskId: string;
  currentStatus: string;
  comments: TaskComment[];
  authors: Record<string, Profile>;
}) {
  const [comment, setComment] = useState("");
  const [isPending, startTransition] = useTransition();

  function handleStatusChange(status: string) {
    startTransition(() => updateTaskStatus(taskId, status));
  }

  function handleAddComment(e: React.FormEvent) {
    e.preventDefault();
    if (!comment.trim()) return;
    startTransition(async () => {
      await addTaskComment(taskId, comment);
      setComment("");
    });
  }

  return (
    <div className="space-y-6">
      <div className="card p-5">
        <label className="label">Status</label>
        <select className="input" value={currentStatus} disabled={isPending} onChange={(e) => handleStatusChange(e.target.value)}>
          {Object.entries(TASK_STATUS_LABELS).map(([value, label]) => (
            <option key={value} value={value}>{label}</option>
          ))}
        </select>
      </div>

      <div className="card p-5">
        <h3 className="mb-3 text-sm font-semibold text-slate-900">Comments</h3>
        <div className="mb-4 space-y-3">
          {comments.map((c) => (
            <div key={c.id} className="rounded-lg border border-slate-100 p-3 text-sm">
              <p className="text-slate-700">{c.comment}</p>
              <p className="mt-1 text-xs text-slate-400">
                {c.created_by ? authors[c.created_by]?.full_name ?? "Team" : "Team"} · {new Date(c.created_at).toLocaleString()}
              </p>
            </div>
          ))}
          {comments.length === 0 && <p className="text-sm text-slate-500">No comments yet.</p>}
        </div>
        <form onSubmit={handleAddComment} className="flex gap-2">
          <input className="input" placeholder="Add a comment..." value={comment} onChange={(e) => setComment(e.target.value)} />
          <button type="submit" disabled={isPending || !comment.trim()} className="btn-primary">Post</button>
        </form>
      </div>
    </div>
  );
}
