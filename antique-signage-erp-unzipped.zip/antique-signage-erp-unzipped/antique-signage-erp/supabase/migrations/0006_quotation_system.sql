-- =========================================================
-- Phase 2 — Migration 0006
-- Quotation System
-- =========================================================

create type quotation_status as enum ('draft', 'sent', 'approved', 'rejected');

create sequence if not exists quotation_number_seq start 1;

create or replace function public.generate_quotation_number()
returns text
language plpgsql
as $$
declare
  next_val int;
begin
  next_val := nextval('quotation_number_seq');
  return 'QT-' || to_char(now(), 'YYYY') || '-' || lpad(next_val::text, 4, '0');
end;
$$;

create table public.quotations (
  id uuid primary key default uuid_generate_v4(),
  quotation_number text not null unique default public.generate_quotation_number(),

  lead_id uuid references public.leads(id) on delete set null,

  -- Client snapshot (kept even if the lead is later edited/deleted)
  client_name text not null,
  company_name text,
  country text,
  email text,
  phone text,

  shipping_included boolean not null default true,
  subtotal numeric(12,2) not null default 0,
  shipping_cost numeric(12,2) not null default 0,
  total_amount numeric(12,2) not null default 0,

  status quotation_status not null default 'draft',

  notes text,

  created_by uuid references public.profiles(id),
  approved_by uuid references public.profiles(id),
  approved_at timestamptz,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_quotations_lead on public.quotations (lead_id);
create index idx_quotations_status on public.quotations (status);
create index idx_quotations_created_by on public.quotations (created_by);

create trigger trg_quotations_updated_at before update on public.quotations
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------
-- Quotation line items — a quote can include multiple sign types
-- (e.g. 3D channel letters + a pylon sign in one order)
-- ---------------------------------------------------------

create table public.quotation_items (
  id uuid primary key default uuid_generate_v4(),
  quotation_id uuid not null references public.quotations(id) on delete cascade,

  sign_type text not null,
  size text,
  material text,
  lighting_type text,
  quantity integer not null default 1,
  unit_price numeric(12,2) not null default 0,
  line_total numeric(12,2) not null default 0,

  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create index idx_quotation_items_quotation on public.quotation_items (quotation_id);

-- Auto-calculate line_total on insert/update
create or replace function public.calc_quotation_item_total()
returns trigger
language plpgsql
as $$
begin
  new.line_total := new.quantity * new.unit_price;
  return new;
end;
$$;

create trigger trg_quotation_items_calc_total
  before insert or update on public.quotation_items
  for each row execute function public.calc_quotation_item_total();

-- Recalculate quotation subtotal/total whenever line items change
create or replace function public.recalc_quotation_totals()
returns trigger
language plpgsql
as $$
declare
  target_quotation_id uuid;
  new_subtotal numeric(12,2);
  shipping numeric(12,2);
begin
  target_quotation_id := coalesce(new.quotation_id, old.quotation_id);

  select coalesce(sum(line_total), 0) into new_subtotal
  from public.quotation_items
  where quotation_id = target_quotation_id;

  select shipping_cost into shipping
  from public.quotations
  where id = target_quotation_id;

  update public.quotations
  set subtotal = new_subtotal,
      total_amount = new_subtotal + coalesce(shipping, 0)
  where id = target_quotation_id;

  return coalesce(new, old);
end;
$$;

create trigger trg_recalc_totals_after_item_change
  after insert or update or delete on public.quotation_items
  for each row execute function public.recalc_quotation_totals();

-- Log quotation status changes to the lead's timeline (if linked to a lead)
create or replace function public.log_quotation_status_change()
returns trigger
language plpgsql
as $$
begin
  if TG_OP = 'UPDATE' and old.status is distinct from new.status and new.lead_id is not null then
    insert into public.lead_timeline (lead_id, event_type, title, old_value, new_value, created_by)
    values (
      new.lead_id, 'quote_event',
      'Quotation ' || new.quotation_number || ' status changed',
      old.status::text, new.status::text,
      auth.uid()
    );
  end if;

  if TG_OP = 'INSERT' and new.lead_id is not null then
    insert into public.lead_timeline (lead_id, event_type, title, description, created_by)
    values (
      new.lead_id, 'quote_event',
      'Quotation created',
      new.quotation_number,
      auth.uid()
    );
  end if;

  return new;
end;
$$;

create trigger trg_quotations_log_insert
  after insert on public.quotations
  for each row execute function public.log_quotation_status_change();

create trigger trg_quotations_log_status_change
  after update on public.quotations
  for each row execute function public.log_quotation_status_change();
