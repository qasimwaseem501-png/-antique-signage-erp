import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { StageBadge } from "@/components/projects/StageBadge";
import type { Project } from "@/types/database";

export default async function ProjectsPage() {
  const supabase = createClient();
  const { data } = await supabase.from("projects").select("*").order("created_at", { ascending: false });
  const projects = (data ?? []) as Project[];

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Projects</h1>
        <p className="text-sm text-slate-500">All active and completed production orders</p>
      </div>

      <div className="card overflow-hidden overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase text-slate-500">
            <tr>
              <th className="px-4 py-3 font-medium">Project</th>
              <th className="px-4 py-3 font-medium">Client</th>
              <th className="px-4 py-3 font-medium">Country</th>
              <th className="px-4 py-3 font-medium">Sale Amount</th>
              <th className="px-4 py-3 font-medium">Stage</th>
              <th className="px-4 py-3 font-medium">Expected Delivery</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {projects.map((p) => (
              <tr key={p.id} className="hover:bg-slate-50">
                <td className="px-4 py-3">
                  <Link href={`/projects/${p.id}`} className="font-medium text-brand-blue-600 hover:underline">
                    {p.project_code}
                  </Link>
                </td>
                <td className="px-4 py-3">
                  <p className="font-medium text-slate-900">{p.client_name}</p>
                  {p.company_name && <p className="text-xs text-slate-500">{p.company_name}</p>}
                </td>
                <td className="px-4 py-3 text-slate-600">{p.country ?? "—"}</td>
                <td className="px-4 py-3 font-medium text-slate-900">${p.sale_amount.toLocaleString()}</td>
                <td className="px-4 py-3"><StageBadge stage={p.current_stage} /></td>
                <td className="px-4 py-3 text-slate-600">{p.expected_delivery_date ?? "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {projects.length === 0 && (
          <div className="p-10 text-center text-sm text-slate-500">
            No projects yet. Approve a quotation and convert it to a project to get started.
          </div>
        )}
      </div>
    </div>
  );
}
