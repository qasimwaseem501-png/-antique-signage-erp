import { createClient } from "@/lib/supabase/server";
import { ShipmentForm } from "./ShipmentForm";
import type { Project, ShippingRate } from "@/types/database";

export default async function NewShipmentPage() {
  const supabase = createClient();

  const [{ data: projectsData }, { data: ratesData }] = await Promise.all([
    supabase
      .from("projects")
      .select("*")
      .in("current_stage", ["packing", "ready_to_ship", "shipped"])
      .order("created_at", { ascending: false }),
    supabase.from("shipping_rates").select("*").order("country")
  ]);

  return (
    <div className="max-w-3xl">
      <h1 className="mb-6 text-2xl font-bold text-slate-900">New Shipment</h1>
      <ShipmentForm projects={(projectsData ?? []) as Project[]} rates={(ratesData ?? []) as ShippingRate[]} />
    </div>
  );
}
