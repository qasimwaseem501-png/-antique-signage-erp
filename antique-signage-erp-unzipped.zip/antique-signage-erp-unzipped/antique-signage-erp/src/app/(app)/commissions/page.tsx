import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile, isAdmin } from "@/lib/auth";
import { CommissionRow } from "@/components/commissions/CommissionRow";
import type { Commission, Profile } from "@/types/database";

export default async function CommissionsPage() {
  const profile = await getCurrentProfile();
  const admin = isAdmin(profile);
  const canManage = admin || profile.role === "accounts";
  const supabase = createClient();

  let query = supabase.from("commissions").select("*").order("created_at", { ascending: false });
  if (!canManage) {
    query = query.eq("employee_id", profile.id);
  }
  const { data } = await query;
  const commissions = (data ?? []) as Commission[];

  const employeeIds = Array.from(new Set(commissions.map((c) => c.employee_id)));
  let employees: Record<string, Profile> = {};
  if (employeeIds.length > 0) {
    const { data: profilesData } = await supabase.from("profiles").select("*").in("id", employeeIds);
    employees = Object.fromEntries((profilesData ?? []).map((p) => [p.id, p as Profile]));
  }

  const pendingTotal = commissions.filter((c) => c.status === "pending").reduce((s, c) => s + c.final_amount, 0);
  const approvedTotal = commissions.filter((c) => c.status === "approved").reduce((s, c) => s + c.final_amount, 0);

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Commissions</h1>
        <p className="text-sm text-slate-500">
          {canManage ? "All employee commissions" : "Your commission history"}
        </p>
      </div>

      {canManage && (
        <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="card p-5">
            <p className="text-sm text-slate-500">Pending Approval</p>
            <p className="mt-1 text-xl font-bold text-amber-600">${pendingTotal.toLocaleString()}</p>
          </div>
          <div className="card p-5">
            <p className="text-sm text-slate-500">Approved (Payable)</p>
            <p className="mt-1 text-xl font-bold text-blue-600">${approvedTotal.toLocaleString()}</p>
          </div>
        </div>
      )}

      <div className="card overflow-hidden overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase text-slate-500">
            <tr>
              <th className="px-4 py-3 font-medium">Employee</th>
              <th className="px-4 py-3 font-medium">Sale Amount</th>
              <th className="px-4 py-3 font-medium">Calculated</th>
              <th className="px-4 py-3 font-medium">Final Amount</th>
              <th className="px-4 py-3 font-medium">Eligibility</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {commissions.map((c) => (
              <CommissionRow key={c.id} commission={c} employee={employees[c.employee_id]} canManage={canManage} />
            ))}
          </tbody>
        </table>
        {commissions.length === 0 && (
          <div className="p-10 text-center text-sm text-slate-500">
            No commissions yet. They&apos;re created automatically when a lead is marked Closed Won.
          </div>
        )}
      </div>

      <p className="mt-4 text-xs text-slate-400">
        Commission tiers: up to $1,000 → $30 · $1,001–$3,000 → $50 · $3,001–$5,000 → $100 ·
        $5,001–$7,000 → $150 · $7,000+ → $200. Admin/Accounts can override any amount.
      </p>
    </div>
  );
}
