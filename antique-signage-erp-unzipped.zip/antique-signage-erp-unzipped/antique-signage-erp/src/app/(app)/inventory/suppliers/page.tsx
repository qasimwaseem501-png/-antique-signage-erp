import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { createSupplier } from "../actions";
import type { Supplier } from "@/types/database";

export default async function SuppliersPage() {
  const supabase = createClient();
  const { data } = await supabase.from("suppliers").select("*").order("name");
  const suppliers = (data ?? []) as Supplier[];

  return (
    <div>
      <Link href="/inventory" className="mb-4 inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-900">
        <ArrowLeft className="h-4 w-4" />
        Back to Inventory
      </Link>

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Suppliers</h1>
        <p className="text-sm text-slate-500">Manage your material suppliers</p>
      </div>

      <div className="mb-6 card p-5">
        <h3 className="mb-3 text-sm font-semibold text-slate-900">Add Supplier</h3>
        <form action={createSupplier} className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <input name="name" required placeholder="Supplier name *" className="input" />
          <input name="contact_person" placeholder="Contact person" className="input" />
          <input name="phone" placeholder="Phone" className="input" />
          <input name="email" type="email" placeholder="Email" className="input" />
          <input name="address" placeholder="Address" className="input sm:col-span-2" />
          <div className="sm:col-span-2">
            <button type="submit" className="btn-primary">Add Supplier</button>
          </div>
        </form>
      </div>

      <div className="card overflow-hidden overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase text-slate-500">
            <tr>
              <th className="px-4 py-3 font-medium">Name</th>
              <th className="px-4 py-3 font-medium">Contact</th>
              <th className="px-4 py-3 font-medium">Phone</th>
              <th className="px-4 py-3 font-medium">Email</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {suppliers.map((s) => (
              <tr key={s.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 font-medium text-slate-900">{s.name}</td>
                <td className="px-4 py-3 text-slate-600">{s.contact_person ?? "—"}</td>
                <td className="px-4 py-3 text-slate-600">{s.phone ?? "—"}</td>
                <td className="px-4 py-3 text-slate-600">{s.email ?? "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {suppliers.length === 0 && <div className="p-10 text-center text-sm text-slate-500">No suppliers yet.</div>}
      </div>
    </div>
  );
}
