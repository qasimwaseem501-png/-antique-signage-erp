import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile, isAdmin } from "@/lib/auth";
import { ReportsCharts } from "@/components/reports/ReportsCharts";
import {
  PROJECT_STAGE_LABELS,
  PROJECT_STAGE_ORDER,
  type Project,
  type Profile,
  type Lead,
  type AdSpend,
  type Commission,
  type ProjectPaymentSummary,
  type Task
} from "@/types/database";

export default async function ReportsPage() {
  const profile = await getCurrentProfile();
  if (!isAdmin(profile) && profile.role !== "accounts") redirect("/dashboard");

  const supabase = createClient();

  const [
    { data: projectsData },
    { data: leadsData },
    { data: profilesData },
    { data: adSpendData },
    { data: commissionsData },
    { data: paymentSummaryData },
    { data: tasksData }
  ] = await Promise.all([
    supabase.from("projects").select("*"),
    supabase.from("leads").select("*"),
    supabase.from("profiles").select("*"),
    supabase.from("ad_spend").select("*"),
    supabase.from("commissions").select("*"),
    supabase.from("project_payment_summary").select("*"),
    supabase.from("tasks").select("*")
  ]);

  const projects = (projectsData ?? []) as Project[];
  const leads = (leadsData ?? []) as Lead[];
  const profiles = (profilesData ?? []) as Profile[];
  const adSpend = (adSpendData ?? []) as AdSpend[];
  const commissions = (commissionsData ?? []) as Commission[];
  const paymentSummaries = (paymentSummaryData ?? []) as ProjectPaymentSummary[];
  const tasks = (tasksData ?? []) as Task[];

  const countryMap = new Map<string, number>();
  projects.forEach((p) => {
    const country = p.country ?? "Unknown";
    countryMap.set(country, (countryMap.get(country) ?? 0) + p.sale_amount);
  });
  const countrySales = Array.from(countryMap.entries()).map(([country, total]) => ({ country, total }));

  const leadById = new Map(leads.map((l) => [l.id, l]));
  const salesByPerson = new Map<string, number>();
  projects.forEach((p) => {
    if (!p.lead_id) return;
    const lead = leadById.get(p.lead_id);
    if (!lead?.assigned_to) return;
    salesByPerson.set(lead.assigned_to, (salesByPerson.get(lead.assigned_to) ?? 0) + p.sale_amount);
  });
  const profileById = new Map(profiles.map((p) => [p.id, p]));
  const salespersonSales = Array.from(salesByPerson.entries())
    .map(([id, total]) => ({ name: profileById.get(id)?.full_name ?? "Unknown", total }))
    .sort((a, b) => b.total - a.total);

  const months: string[] = [];
  const now = new Date();
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    months.push(d.toISOString().slice(0, 7));
  }
  const salesVsAds = months.map((month) => {
    const sales = projects.filter((p) => p.created_at.slice(0, 7) === month).reduce((sum, p) => sum + p.sale_amount, 0);
    const ads = adSpend.filter((a) => a.spend_date.slice(0, 7) === month).reduce((sum, a) => sum + a.amount, 0);
    return { month, sales, ads };
  });

  // Pending payments report
  const pendingPayments = paymentSummaries
    .filter((p) => p.balance_pending > 0)
    .sort((a, b) => b.balance_pending - a.balance_pending);
  const totalPendingBalance = pendingPayments.reduce((sum, p) => sum + p.balance_pending, 0);

  // Production status breakdown
  const productionStatus = PROJECT_STAGE_ORDER.map((stage) => ({
    stage,
    label: PROJECT_STAGE_LABELS[stage],
    count: projects.filter((p) => p.current_stage === stage).length
  })).filter((s) => s.count > 0);

  // Employee performance: leads closed, commission earned, tasks completed — per sales/production employee
  const employeePerformance = profiles
    .filter((p) => p.role !== "client" && p.is_active)
    .map((emp) => {
      const leadsWon = leads.filter((l) => l.assigned_to === emp.id && l.status === "closed_won").length;
      const commissionEarned = commissions
        .filter((c) => c.employee_id === emp.id && c.status === "paid")
        .reduce((sum, c) => sum + c.final_amount, 0);
      const tasksCompleted = tasks.filter((t) => t.assigned_to === emp.id && t.status === "done").length;
      return { name: emp.full_name, role: emp.role, leadsWon, commissionEarned, tasksCompleted };
    })
    .filter((e) => e.leadsWon > 0 || e.commissionEarned > 0 || e.tasksCompleted > 0)
    .sort((a, b) => b.leadsWon - a.leadsWon);

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Reports</h1>
        <p className="text-sm text-slate-500">Sales, payments, production, and team performance</p>
      </div>

      <ReportsCharts
        countrySales={countrySales}
        salespersonSales={salespersonSales}
        salesVsAds={salesVsAds}
        pendingPayments={pendingPayments}
        totalPendingBalance={totalPendingBalance}
        productionStatus={productionStatus}
        employeePerformance={employeePerformance}
      />
    </div>
  );
}
