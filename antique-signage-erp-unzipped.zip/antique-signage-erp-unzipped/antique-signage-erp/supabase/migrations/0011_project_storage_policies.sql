-- =========================================================
-- Phase 2 — Migration 0011
-- Storage policies for project files.
-- Path convention: client-files/projects/{project_id}/{filename}
-- (Phase 1 lead files use: client-files/{lead_id}/{filename})
-- =========================================================

create policy storage_select_project_scoped
  on storage.objects for select
  using (
    bucket_id = 'client-files'
    and (storage.foldername(name))[1] = 'projects'
    and (
      public.is_admin()
      or public.current_role() = 'accounts'
      or exists (
        select 1 from public.projects p
        left join public.leads l on l.id = p.lead_id
        where p.id::text = (storage.foldername(name))[2]
        and (
          (l.assigned_to = auth.uid())
          or (public.current_role() = 'designer' and public.is_design_stage(p.current_stage))
          or (public.current_role() = 'production' and public.is_production_stage(p.current_stage))
          or (public.current_role() = 'packing' and public.is_packing_stage(p.current_stage))
        )
      )
    )
  );

create policy storage_insert_project_scoped
  on storage.objects for insert
  with check (
    bucket_id = 'client-files'
    and (storage.foldername(name))[1] = 'projects'
    and auth.uid() is not null
  );

create policy storage_delete_project_admin_only
  on storage.objects for delete
  using (
    bucket_id = 'client-files'
    and (storage.foldername(name))[1] = 'projects'
    and public.is_admin()
  );
