import Link from "next/link";
import { ArrowLeft, Plus } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { PO_STATUS_LABELS, type PurchaseOrder } from "@/types/database";

export default async function PurchaseOrdersPage() {
  const supabase = createClient();
  const { data } = await supabase.from("purchase_orders").select("*, suppliers(name)").order("created_at", { ascending: false });
  const orders = (data ?? []) as (PurchaseOrder & { suppliers: { name: string } | null })[];

  return (
    <div>
      <Link href="/inventory" className="mb-4 inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-900">
        <ArrowLeft className="h-4 w-4" />
        Back to Inventory
      </Link>

      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Purchase Orders</h1>
          <p className="text-sm text-slate-500">Track material orders from suppliers</p>
        </div>
        <Link href="/inventory/purchase-orders/new" className="btn-primary">
          <Plus className="h-4 w-4" />
          New PO
        </Link>
      </div>

      <div className="card overflow-hidden overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase text-slate-500">
            <tr>
              <th className="px-4 py-3 font-medium">PO #</th>
              <th className="px-4 py-3 font-medium">Supplier</th>
              <th className="px-4 py-3 font-medium">Total</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Expected Date</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {orders.map((po) => (
              <tr key={po.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 font-medium text-slate-900">{po.po_number}</td>
                <td className="px-4 py-3 text-slate-600">{po.suppliers?.name ?? "—"}</td>
                <td className="px-4 py-3 text-slate-600">${po.total_amount.toLocaleString()}</td>
                <td className="px-4 py-3 text-slate-600">{PO_STATUS_LABELS[po.status]}</td>
                <td className="px-4 py-3 text-slate-600">{po.expected_date ?? "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {orders.length === 0 && <div className="p-10 text-center text-sm text-slate-500">No purchase orders yet.</div>}
      </div>
    </div>
  );
}
