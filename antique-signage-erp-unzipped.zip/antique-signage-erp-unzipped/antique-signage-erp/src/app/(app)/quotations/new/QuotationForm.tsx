"use client";

import { useMemo, useState, useTransition } from "react";
import { Plus, Trash2 } from "lucide-react";
import { createQuotation, type QuotationItemInput } from "../actions";
import type { Lead } from "@/types/database";

const SIGN_TYPES = [
  "3D Channel Letters",
  "Neon Sign",
  "Acrylic Sign",
  "LED Sign",
  "Pylon Sign",
  "ACM Board",
  "Shopfront Sign",
  "Other"
];

const LIGHTING_TYPES = ["None", "Front-lit LED", "Back-lit (Halo)", "Neon Flex", "Reverse-lit"];

const emptyItem = (): QuotationItemInput => ({
  sign_type: SIGN_TYPES[0],
  size: "",
  material: "",
  lighting_type: LIGHTING_TYPES[0],
  quantity: 1,
  unit_price: 0
});

export function QuotationForm({ leads }: { leads: Lead[] }) {
  const [leadId, setLeadId] = useState<string>("");
  const [clientName, setClientName] = useState("");
  const [companyName, setCompanyName] = useState("");
  const [country, setCountry] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [shippingIncluded, setShippingIncluded] = useState(true);
  const [shippingCost, setShippingCost] = useState(0);
  const [notes, setNotes] = useState("");
  const [items, setItems] = useState<QuotationItemInput[]>([emptyItem()]);
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  function handleSelectLead(id: string) {
    setLeadId(id);
    const lead = leads.find((l) => l.id === id);
    if (lead) {
      setClientName(lead.client_name);
      setCompanyName(lead.company_name ?? "");
      setCountry(lead.country ?? "");
      setEmail(lead.email ?? "");
      setPhone(lead.phone ?? "");
    }
  }

  function updateItem(index: number, patch: Partial<QuotationItemInput>) {
    setItems((prev) => prev.map((item, i) => (i === index ? { ...item, ...patch } : item)));
  }

  function removeItem(index: number) {
    setItems((prev) => prev.filter((_, i) => i !== index));
  }

  const subtotal = useMemo(
    () => items.reduce((sum, item) => sum + item.quantity * item.unit_price, 0),
    [items]
  );
  const total = subtotal + (shippingIncluded ? shippingCost : 0);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (!clientName.trim()) {
      setError("Client name is required.");
      return;
    }
    if (items.length === 0) {
      setError("Add at least one line item.");
      return;
    }

    startTransition(async () => {
      try {
        await createQuotation({
          lead_id: leadId || null,
          client_name: clientName,
          company_name: companyName,
          country,
          email,
          phone,
          shipping_included: shippingIncluded,
          shipping_cost: shippingCost,
          notes,
          items
        });
      } catch (err) {
        // Next.js's redirect() throws a special internal error to trigger
        // navigation — it must be re-thrown, not treated as a failure.
        if (err instanceof Error && err.message === "NEXT_REDIRECT") {
          throw err;
        }
        setError(err instanceof Error ? err.message : "Something went wrong.");
      }
    });
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error && <div className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>}

      <div className="card space-y-4 p-6">
        <h2 className="text-sm font-semibold text-slate-900">Client Information</h2>

        {leads.length > 0 && (
          <div>
            <label className="label">Link to existing lead (optional)</label>
            <select className="input" value={leadId} onChange={(e) => handleSelectLead(e.target.value)}>
              <option value="">— No linked lead —</option>
              {leads.map((lead) => (
                <option key={lead.id} value={lead.id}>
                  {lead.lead_code} · {lead.client_name}
                </option>
              ))}
            </select>
          </div>
        )}

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="label">Client Name *</label>
            <input className="input" value={clientName} onChange={(e) => setClientName(e.target.value)} required />
          </div>
          <div>
            <label className="label">Company Name</label>
            <input className="input" value={companyName} onChange={(e) => setCompanyName(e.target.value)} />
          </div>
          <div>
            <label className="label">Country</label>
            <input className="input" value={country} onChange={(e) => setCountry(e.target.value)} />
          </div>
          <div>
            <label className="label">Email</label>
            <input type="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div>
            <label className="label">Phone</label>
            <input className="input" value={phone} onChange={(e) => setPhone(e.target.value)} />
          </div>
        </div>
      </div>

      <div className="card p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-sm font-semibold text-slate-900">Line Items</h2>
          <button type="button" onClick={() => setItems((prev) => [...prev, emptyItem()])} className="btn-secondary">
            <Plus className="h-4 w-4" />
            Add Item
          </button>
        </div>

        <div className="space-y-4">
          {items.map((item, index) => (
            <div key={index} className="rounded-lg border border-slate-200 p-4">
              <div className="mb-3 flex items-center justify-between">
                <span className="text-xs font-medium uppercase text-slate-400">Item {index + 1}</span>
                {items.length > 1 && (
                  <button type="button" onClick={() => removeItem(index)} className="text-red-500 hover:text-red-700">
                    <Trash2 className="h-4 w-4" />
                  </button>
                )}
              </div>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                <div>
                  <label className="label">Sign Type</label>
                  <select className="input" value={item.sign_type} onChange={(e) => updateItem(index, { sign_type: e.target.value })}>
                    {SIGN_TYPES.map((t) => (
                      <option key={t} value={t}>{t}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label">Size</label>
                  <input className="input" placeholder='e.g. 6ft x 2ft' value={item.size} onChange={(e) => updateItem(index, { size: e.target.value })} />
                </div>
                <div>
                  <label className="label">Material</label>
                  <input className="input" placeholder="Acrylic, Aluminum..." value={item.material} onChange={(e) => updateItem(index, { material: e.target.value })} />
                </div>
                <div>
                  <label className="label">Lighting</label>
                  <select className="input" value={item.lighting_type} onChange={(e) => updateItem(index, { lighting_type: e.target.value })}>
                    {LIGHTING_TYPES.map((t) => (
                      <option key={t} value={t}>{t}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label">Quantity</label>
                  <input
                    type="number"
                    min={1}
                    className="input"
                    value={item.quantity}
                    onChange={(e) => updateItem(index, { quantity: Number(e.target.value) })}
                  />
                </div>
                <div>
                  <label className="label">Unit Price (USD)</label>
                  <input
                    type="number"
                    min={0}
                    step="0.01"
                    className="input"
                    value={item.unit_price}
                    onChange={(e) => updateItem(index, { unit_price: Number(e.target.value) })}
                  />
                </div>
              </div>
              <p className="mt-2 text-right text-sm font-medium text-slate-700">
                Line total: ${(item.quantity * item.unit_price).toLocaleString()}
              </p>
            </div>
          ))}
        </div>
      </div>

      <div className="card space-y-4 p-6">
        <h2 className="text-sm font-semibold text-slate-900">Shipping &amp; Total</h2>
        <label className="flex items-center gap-2 text-sm text-slate-700">
          <input
            type="checkbox"
            checked={shippingIncluded}
            onChange={(e) => setShippingIncluded(e.target.checked)}
          />
          Shipping included in this quotation
        </label>
        {shippingIncluded && (
          <div className="max-w-xs">
            <label className="label">Shipping Cost (USD)</label>
            <input
              type="number"
              min={0}
              step="0.01"
              className="input"
              value={shippingCost}
              onChange={(e) => setShippingCost(Number(e.target.value))}
            />
          </div>
        )}
        <div>
          <label className="label">Notes</label>
          <textarea className="input" rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} />
        </div>

        <div className="border-t border-slate-100 pt-4 text-right">
          <p className="text-sm text-slate-500">Subtotal: ${subtotal.toLocaleString()}</p>
          {shippingIncluded && <p className="text-sm text-slate-500">Shipping: ${shippingCost.toLocaleString()}</p>}
          <p className="text-lg font-bold text-slate-900">Total: ${total.toLocaleString()}</p>
        </div>
      </div>

      <div className="flex justify-end">
        <button type="submit" disabled={isPending} className="btn-primary">
          {isPending ? "Creating..." : "Create Quotation"}
        </button>
      </div>
    </form>
  );
}
