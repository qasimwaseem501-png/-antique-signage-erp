import Link from "next/link";
import { Plus, Upload, BellRing } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile, isOwner } from "@/lib/auth";
import { StatusBadge } from "@/components/leads/StatusBadge";
import { ACTIVE_LEAD_STATUSES, LEAD_SOURCE_LABELS, LEAD_STATUS_LABELS, type Lead, type Profile } from "@/types/database";

export default async function LeadsPage({
  searchParams
}: {
  searchParams: { status?: string; q?: string };
}) {
  const profile = await getCurrentProfile();
  const supabase = createClient();
  const owner = isOwner(profile);

  let query = supabase.from("leads").select("*").order("created_at", { ascending: false });

  if (searchParams.status) {
    query = query.eq("status", searchParams.status);
  }
  if (searchParams.q) {
    query = query.or(
      `client_name.ilike.%${searchParams.q}%,company_name.ilike.%${searchParams.q}%,lead_code.ilike.%${searchParams.q}%`
    );
  }

  const { data: leadsData } = await query;
  const leads = (leadsData ?? []) as Lead[];

  let assignees: Record<string, Profile> = {};
  if (owner) {
    const { data: profilesData } = await supabase.from("profiles").select("*");
    assignees = Object.fromEntries((profilesData ?? []).map((p) => [p.id, p as Profile]));
  }

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Leads CRM</h1>
          <p className="text-sm text-slate-500">
            {owner ? "All company leads" : "Leads assigned to you"}
          </p>
        </div>
        <Link href="/leads/new" className="btn-primary">
          <Plus className="h-4 w-4" />
          New Lead
        </Link>
      </div>

      <div className="mb-4 flex flex-wrap gap-3">
        <Link href="/leads/follow-ups" className="flex items-center gap-1.5 text-sm font-medium text-amber-600 hover:underline">
          <BellRing className="h-4 w-4" />
          Follow-up Reminders
        </Link>
        <Link href="/leads/import" className="flex items-center gap-1.5 text-sm font-medium text-brand-blue-600 hover:underline">
          <Upload className="h-4 w-4" />
          Import Leads (CSV)
        </Link>
      </div>

      <form className="mb-4 flex flex-wrap gap-3" method="get">
        <input
          type="text"
          name="q"
          defaultValue={searchParams.q}
          placeholder="Search by name, company, or lead code..."
          className="input max-w-xs"
        />
        <select name="status" defaultValue={searchParams.status ?? ""} className="input max-w-[200px]">
          <option value="">All statuses</option>
          {ACTIVE_LEAD_STATUSES.map((status) => (
            <option key={status} value={status}>
              {LEAD_STATUS_LABELS[status]}
            </option>
          ))}
        </select>
        <button type="submit" className="btn-secondary">
          Filter
        </button>
      </form>

      <div className="card overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase text-slate-500">
            <tr>
              <th className="px-4 py-3 font-medium">Lead</th>
              <th className="px-4 py-3 font-medium">Client</th>
              <th className="px-4 py-3 font-medium">Country</th>
              <th className="px-4 py-3 font-medium">Source</th>
              <th className="px-4 py-3 font-medium">Status</th>
              {owner && <th className="px-4 py-3 font-medium">Assigned To</th>}
              <th className="px-4 py-3 font-medium">Follow Up</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {leads.map((lead) => (
              <tr key={lead.id} className="hover:bg-slate-50">
                <td className="px-4 py-3">
                  <Link href={`/leads/${lead.id}`} className="font-medium text-brand-blue-600 hover:underline">
                    {lead.lead_code}
                  </Link>
                </td>
                <td className="px-4 py-3">
                  <p className="font-medium text-slate-900">{lead.client_name}</p>
                  {lead.company_name && (
                    <p className="text-xs text-slate-500">{lead.company_name}</p>
                  )}
                </td>
                <td className="px-4 py-3 text-slate-600">{lead.country ?? "—"}</td>
                <td className="px-4 py-3 text-slate-600">{LEAD_SOURCE_LABELS[lead.source]}</td>
                <td className="px-4 py-3">
                  <StatusBadge status={lead.status} />
                </td>
                {owner && (
                  <td className="px-4 py-3 text-slate-600">
                    {lead.assigned_to ? assignees[lead.assigned_to]?.full_name ?? "—" : "Unassigned"}
                  </td>
                )}
                <td className="px-4 py-3 text-slate-600">{lead.follow_up_date ?? "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>

        {leads.length === 0 && (
          <div className="p-10 text-center text-sm text-slate-500">
            No leads found. Create your first lead to get started.
          </div>
        )}
      </div>
    </div>
  );
}
