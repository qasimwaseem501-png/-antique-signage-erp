import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile, isAdmin } from "@/lib/auth";
import { QuotationStatusBadge } from "@/components/quotations/QuotationStatusBadge";
import { QuotationActions } from "@/components/quotations/QuotationActions";
import type { Quotation, QuotationItem } from "@/types/database";

export default async function QuotationDetailPage({ params }: { params: { id: string } }) {
  const profile = await getCurrentProfile();
  const supabase = createClient();

  const { data: quotation } = await supabase.from("quotations").select("*").eq("id", params.id).single();
  if (!quotation) notFound();

  const { data: itemsData } = await supabase
    .from("quotation_items")
    .select("*")
    .eq("quotation_id", params.id)
    .order("sort_order");

  const items = (itemsData ?? []) as QuotationItem[];
  const typedQuotation = quotation as Quotation;
  const canManage = isAdmin(profile) || typedQuotation.created_by === profile.id;

  return (
    <div className="max-w-4xl">
      <Link href="/quotations" className="mb-4 inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-900">
        <ArrowLeft className="h-4 w-4" />
        Back to Quotations
      </Link>

      <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-sm font-medium text-brand-blue-600">{typedQuotation.quotation_number}</p>
          <h1 className="text-2xl font-bold text-slate-900">{typedQuotation.client_name}</h1>
          <div className="mt-2">
            <QuotationStatusBadge status={typedQuotation.status} />
          </div>
        </div>
        <QuotationActions quotation={typedQuotation} items={items} canManage={canManage} />
      </div>

      <div className="card mb-6 overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase text-slate-500">
            <tr>
              <th className="px-4 py-3 font-medium">Sign Type</th>
              <th className="px-4 py-3 font-medium">Size</th>
              <th className="px-4 py-3 font-medium">Material</th>
              <th className="px-4 py-3 font-medium">Lighting</th>
              <th className="px-4 py-3 font-medium">Qty</th>
              <th className="px-4 py-3 font-medium">Unit Price</th>
              <th className="px-4 py-3 font-medium">Total</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {items.map((item) => (
              <tr key={item.id}>
                <td className="px-4 py-3 font-medium text-slate-900">{item.sign_type}</td>
                <td className="px-4 py-3 text-slate-600">{item.size ?? "—"}</td>
                <td className="px-4 py-3 text-slate-600">{item.material ?? "—"}</td>
                <td className="px-4 py-3 text-slate-600">{item.lighting_type ?? "—"}</td>
                <td className="px-4 py-3 text-slate-600">{item.quantity}</td>
                <td className="px-4 py-3 text-slate-600">${item.unit_price.toLocaleString()}</td>
                <td className="px-4 py-3 font-medium text-slate-900">${item.line_total.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="border-t border-slate-100 p-4 text-right">
          <p className="text-sm text-slate-500">Subtotal: ${typedQuotation.subtotal.toLocaleString()}</p>
          {typedQuotation.shipping_included && (
            <p className="text-sm text-slate-500">Shipping: ${typedQuotation.shipping_cost.toLocaleString()}</p>
          )}
          <p className="text-lg font-bold text-slate-900">Total: ${typedQuotation.total_amount.toLocaleString()}</p>
        </div>
      </div>

      {typedQuotation.notes && (
        <div className="card p-5">
          <h3 className="mb-2 text-sm font-semibold text-slate-900">Notes</h3>
          <p className="text-sm text-slate-600">{typedQuotation.notes}</p>
        </div>
      )}
    </div>
  );
}
