"use client";

import { useState, useTransition } from "react";
import { Check, Pencil, X } from "lucide-react";
import { updateCommissionStatus, overrideCommissionAmount } from "@/app/(app)/commissions/actions";
import type { Commission, Profile } from "@/types/database";

const STATUS_STYLES: Record<string, string> = {
  pending: "bg-amber-100 text-amber-700",
  approved: "bg-blue-100 text-blue-700",
  paid: "bg-emerald-100 text-emerald-700",
  rejected: "bg-red-100 text-red-700"
};

const ELIGIBILITY_STYLES: Record<string, string> = {
  new_client: "bg-emerald-50 text-emerald-600",
  repeat_client: "bg-slate-100 text-slate-600",
  admin_review: "bg-orange-50 text-orange-600"
};

const ELIGIBILITY_LABELS: Record<string, string> = {
  new_client: "New Client",
  repeat_client: "Repeat Client",
  admin_review: "Needs Review"
};

export function CommissionRow({
  commission,
  employee,
  canManage
}: {
  commission: Commission;
  employee: Profile | undefined;
  canManage: boolean;
}) {
  const [editing, setEditing] = useState(false);
  const [overrideValue, setOverrideValue] = useState(commission.override_amount ?? commission.calculated_amount);
  const [isPending, startTransition] = useTransition();

  function handleSaveOverride() {
    startTransition(async () => {
      await overrideCommissionAmount(commission.id, overrideValue, commission.notes ?? "");
      setEditing(false);
    });
  }

  return (
    <tr className="hover:bg-slate-50">
      <td className="px-4 py-3 font-medium text-slate-900">{employee?.full_name ?? "—"}</td>
      <td className="px-4 py-3 text-slate-600">${commission.sale_amount.toLocaleString()}</td>
      <td className="px-4 py-3 text-slate-600">${commission.calculated_amount.toLocaleString()}</td>
      <td className="px-4 py-3">
        {editing ? (
          <div className="flex items-center gap-2">
            <input
              type="number"
              className="input max-w-[100px]"
              value={overrideValue}
              onChange={(e) => setOverrideValue(Number(e.target.value))}
            />
            <button onClick={handleSaveOverride} disabled={isPending} className="text-emerald-600">
              <Check className="h-4 w-4" />
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <span className="font-medium text-slate-900">${commission.final_amount.toLocaleString()}</span>
            {canManage && (
              <button onClick={() => setEditing(true)} className="text-slate-400 hover:text-slate-700">
                <Pencil className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        )}
      </td>
      <td className="px-4 py-3">
        <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ${ELIGIBILITY_STYLES[commission.eligibility]}`}>
          {ELIGIBILITY_LABELS[commission.eligibility]}
        </span>
      </td>
      <td className="px-4 py-3">
        <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium capitalize ${STATUS_STYLES[commission.status]}`}>
          {commission.status}
        </span>
      </td>
      <td className="px-4 py-3">
        {canManage && !["paid", "rejected"].includes(commission.status) && (
          <div className="flex gap-2">
            {commission.status === "pending" && (
              <>
                <button
                  onClick={() => startTransition(() => updateCommissionStatus(commission.id, "approved"))}
                  disabled={isPending}
                  className="text-xs font-medium text-brand-blue-600 hover:underline"
                >
                  Approve
                </button>
                <button
                  onClick={() => startTransition(() => updateCommissionStatus(commission.id, "rejected"))}
                  disabled={isPending}
                  className="flex items-center gap-0.5 text-xs font-medium text-red-600 hover:underline"
                >
                  <X className="h-3 w-3" />
                  Reject
                </button>
              </>
            )}
            {commission.status === "approved" && (
              <button
                onClick={() => startTransition(() => updateCommissionStatus(commission.id, "paid"))}
                disabled={isPending}
                className="text-xs font-medium text-emerald-600 hover:underline"
              >
                Mark Paid
              </button>
            )}
          </div>
        )}
      </td>
    </tr>
  );
}
