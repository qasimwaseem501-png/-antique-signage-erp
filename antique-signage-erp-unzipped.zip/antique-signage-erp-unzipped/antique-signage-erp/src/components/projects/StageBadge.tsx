import { PROJECT_STAGE_LABELS, type ProjectStage } from "@/types/database";

const STAGE_STYLES: Record<ProjectStage, string> = {
  design_pending: "bg-slate-100 text-slate-700",
  design_approved: "bg-indigo-100 text-indigo-700",
  material_purchase: "bg-purple-100 text-purple-700",
  cnc_laser_cutting: "bg-orange-100 text-orange-700",
  letter_bending: "bg-amber-100 text-amber-700",
  welding_fabrication: "bg-yellow-100 text-yellow-700",
  powder_coating: "bg-lime-100 text-lime-700",
  led_wiring: "bg-teal-100 text-teal-700",
  testing: "bg-cyan-100 text-cyan-700",
  packing: "bg-sky-100 text-sky-700",
  ready_to_ship: "bg-blue-100 text-blue-700",
  shipped: "bg-violet-100 text-violet-700",
  delivered: "bg-emerald-100 text-emerald-700"
};

export function StageBadge({ stage }: { stage: ProjectStage }) {
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ${STAGE_STYLES[stage]}`}>
      {PROJECT_STAGE_LABELS[stage]}
    </span>
  );
}
