"use client";

import { useState, useTransition } from "react";
import { submitDesignApproval } from "@/app/(app)/design/actions";
import { DESIGN_APPROVAL_STATUS_LABELS, type DesignApproval, type DesignApprovalStatus } from "@/types/database";

const STATUS_STYLES: Record<DesignApprovalStatus, string> = {
  pending: "bg-amber-100 text-amber-700",
  changes_required: "bg-red-100 text-red-700",
  approved: "bg-emerald-100 text-emerald-700"
};

export function DesignApprovalPanel({
  projectId,
  history,
  canManage
}: {
  projectId: string;
  history: DesignApproval[];
  canManage: boolean;
}) {
  const [status, setStatus] = useState<DesignApprovalStatus>("pending");
  const [notes, setNotes] = useState("");
  const [isPending, startTransition] = useTransition();

  const latest = history[0];

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    startTransition(async () => {
      await submitDesignApproval(projectId, status, notes);
      setNotes("");
    });
  }

  return (
    <div className="card p-5">
      <h3 className="mb-3 text-sm font-semibold text-slate-900">Design Approval</h3>

      {latest && (
        <div className="mb-4">
          <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ${STATUS_STYLES[latest.status]}`}>
            {DESIGN_APPROVAL_STATUS_LABELS[latest.status]}
          </span>
          {latest.revision_notes && <p className="mt-2 text-sm text-slate-600">{latest.revision_notes}</p>}
        </div>
      )}

      {canManage && (
        <form onSubmit={handleSubmit} className="space-y-3 border-t border-slate-100 pt-4">
          <select className="input" value={status} onChange={(e) => setStatus(e.target.value as DesignApprovalStatus)}>
            {Object.entries(DESIGN_APPROVAL_STATUS_LABELS).map(([value, label]) => (
              <option key={value} value={value}>{label}</option>
            ))}
          </select>
          <textarea
            className="input"
            rows={2}
            placeholder="Revision notes (optional)"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
          />
          <button type="submit" disabled={isPending} className="btn-primary">
            Submit Update
          </button>
        </form>
      )}

      {history.length > 1 && (
        <div className="mt-4 space-y-2 border-t border-slate-100 pt-4">
          <p className="text-xs font-medium uppercase text-slate-400">History</p>
          {history.slice(1).map((h) => (
            <div key={h.id} className="text-xs text-slate-500">
              {DESIGN_APPROVAL_STATUS_LABELS[h.status]} — {new Date(h.created_at).toLocaleDateString()}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
