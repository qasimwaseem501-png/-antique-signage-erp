import Link from "next/link";
import { AlertTriangle, Plus } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile, isAdmin } from "@/lib/auth";
import { DeliveryStatusSelect } from "@/components/shared/DeliveryStatusSelect";
import type { Shipment, ShipmentBox } from "@/types/database";

export default async function ShippingPage() {
  const profile = await getCurrentProfile();
  const admin = isAdmin(profile);
  const supabase = createClient();

  const { data } = await supabase
    .from("shipments")
    .select("*, projects(project_code, client_name)")
    .order("created_at", { ascending: false });

  const shipments = (data ?? []) as (Shipment & { projects: { project_code: string; client_name: string } | null })[];

  const shipmentIds = shipments.map((s) => s.id);
  let boxesByShipment: Record<string, ShipmentBox[]> = {};
  if (shipmentIds.length > 0) {
    const { data: boxesData } = await supabase.from("shipment_boxes").select("*").in("shipment_id", shipmentIds);
    boxesByShipment = (boxesData ?? []).reduce<Record<string, ShipmentBox[]>>((acc, box) => {
      (acc[box.shipment_id] ??= []).push(box as ShipmentBox);
      return acc;
    }, {});
  }

  const canCreate = admin || profile.role === "packing";

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Shipping</h1>
          <p className="text-sm text-slate-500">Multi-box shipments with automatic chargeable weight</p>
        </div>
        {canCreate && (
          <Link href="/shipping/new" className="btn-primary">
            <Plus className="h-4 w-4" />
            New Shipment
          </Link>
        )}
      </div>

      <div className="card overflow-hidden overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase text-slate-500">
            <tr>
              <th className="px-4 py-3 font-medium">Project</th>
              <th className="px-4 py-3 font-medium">Country</th>
              <th className="px-4 py-3 font-medium">Boxes</th>
              <th className="px-4 py-3 font-medium">Chargeable Wt.</th>
              <th className="px-4 py-3 font-medium">Total Cost (PKR)</th>
              <th className="px-4 py-3 font-medium">Tracking #</th>
              <th className="px-4 py-3 font-medium">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {shipments.map((s) => {
              const boxes = boxesByShipment[s.id] ?? [];
              const totalChargeable = boxes.reduce((sum, b) => sum + (b.chargeable_weight_kg ?? 0), 0);
              const hasAlert = boxes.some((b) => b.is_oversize || b.is_overweight);
              return (
                <tr key={s.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3">
                    {s.projects && (
                      <Link href={`/projects/${s.project_id}`} className="font-medium text-brand-blue-600 hover:underline">
                        {s.projects.project_code}
                      </Link>
                    )}
                    <p className="text-xs text-slate-500">{s.projects?.client_name}</p>
                  </td>
                  <td className="px-4 py-3 text-slate-600">{s.country}</td>
                  <td className="px-4 py-3 text-slate-600">
                    <div className="flex items-center gap-1.5">
                      {boxes.length}
                      {hasAlert && (
                        <span title="Oversize or overweight box in this shipment">
                          <AlertTriangle className="h-3.5 w-3.5 text-red-500" />
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-slate-600">{totalChargeable.toFixed(2)}kg</td>
                  <td className="px-4 py-3 font-medium text-slate-900">{s.total_shipping_cost.toLocaleString()}</td>
                  <td className="px-4 py-3 text-slate-600">{s.tracking_number ?? "—"}</td>
                  <td className="px-4 py-3">
                    <DeliveryStatusSelect shipmentId={s.id} status={s.delivery_status} />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {shipments.length === 0 && (
          <div className="p-10 text-center text-sm text-slate-500">No shipments recorded yet.</div>
        )}
      </div>
    </div>
  );
}
