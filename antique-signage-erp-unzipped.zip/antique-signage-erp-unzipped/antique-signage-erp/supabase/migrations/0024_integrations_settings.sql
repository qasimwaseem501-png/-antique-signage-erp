-- =========================================================
-- Phase 4 — Migration 0024
-- Integration settings placeholders (WhatsApp, Meta, Google Ads,
-- Stripe/PayPal, DHL/FedEx). Admin-only visibility since these
-- will hold API keys/secrets once wired up.
-- =========================================================

create table public.integrations_config (
  id uuid primary key default uuid_generate_v4(),
  service_name text not null unique,
  display_name text not null,
  api_key text,
  additional_config jsonb,
  is_enabled boolean not null default false,
  updated_at timestamptz not null default now()
);

create trigger trg_integrations_config_updated_at before update on public.integrations_config
  for each row execute function public.set_updated_at();

insert into public.integrations_config (service_name, display_name) values
  ('whatsapp_business', 'WhatsApp Business API'),
  ('meta_lead_ads', 'Meta Lead Ads'),
  ('google_ads', 'Google Ads'),
  ('stripe', 'Stripe'),
  ('paypal', 'PayPal'),
  ('dhl', 'DHL Tracking API'),
  ('fedex', 'FedEx Tracking API')
on conflict (service_name) do nothing;

alter table public.integrations_config enable row level security;

create policy integrations_config_admin_only
  on public.integrations_config for all
  using (public.is_admin())
  with check (public.is_admin());
