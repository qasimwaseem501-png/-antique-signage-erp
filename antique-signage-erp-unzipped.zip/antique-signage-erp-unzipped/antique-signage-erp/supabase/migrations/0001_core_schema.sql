-- =========================================================
-- Antique Signage & Advertising — ERP/CRM Core Schema
-- Phase 1: Auth, Roles, Leads CRM, Clients, Timeline
-- =========================================================

-- ---------- Extensions ----------
create extension if not exists "uuid-ossp";
create extension if not exists "pgcrypto";

-- =========================================================
-- ENUMS
-- =========================================================

create type user_role as enum (
  'owner',
  'sales',
  'production',
  'designer',
  'accounts'
);

create type lead_source as enum (
  'meta_ads',
  'google_ads',
  'website',
  'whatsapp',
  'referral',
  'organic',
  'other'
);

create type lead_status as enum (
  'new',
  'contacted',
  'quote_requested',
  'quote_sent',
  'negotiation',
  'deposit_received',
  'confirmed',
  'production',
  'packing',
  'shipping',
  'delivered',
  'completed',
  'lost'
);

-- =========================================================
-- PROFILES (extends auth.users with role + employee data)
-- =========================================================

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  email text not null unique,
  phone text,
  role user_role not null default 'sales',
  is_active boolean not null default true,
  avatar_url text,
  hire_date date,
  base_salary numeric(12,2),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

comment on table public.profiles is 'One row per employee/owner. Mirrors auth.users, adds role + HR fields.';

-- =========================================================
-- SEQUENCES for human-readable IDs
-- =========================================================

create sequence if not exists lead_id_seq start 1;
create sequence if not exists quote_id_seq start 1;

create or replace function public.generate_lead_code()
returns text
language plpgsql
as $$
declare
  next_val int;
begin
  next_val := nextval('lead_id_seq');
  return 'LEAD-' || to_char(now(), 'YYYY') || '-' || lpad(next_val::text, 4, '0');
end;
$$;

-- =========================================================
-- CLIENTS
-- (A client is created once a lead converts, or can exist standalone
--  for repeat business. Leads reference clients optionally.)
-- =========================================================

create table public.clients (
  id uuid primary key default uuid_generate_v4(),
  client_name text not null,
  company_name text,
  country text,
  city text,
  phone text,
  whatsapp text,
  email text,
  website text,
  is_repeat_client boolean not null default false,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_clients_company on public.clients (company_name);
create index idx_clients_country on public.clients (country);

-- =========================================================
-- LEADS
-- =========================================================

create table public.leads (
  id uuid primary key default uuid_generate_v4(),
  lead_code text not null unique default public.generate_lead_code(),

  client_id uuid references public.clients(id) on delete set null,

  client_name text not null,
  company_name text,
  country text,
  city text,
  phone text,
  whatsapp text,
  email text,
  website text,

  source lead_source not null default 'other',
  status lead_status not null default 'new',

  assigned_to uuid references public.profiles(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,

  follow_up_date date,
  expected_close_date date,
  notes text,

  is_new_client boolean not null default true, -- drives commission eligibility later
  lost_reason text,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_leads_assigned_to on public.leads (assigned_to);
create index idx_leads_status on public.leads (status);
create index idx_leads_source on public.leads (source);
create index idx_leads_created_at on public.leads (created_at);
create index idx_leads_client_id on public.leads (client_id);
create index idx_leads_follow_up on public.leads (follow_up_date);

-- =========================================================
-- LEAD TIMELINE (full history / audit trail per lead)
-- =========================================================

create type timeline_event_type as enum (
  'status_change',
  'note_added',
  'assigned',
  'follow_up_set',
  'call',
  'whatsapp_message',
  'email_sent',
  'quote_event',
  'payment_event',
  'production_event',
  'shipping_event',
  'system'
);

create table public.lead_timeline (
  id uuid primary key default uuid_generate_v4(),
  lead_id uuid not null references public.leads(id) on delete cascade,
  event_type timeline_event_type not null,
  title text not null,
  description text,
  old_value text,
  new_value text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create index idx_timeline_lead_id on public.lead_timeline (lead_id, created_at desc);

-- =========================================================
-- CLIENT FILES (photos, videos, AI/CDR/PDF placeholders for Phase 1;
-- storage buckets wired in Phase 1, full doc mgmt expands later)
-- =========================================================

create type file_category as enum (
  'photo',
  'video',
  'design_ai',
  'design_cdr',
  'pdf',
  'invoice',
  'other'
);

create table public.client_files (
  id uuid primary key default uuid_generate_v4(),
  client_id uuid references public.clients(id) on delete cascade,
  lead_id uuid references public.leads(id) on delete cascade,
  category file_category not null default 'other',
  file_name text not null,
  storage_path text not null,
  file_size_bytes bigint,
  uploaded_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create index idx_client_files_client on public.client_files (client_id);
create index idx_client_files_lead on public.client_files (lead_id);

-- =========================================================
-- updated_at triggers
-- =========================================================

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger trg_profiles_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();

create trigger trg_clients_updated_at before update on public.clients
  for each row execute function public.set_updated_at();

create trigger trg_leads_updated_at before update on public.leads
  for each row execute function public.set_updated_at();

-- =========================================================
-- Auto-timeline trigger: log status changes + assignment changes
-- =========================================================

create or replace function public.log_lead_changes()
returns trigger
language plpgsql
as $$
begin
  if TG_OP = 'INSERT' then
    insert into public.lead_timeline (lead_id, event_type, title, description, created_by)
    values (new.id, 'system', 'Lead created', 'Lead ' || new.lead_code || ' created via ' || new.source, new.created_by);
    return new;
  end if;

  if TG_OP = 'UPDATE' then
    if old.status is distinct from new.status then
      insert into public.lead_timeline (lead_id, event_type, title, old_value, new_value, created_by)
      values (new.id, 'status_change', 'Status changed', old.status::text, new.status::text, new.assigned_to);
    end if;

    if old.assigned_to is distinct from new.assigned_to then
      insert into public.lead_timeline (lead_id, event_type, title, old_value, new_value, created_by)
      values (new.id, 'assigned', 'Lead reassigned', old.assigned_to::text, new.assigned_to::text, new.assigned_to);
    end if;

    if old.follow_up_date is distinct from new.follow_up_date then
      insert into public.lead_timeline (lead_id, event_type, title, old_value, new_value, created_by)
      values (new.id, 'follow_up_set', 'Follow-up date updated', old.follow_up_date::text, new.follow_up_date::text, new.assigned_to);
    end if;
  end if;

  return new;
end;
$$;

create trigger trg_leads_log_insert
  after insert on public.leads
  for each row execute function public.log_lead_changes();

create trigger trg_leads_log_update
  after update on public.leads
  for each row execute function public.log_lead_changes();

-- =========================================================
-- Auto-create profile row when a new auth user signs up
-- (role defaults to 'sales'; owner promotes manually via Owner Panel)
-- =========================================================

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, email, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
    new.email,
    'sales'
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
