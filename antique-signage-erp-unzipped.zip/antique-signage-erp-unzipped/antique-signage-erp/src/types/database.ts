// =========================================================
// Phase 1 + Phase 2 types.
// Phase 1 fields/enums are kept as-is for backward compatibility;
// Phase 2 adds new values additively (see migrations 0004+).
// =========================================================

export type UserRole =
  | "owner" // legacy, treated as admin
  | "admin"
  | "sales"
  | "production"
  | "designer"
  | "accounts"
  | "packing"
  | "client";

export type LeadSource =
  | "meta_ads" // legacy
  | "organic" // legacy
  | "other"
  | "google_ads"
  | "website"
  | "whatsapp"
  | "referral"
  | "facebook_ads"
  | "instagram";

export type LeadStatus =
  // Phase 1 legacy statuses (kept so old records still render)
  | "quote_requested"
  | "quote_sent"
  | "deposit_received"
  | "confirmed"
  | "production"
  | "packing"
  | "shipping"
  | "delivered"
  | "completed"
  | "lost"
  // Shared / Phase 2 statuses
  | "new"
  | "contacted"
  | "negotiation"
  | "quotation_sent"
  | "follow_up"
  | "closed_won"
  | "closed_lost"
  | "repeat_client";

export const LEAD_STATUS_LABELS: Record<LeadStatus, string> = {
  quote_requested: "Quote Requested (legacy)",
  quote_sent: "Quote Sent (legacy)",
  deposit_received: "Deposit Received (legacy)",
  confirmed: "Confirmed (legacy)",
  production: "Production (legacy)",
  packing: "Packing (legacy)",
  shipping: "Shipping (legacy)",
  delivered: "Delivered (legacy)",
  completed: "Completed (legacy)",
  lost: "Lost (legacy)",
  new: "New",
  contacted: "Contacted",
  negotiation: "Negotiation",
  quotation_sent: "Quotation Sent",
  follow_up: "Follow Up",
  closed_won: "Won",
  closed_lost: "Lost",
  repeat_client: "Repeat Client"
};

export const ACTIVE_LEAD_STATUSES: LeadStatus[] = [
  "new",
  "contacted",
  "quotation_sent",
  "follow_up",
  "closed_won",
  "closed_lost",
  "repeat_client"
];

export const LEAD_SOURCE_LABELS: Record<LeadSource, string> = {
  meta_ads: "Meta Ads (legacy)",
  organic: "Organic (legacy)",
  other: "Other",
  google_ads: "Google Ads",
  website: "Website",
  whatsapp: "WhatsApp",
  referral: "Referral",
  facebook_ads: "Facebook Ads",
  instagram: "Instagram"
};

export const ACTIVE_LEAD_SOURCES: LeadSource[] = [
  "whatsapp",
  "facebook_ads",
  "google_ads",
  "instagram",
  "website",
  "referral"
];

export interface Profile {
  id: string;
  full_name: string;
  email: string;
  phone: string | null;
  role: UserRole;
  is_active: boolean;
  avatar_url: string | null;
  hire_date: string | null;
  base_salary: number | null;
  client_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface Client {
  id: string;
  client_name: string;
  company_name: string | null;
  country: string | null;
  city: string | null;
  phone: string | null;
  whatsapp: string | null;
  email: string | null;
  website: string | null;
  is_repeat_client: boolean;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface Lead {
  id: string;
  lead_code: string;
  client_id: string | null;
  client_name: string;
  company_name: string | null;
  country: string | null;
  city: string | null;
  phone: string | null;
  whatsapp: string | null;
  email: string | null;
  website: string | null;
  source: LeadSource;
  status: LeadStatus;
  assigned_to: string | null;
  created_by: string | null;
  follow_up_date: string | null;
  expected_close_date: string | null;
  notes: string | null;
  is_new_client: boolean;
  lost_reason: string | null;
  phone_visible_to_assignee: boolean;
  next_action: string | null;
  created_at: string;
  updated_at: string;
}

export type TimelineEventType =
  | "status_change"
  | "note_added"
  | "assigned"
  | "follow_up_set"
  | "call"
  | "whatsapp_message"
  | "email_sent"
  | "quote_event"
  | "payment_event"
  | "production_event"
  | "shipping_event"
  | "system";

export interface LeadTimelineEntry {
  id: string;
  lead_id: string;
  event_type: TimelineEventType;
  title: string;
  description: string | null;
  old_value: string | null;
  new_value: string | null;
  created_by: string | null;
  created_at: string;
}

// =========================================================
// Phase 2: Quotations
// =========================================================

export type QuotationStatus = "draft" | "sent" | "approved" | "rejected";

export interface Quotation {
  id: string;
  quotation_number: string;
  lead_id: string | null;
  client_name: string;
  company_name: string | null;
  country: string | null;
  email: string | null;
  phone: string | null;
  shipping_included: boolean;
  subtotal: number;
  discount_percentage: number;
  discount_amount: number;
  tax_percentage: number;
  tax_amount: number;
  shipping_cost: number;
  total_amount: number;
  status: QuotationStatus;
  notes: string | null;
  created_by: string | null;
  approved_by: string | null;
  approved_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface QuotationItem {
  id: string;
  quotation_id: string;
  sign_type: string;
  size: string | null;
  material: string | null;
  lighting_type: string | null;
  quantity: number;
  unit_price: number;
  line_total: number;
  sort_order: number;
  created_at: string;
}

export const QUOTATION_STATUS_LABELS: Record<QuotationStatus, string> = {
  draft: "Draft",
  sent: "Sent",
  approved: "Approved",
  rejected: "Rejected"
};

// =========================================================
// Phase 2: Projects / Production
// =========================================================

export type ProjectStage =
  | "design_pending"
  | "design_approved"
  | "material_purchase" // legacy
  | "cnc_laser_cutting"
  | "letter_bending" // legacy
  | "welding_fabrication" // legacy
  | "acrylic_fabrication"
  | "led_wiring"
  | "powder_coating"
  | "assembly"
  | "testing"
  | "packing"
  | "ready_to_ship" // legacy
  | "shipped"
  | "delivered" // legacy
  | "completed"; // legacy

export const PROJECT_STAGE_LABELS: Record<ProjectStage, string> = {
  design_pending: "Design",
  design_approved: "Approval",
  material_purchase: "Material Purchase (legacy)",
  cnc_laser_cutting: "CNC / Laser",
  letter_bending: "Letter Bending (legacy)",
  welding_fabrication: "Welding / Fabrication (legacy)",
  acrylic_fabrication: "Acrylic",
  led_wiring: "LED",
  powder_coating: "Powder Coating",
  assembly: "Assembly",
  testing: "QC",
  packing: "Packing",
  ready_to_ship: "Ready to Ship (legacy)",
  shipped: "Shipping",
  delivered: "Delivered (legacy)",
  completed: "Completed (legacy)"
};

// The exact 10-stage flow requested: Design → Approval → CNC/Laser →
// Acrylic → LED → Powder Coating → Assembly → QC → Packing → Shipping
export const PROJECT_STAGE_ORDER: ProjectStage[] = [
  "design_pending",
  "design_approved",
  "cnc_laser_cutting",
  "acrylic_fabrication",
  "led_wiring",
  "powder_coating",
  "assembly",
  "testing",
  "packing",
  "shipped"
];

export interface Project {
  id: string;
  project_code: string;
  quotation_id: string | null;
  lead_id: string | null;
  client_name: string;
  company_name: string | null;
  country: string | null;
  current_stage: ProjectStage;
  stage_assignee: string | null;
  stage_due_date: string | null;
  expected_delivery_date: string | null;
  internal_notes: string | null;
  sale_amount: number;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface ProjectStageHistoryEntry {
  id: string;
  project_id: string;
  stage: ProjectStage;
  assigned_to: string | null;
  due_date: string | null;
  notes: string | null;
  changed_by: string | null;
  created_at: string;
}

export type ProjectFileCategory =
  | "design"
  | "photo"
  | "video"
  | "invoice"
  | "shipping_doc"
  | "packing_photo"
  | "tracking_receipt"
  | "other";

export interface ProjectFile {
  id: string;
  project_id: string;
  category: ProjectFileCategory;
  file_name: string;
  storage_path: string;
  uploaded_by: string | null;
  created_at: string;
}

// =========================================================
// Phase 2: Commission
// =========================================================

export type CommissionStatus = "pending" | "approved" | "paid" | "rejected";
export type CommissionEligibility = "new_client" | "repeat_client" | "admin_review";

export interface Commission {
  id: string;
  lead_id: string | null;
  project_id: string | null;
  employee_id: string;
  sale_amount: number;
  calculated_amount: number;
  override_amount: number | null;
  final_amount: number;
  status: CommissionStatus;
  eligibility: CommissionEligibility;
  notes: string | null;
  approved_by: string | null;
  approved_at: string | null;
  created_at: string;
  updated_at: string;
}

// =========================================================
// Phase 2: Expenses
// =========================================================

export type ExpenseCategory =
  | "material"
  | "acrylic"
  | "acm"
  | "stainless_steel"
  | "labor"
  | "powder_coating"
  | "led_power_supply"
  | "packing"
  | "shipping"
  | "ads"
  | "other";

export const EXPENSE_CATEGORY_LABELS: Record<ExpenseCategory, string> = {
  material: "Material Cost (General)",
  acrylic: "Acrylic",
  acm: "ACM",
  stainless_steel: "Stainless Steel",
  labor: "Labor Cost",
  powder_coating: "Powder Coating",
  led_power_supply: "LEDs / Power Supply",
  packing: "Packing",
  shipping: "Shipping",
  ads: "Ads Cost",
  other: "Other Expense"
};

export interface ProjectExpense {
  id: string;
  project_id: string;
  category: ExpenseCategory;
  amount: number;
  description: string | null;
  created_by: string | null;
  created_at: string;
}

export interface ProjectProfitSummary {
  project_id: string;
  project_code: string;
  client_name: string;
  sale_amount: number;
  total_cost: number;
  gross_profit: number;
  profit_percentage: number;
}

// =========================================================
// Phase 2: Shipping
// =========================================================

export type DutyStatus = "duty_paid" | "duty_unpaid" | "not_applicable";

export interface Shipment {
  id: string;
  project_id: string;
  country: string;
  courier: string | null;
  box_length_cm: number | null;
  box_width_cm: number | null;
  box_height_cm: number | null;
  actual_weight_kg: number | null;
  volumetric_weight_kg: number | null;
  tracking_number: string | null;
  shipping_cost: number;
  duty_status: DutyStatus;
  delivery_status: string;
  rate_pkr_per_kg: number | null;
  oversize_charge: number;
  overweight_charge: number;
  total_shipping_cost: number;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface ShipmentBox {
  id: string;
  shipment_id: string;
  box_number: number;
  length_cm: number;
  width_cm: number;
  height_cm: number;
  actual_weight_kg: number;
  volumetric_weight_kg: number | null;
  chargeable_weight_kg: number | null;
  is_oversize: boolean;
  is_overweight: boolean;
  created_at: string;
}

export interface ShippingRate {
  country: string;
  rate_pkr_per_kg: number;
  duty_status: DutyStatus;
  updated_at: string;
}

// =========================================================
// Phase 3: Payments
// =========================================================

export type PaymentType = "advance" | "balance" | "full" | "refund";
export type PaymentMethod = "cash" | "bank_transfer" | "card" | "wire_transfer" | "other";

export const PAYMENT_TYPE_LABELS: Record<PaymentType, string> = {
  advance: "Advance",
  balance: "Balance",
  full: "Full Payment",
  refund: "Refund"
};

export const PAYMENT_METHOD_LABELS: Record<PaymentMethod, string> = {
  cash: "Cash",
  bank_transfer: "Bank Transfer",
  card: "Card",
  wire_transfer: "Wire Transfer",
  other: "Other"
};

export interface Payment {
  id: string;
  project_id: string;
  payment_type: PaymentType;
  amount: number;
  payment_method: PaymentMethod;
  proof_storage_path: string | null;
  notes: string | null;
  received_by: string | null;
  created_at: string;
}

export interface ProjectPaymentSummary {
  project_id: string;
  project_code: string;
  sale_amount: number;
  total_received: number;
  balance_pending: number;
}

// =========================================================
// Phase 3: Design Approvals
// =========================================================

export type DesignApprovalStatus = "pending" | "changes_required" | "approved";

export const DESIGN_APPROVAL_STATUS_LABELS: Record<DesignApprovalStatus, string> = {
  pending: "Pending Review",
  changes_required: "Changes Required",
  approved: "Approved"
};

export interface DesignApproval {
  id: string;
  project_id: string;
  status: DesignApprovalStatus;
  revision_notes: string | null;
  approved_at: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

// =========================================================
// Phase 3: Inventory
// =========================================================

export type InventoryCategory =
  | "acm_sheet"
  | "acrylic_sheet"
  | "stainless_steel"
  | "led_module"
  | "power_supply"
  | "wire"
  | "packing_material"
  | "other";

export const INVENTORY_CATEGORY_LABELS: Record<InventoryCategory, string> = {
  acm_sheet: "ACM Sheets",
  acrylic_sheet: "Acrylic Sheets",
  stainless_steel: "Stainless Steel",
  led_module: "LED Modules",
  power_supply: "Power Supplies",
  wire: "Wires",
  packing_material: "Packing Materials",
  other: "Other"
};

export type InventoryTransactionType = "in" | "out";

export interface InventoryItem {
  id: string;
  name: string;
  category: InventoryCategory;
  unit: string;
  current_stock: number;
  low_stock_threshold: number;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface InventoryTransaction {
  id: string;
  item_id: string;
  transaction_type: InventoryTransactionType;
  quantity: number;
  project_id: string | null;
  notes: string | null;
  created_by: string | null;
  created_at: string;
}

export interface ActivityLogEntry {
  id: string;
  actor_id: string | null;
  action: string;
  entity_type: string;
  entity_id: string | null;
  details: Record<string, unknown> | null;
  created_at: string;
}

// =========================================================
// Phase 4: Tasks
// =========================================================

export type TaskPriority = "low" | "medium" | "high" | "urgent";
export type TaskStatus = "todo" | "in_progress" | "done" | "blocked";

export const TASK_PRIORITY_LABELS: Record<TaskPriority, string> = {
  low: "Low",
  medium: "Medium",
  high: "High",
  urgent: "Urgent"
};

export const TASK_STATUS_LABELS: Record<TaskStatus, string> = {
  todo: "To Do",
  in_progress: "In Progress",
  done: "Done",
  blocked: "Blocked"
};

export interface Task {
  id: string;
  title: string;
  description: string | null;
  project_id: string | null;
  assigned_to: string | null;
  priority: TaskPriority;
  status: TaskStatus;
  due_date: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface TaskComment {
  id: string;
  task_id: string;
  comment: string;
  created_by: string | null;
  created_at: string;
}

export interface TaskFile {
  id: string;
  task_id: string;
  file_name: string;
  storage_path: string;
  uploaded_by: string | null;
  created_at: string;
}

// =========================================================
// Phase 4: Suppliers & Purchase Orders
// =========================================================

export interface Supplier {
  id: string;
  name: string;
  contact_person: string | null;
  phone: string | null;
  email: string | null;
  address: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export type PoStatus = "draft" | "ordered" | "received" | "cancelled";

export const PO_STATUS_LABELS: Record<PoStatus, string> = {
  draft: "Draft",
  ordered: "Ordered",
  received: "Received",
  cancelled: "Cancelled"
};

export interface PurchaseOrder {
  id: string;
  po_number: string;
  supplier_id: string | null;
  status: PoStatus;
  order_date: string;
  expected_date: string | null;
  total_amount: number;
  notes: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface PurchaseOrderItem {
  id: string;
  po_id: string;
  inventory_item_id: string | null;
  description: string;
  quantity: number;
  unit_cost: number;
  line_total: number;
  created_at: string;
}

// =========================================================
// Phase 4: Integrations (placeholders for future API wiring)
// =========================================================

export interface IntegrationConfig {
  id: string;
  service_name: string;
  display_name: string;
  api_key: string | null;
  additional_config: Record<string, unknown> | null;
  is_enabled: boolean;
  updated_at: string;
}

// =========================================================
// Phase 4: Ad Spend (for Ads Spend vs Sales report)
// =========================================================

export interface AdSpend {
  id: string;
  platform: string;
  spend_date: string;
  amount: number;
  notes: string | null;
  created_by: string | null;
  created_at: string;
}

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: Profile;
        Insert: Partial<Profile> & { id: string; full_name: string; email: string };
        Update: Partial<Profile>;
      };
      clients: {
        Row: Client;
        Insert: Partial<Client> & { client_name: string };
        Update: Partial<Client>;
      };
      leads: {
        Row: Lead;
        Insert: Partial<Lead> & { client_name: string };
        Update: Partial<Lead>;
      };
      lead_timeline: {
        Row: LeadTimelineEntry;
        Insert: Partial<LeadTimelineEntry> & {
          lead_id: string;
          event_type: TimelineEventType;
          title: string;
        };
        Update: Partial<LeadTimelineEntry>;
      };
      quotations: {
        Row: Quotation;
        Insert: Partial<Quotation> & { client_name: string };
        Update: Partial<Quotation>;
      };
      quotation_items: {
        Row: QuotationItem;
        Insert: Partial<QuotationItem> & { quotation_id: string; sign_type: string };
        Update: Partial<QuotationItem>;
      };
      projects: {
        Row: Project;
        Insert: Partial<Project> & { client_name: string };
        Update: Partial<Project>;
      };
      project_stage_history: {
        Row: ProjectStageHistoryEntry;
        Insert: Partial<ProjectStageHistoryEntry> & { project_id: string; stage: ProjectStage };
        Update: Partial<ProjectStageHistoryEntry>;
      };
      project_files: {
        Row: ProjectFile;
        Insert: Partial<ProjectFile> & { project_id: string; file_name: string; storage_path: string };
        Update: Partial<ProjectFile>;
      };
      commissions: {
        Row: Commission;
        Insert: Partial<Commission> & { employee_id: string };
        Update: Partial<Commission>;
      };
      project_expenses: {
        Row: ProjectExpense;
        Insert: Partial<ProjectExpense> & { project_id: string; category: ExpenseCategory };
        Update: Partial<ProjectExpense>;
      };
      shipments: {
        Row: Shipment;
        Insert: Partial<Shipment> & { project_id: string; country: string };
        Update: Partial<Shipment>;
      };
      shipment_boxes: {
        Row: ShipmentBox;
        Insert: Partial<ShipmentBox> & {
          shipment_id: string;
          length_cm: number;
          width_cm: number;
          height_cm: number;
          actual_weight_kg: number;
        };
        Update: Partial<ShipmentBox>;
      };
      shipping_rates: {
        Row: ShippingRate;
        Insert: Partial<ShippingRate> & { country: string; rate_pkr_per_kg: number };
        Update: Partial<ShippingRate>;
      };
      payments: {
        Row: Payment;
        Insert: Partial<Payment> & { project_id: string; payment_type: PaymentType; amount: number };
        Update: Partial<Payment>;
      };
      design_approvals: {
        Row: DesignApproval;
        Insert: Partial<DesignApproval> & { project_id: string };
        Update: Partial<DesignApproval>;
      };
      inventory_items: {
        Row: InventoryItem;
        Insert: Partial<InventoryItem> & { name: string; category: InventoryCategory };
        Update: Partial<InventoryItem>;
      };
      inventory_transactions: {
        Row: InventoryTransaction;
        Insert: Partial<InventoryTransaction> & {
          item_id: string;
          transaction_type: InventoryTransactionType;
          quantity: number;
        };
        Update: Partial<InventoryTransaction>;
      };
      tasks: {
        Row: Task;
        Insert: Partial<Task> & { title: string };
        Update: Partial<Task>;
      };
      task_comments: {
        Row: TaskComment;
        Insert: Partial<TaskComment> & { task_id: string; comment: string };
        Update: Partial<TaskComment>;
      };
      task_files: {
        Row: TaskFile;
        Insert: Partial<TaskFile> & { task_id: string; file_name: string; storage_path: string };
        Update: Partial<TaskFile>;
      };
      suppliers: {
        Row: Supplier;
        Insert: Partial<Supplier> & { name: string };
        Update: Partial<Supplier>;
      };
      purchase_orders: {
        Row: PurchaseOrder;
        Insert: Partial<PurchaseOrder>;
        Update: Partial<PurchaseOrder>;
      };
      purchase_order_items: {
        Row: PurchaseOrderItem;
        Insert: Partial<PurchaseOrderItem> & { po_id: string; description: string; quantity: number };
        Update: Partial<PurchaseOrderItem>;
      };
      integrations_config: {
        Row: IntegrationConfig;
        Insert: Partial<IntegrationConfig> & { service_name: string; display_name: string };
        Update: Partial<IntegrationConfig>;
      };
      ad_spend: {
        Row: AdSpend;
        Insert: Partial<AdSpend> & { platform: string; amount: number };
        Update: Partial<AdSpend>;
      };
      activity_log: {
        Row: ActivityLogEntry;
        Insert: Partial<ActivityLogEntry> & { action: string; entity_type: string };
        Update: Partial<ActivityLogEntry>;
      };
    };
    Views: {
      project_profit_summary: {
        Row: ProjectProfitSummary;
      };
      project_payment_summary: {
        Row: ProjectPaymentSummary;
      };
      inventory_low_stock: {
        Row: InventoryItem;
      };
    };
  };
}
