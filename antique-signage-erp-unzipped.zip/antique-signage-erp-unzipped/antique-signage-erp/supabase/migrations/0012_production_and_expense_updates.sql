-- =========================================================
-- Phase 3 — Migration 0012
-- Production workflow refinements + expanded expense categories
-- =========================================================

-- Add the final "Completed" stage after Delivered
alter type project_stage add value if not exists 'completed';

-- Per-stage due date, tracked on the project's current stage
-- (the running history in project_stage_history already logs each
-- transition; this adds a due date to the *active* stage)
alter table public.projects
  add column if not exists stage_due_date date;

alter table public.project_stage_history
  add column if not exists due_date date;

-- Expand expense categories: split Material into Acrylic / ACM / Stainless Steel
-- for accurate signage costing (keeps 'material' for backward compatibility
-- with any Phase 2 expenses already recorded).
alter type expense_category add value if not exists 'acrylic';
alter type expense_category add value if not exists 'acm';
alter type expense_category add value if not exists 'stainless_steel';
