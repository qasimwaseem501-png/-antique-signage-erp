"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile } from "@/lib/auth";

export async function createProjectTask(
  projectId: string,
  title: string,
  assignedTo: string | null,
  dueDate: string | null
) {
  const profile = await getCurrentProfile();
  const supabase = createClient();

  const { error } = await supabase.from("tasks").insert({
    title,
    project_id: projectId,
    assigned_to: assignedTo,
    due_date: dueDate,
    created_by: profile.id
  });

  if (error) throw new Error(error.message);
  revalidatePath(`/projects/${projectId}`);
  revalidatePath("/tasks");
}

export async function updateTaskStatus(taskId: string, status: string, projectId: string) {
  const supabase = createClient();
  const { error } = await supabase.from("tasks").update({ status }).eq("id", taskId);
  if (error) throw new Error(error.message);
  revalidatePath(`/projects/${projectId}`);
  revalidatePath("/tasks");
}
