"use client";

import { useState, useTransition } from "react";
import { Plus, Trash2 } from "lucide-react";
import { createPurchaseOrder, type PoItemInput } from "../../actions";
import type { InventoryItem, Supplier } from "@/types/database";

const emptyItem = (): PoItemInput => ({ description: "", inventory_item_id: null, quantity: 1, unit_cost: 0 });

export function PurchaseOrderForm({ suppliers, inventoryItems }: { suppliers: Supplier[]; inventoryItems: InventoryItem[] }) {
  const [supplierId, setSupplierId] = useState("");
  const [expectedDate, setExpectedDate] = useState("");
  const [notes, setNotes] = useState("");
  const [items, setItems] = useState<PoItemInput[]>([emptyItem()]);
  const [error, setError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  function updateItem(index: number, patch: Partial<PoItemInput>) {
    setItems((prev) => prev.map((item, i) => (i === index ? { ...item, ...patch } : item)));
  }

  const total = items.reduce((sum, item) => sum + item.quantity * item.unit_cost, 0);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!supplierId) {
      setError("Select a supplier.");
      return;
    }
    startTransition(async () => {
      try {
        await createPurchaseOrder({ supplier_id: supplierId, expected_date: expectedDate, notes, items });
      } catch (err) {
        if (err instanceof Error && err.message === "NEXT_REDIRECT") throw err;
        setError(err instanceof Error ? err.message : "Failed to create PO");
      }
    });
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error && <div className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>}

      <div className="card space-y-4 p-6">
        <div>
          <label className="label">Supplier *</label>
          <select className="input" value={supplierId} onChange={(e) => setSupplierId(e.target.value)} required>
            <option value="" disabled>Select supplier</option>
            {suppliers.map((s) => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="label">Expected Date</label>
          <input type="date" className="input" value={expectedDate} onChange={(e) => setExpectedDate(e.target.value)} />
        </div>
      </div>

      <div className="card p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-sm font-semibold text-slate-900">Items</h2>
          <button type="button" onClick={() => setItems((prev) => [...prev, emptyItem()])} className="btn-secondary">
            <Plus className="h-4 w-4" />
            Add Item
          </button>
        </div>
        <div className="space-y-3">
          {items.map((item, index) => (
            <div key={index} className="rounded-lg border border-slate-200 p-3">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-4">
                <input
                  className="input sm:col-span-2"
                  placeholder="Description"
                  value={item.description}
                  onChange={(e) => updateItem(index, { description: e.target.value })}
                />
                <select
                  className="input"
                  value={item.inventory_item_id ?? ""}
                  onChange={(e) => updateItem(index, { inventory_item_id: e.target.value || null })}
                >
                  <option value="">Link to stock item (optional)</option>
                  {inventoryItems.map((inv) => (
                    <option key={inv.id} value={inv.id}>{inv.name}</option>
                  ))}
                </select>
                <div className="flex gap-2">
                  <input
                    type="number"
                    min={0}
                    className="input"
                    placeholder="Qty"
                    value={item.quantity || ""}
                    onChange={(e) => updateItem(index, { quantity: Number(e.target.value) })}
                  />
                  <input
                    type="number"
                    min={0}
                    step="0.01"
                    className="input"
                    placeholder="Unit Cost"
                    value={item.unit_cost || ""}
                    onChange={(e) => updateItem(index, { unit_cost: Number(e.target.value) })}
                  />
                  {items.length > 1 && (
                    <button type="button" onClick={() => setItems((prev) => prev.filter((_, i) => i !== index))} className="text-red-500">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
        <p className="mt-4 text-right text-lg font-bold text-slate-900">Total: ${total.toLocaleString()}</p>
      </div>

      <div>
        <label className="label">Notes</label>
        <textarea className="input" rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} />
      </div>

      <div className="flex justify-end">
        <button type="submit" disabled={isPending} className="btn-primary">
          {isPending ? "Creating..." : "Create Purchase Order"}
        </button>
      </div>
    </form>
  );
}
