"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";

export async function updateIntegration(serviceName: string, apiKey: string, isEnabled: boolean) {
  const supabase = createClient();
  const { error } = await supabase
    .from("integrations_config")
    .update({ api_key: apiKey || null, is_enabled: isEnabled })
    .eq("service_name", serviceName);
  if (error) throw new Error(error.message);
  revalidatePath("/settings");
}
