-- =========================================================
-- Storage Buckets
-- One private bucket for all company files (photos, videos,
-- design files, invoices). Path convention enforces scoping:
--   client-files/{lead_id}/{filename}
-- =========================================================

insert into storage.buckets (id, name, public)
values ('client-files', 'client-files', false)
on conflict (id) do nothing;

-- Only authenticated users can read files for leads they're allowed to see
create policy storage_select_scoped
  on storage.objects for select
  using (
    bucket_id = 'client-files'
    and (
      public.is_owner()
      or exists (
        select 1 from public.leads l
        where l.id::text = (storage.foldername(name))[1]
        and l.assigned_to = auth.uid()
      )
    )
  );

create policy storage_insert_scoped
  on storage.objects for insert
  with check (
    bucket_id = 'client-files'
    and (
      public.is_owner()
      or exists (
        select 1 from public.leads l
        where l.id::text = (storage.foldername(name))[1]
        and l.assigned_to = auth.uid()
      )
    )
  );

-- Employees cannot delete company files — Owner only
create policy storage_delete_owner_only
  on storage.objects for delete
  using (bucket_id = 'client-files' and public.is_owner());
