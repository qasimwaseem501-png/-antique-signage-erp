import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile, isAdmin } from "@/lib/auth";
import { ProjectStagePanel, ExpenseForm } from "@/components/projects/ProjectStagePanel";
import { ProjectFileUpload } from "@/components/projects/ProjectFileUpload";
import { PaymentPanel } from "@/components/payments/PaymentPanel";
import { DesignApprovalPanel } from "@/components/projects/DesignApprovalPanel";
import { ProjectTasksPanel } from "@/components/projects/ProjectTasksPanel";
import {
  EXPENSE_CATEGORY_LABELS,
  type Project,
  type ProjectExpense,
  type ProjectFile,
  type Profile,
  type Payment,
  type ProjectPaymentSummary,
  type DesignApproval,
  type Task
} from "@/types/database";

export default async function ProjectDetailPage({ params }: { params: { id: string } }) {
  const profile = await getCurrentProfile();
  const supabase = createClient();
  const admin = isAdmin(profile);

  const { data: project } = await supabase.from("projects").select("*").eq("id", params.id).single();
  if (!project) notFound();
  const typedProject = project as Project;

  const [{ data: expensesData }, { data: filesData }, { data: teamData }, { data: paymentsData }, { data: paymentSummaryData }, { data: designData }, { data: tasksData }] = await Promise.all([
    supabase.from("project_expenses").select("*").eq("project_id", params.id).order("created_at", { ascending: false }),
    supabase.from("project_files").select("*").eq("project_id", params.id).order("created_at", { ascending: false }),
    supabase.from("profiles").select("*").eq("is_active", true).neq("role", "client"),
    supabase.from("payments").select("*").eq("project_id", params.id).order("created_at", { ascending: false }),
    supabase.from("project_payment_summary").select("*").eq("project_id", params.id).maybeSingle(),
    supabase.from("design_approvals").select("*").eq("project_id", params.id).order("created_at", { ascending: false }),
    supabase.from("tasks").select("*").eq("project_id", params.id).order("created_at", { ascending: false })
  ]);

  const expenses = (expensesData ?? []) as ProjectExpense[];
  const files = (filesData ?? []) as ProjectFile[];
  const team = (teamData ?? []) as Profile[];
  const payments = (paymentsData ?? []) as Payment[];
  const paymentSummary = (paymentSummaryData ?? undefined) as ProjectPaymentSummary | undefined;
  const designHistory = (designData ?? []) as DesignApproval[];
  const tasks = (tasksData ?? []) as Task[];

  const totalCost = expenses.reduce((sum, e) => sum + e.amount, 0);
  const grossProfit = typedProject.sale_amount - totalCost;
  const profitPct = typedProject.sale_amount > 0 ? (grossProfit / typedProject.sale_amount) * 100 : 0;

  const canSeeFinancials = admin || profile.role === "accounts";
  const canManagePayments = admin || profile.role === "accounts";
  const canManageDesign = admin || profile.role === "designer";
  const canEditStage =
    admin ||
    ["designer", "production", "packing"].includes(profile.role);

  return (
    <div>
      <Link href="/projects" className="mb-4 inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-900">
        <ArrowLeft className="h-4 w-4" />
        Back to Projects
      </Link>

      <div className="mb-6">
        <p className="text-sm font-medium text-brand-blue-600">{typedProject.project_code}</p>
        <h1 className="text-2xl font-bold text-slate-900">{typedProject.client_name}</h1>
        {typedProject.company_name && <p className="text-sm text-slate-500">{typedProject.company_name}</p>}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-1">
          <ProjectStagePanel
            projectId={typedProject.id}
            currentStage={typedProject.current_stage}
            stageAssignee={typedProject.stage_assignee}
            team={team}
            canEdit={canEditStage}
          />

          <div className="card p-5">
            <h3 className="mb-3 text-sm font-semibold text-slate-900">Delivery</h3>
            <dl className="space-y-2 text-sm">
              <div className="flex justify-between">
                <dt className="text-slate-500">Expected Date</dt>
                <dd className="font-medium text-slate-900">{typedProject.expected_delivery_date ?? "—"}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-500">Country</dt>
                <dd className="font-medium text-slate-900">{typedProject.country ?? "—"}</dd>
              </div>
            </dl>
            {typedProject.internal_notes && (
              <p className="mt-3 border-t border-slate-100 pt-3 text-sm text-slate-600">
                {typedProject.internal_notes}
              </p>
            )}
          </div>

          <DesignApprovalPanel projectId={typedProject.id} history={designHistory} canManage={canManageDesign} />

          {canSeeFinancials && (
            <div className="card p-5">
              <h3 className="mb-3 text-sm font-semibold text-slate-900">Profit Summary</h3>
              <dl className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <dt className="text-slate-500">Sale Amount</dt>
                  <dd className="font-medium text-slate-900">${typedProject.sale_amount.toLocaleString()}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-slate-500">Total Cost</dt>
                  <dd className="font-medium text-slate-900">${totalCost.toLocaleString()}</dd>
                </div>
                <div className="flex justify-between border-t border-slate-100 pt-2">
                  <dt className="font-medium text-slate-700">Gross Profit</dt>
                  <dd className={`font-bold ${grossProfit >= 0 ? "text-emerald-600" : "text-red-600"}`}>
                    ${grossProfit.toLocaleString()}
                  </dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-slate-500">Profit %</dt>
                  <dd className="font-medium text-slate-900">{profitPct.toFixed(1)}%</dd>
                </div>
              </dl>
            </div>
          )}
        </div>

        <div className="space-y-6 lg:col-span-2">
          <PaymentPanel projectId={typedProject.id} payments={payments} summary={paymentSummary} canManage={canManagePayments} />

          <div className="card p-5">
            <h3 className="mb-3 text-sm font-semibold text-slate-900">Files</h3>
            <ProjectFileUpload projectId={typedProject.id} />
            <div className="mt-4 space-y-2">
              {files.map((f) => (
                <div key={f.id} className="flex items-center justify-between rounded-lg border border-slate-100 px-3 py-2 text-sm">
                  <span className="text-slate-700">{f.file_name}</span>
                  <span className="text-xs uppercase text-slate-400">{f.category.replace("_", " ")}</span>
                </div>
              ))}
              {files.length === 0 && <p className="text-sm text-slate-500">No files uploaded yet.</p>}
            </div>
          </div>

          {canSeeFinancials && (
            <div className="card p-5">
              <h3 className="mb-3 text-sm font-semibold text-slate-900">Expenses</h3>
              <ExpenseForm projectId={typedProject.id} />
              <div className="mt-4 divide-y divide-slate-100">
                {expenses.map((e) => (
                  <div key={e.id} className="flex items-center justify-between py-2 text-sm">
                    <div>
                      <p className="font-medium text-slate-900">{EXPENSE_CATEGORY_LABELS[e.category]}</p>
                      {e.description && <p className="text-xs text-slate-500">{e.description}</p>}
                    </div>
                    <span className="font-medium text-slate-900">${e.amount.toLocaleString()}</span>
                  </div>
                ))}
                {expenses.length === 0 && <p className="py-2 text-sm text-slate-500">No expenses logged yet.</p>}
              </div>
            </div>
          )}

          <ProjectTasksPanel projectId={typedProject.id} tasks={tasks} team={team} />
        </div>
      </div>
    </div>
  );
}
