import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile, isAdmin } from "@/lib/auth";
import { StageBadge } from "@/components/projects/StageBadge";
import { PROJECT_STAGE_LABELS, type Project, type ProjectStage } from "@/types/database";

const DESIGN_STAGES: ProjectStage[] = ["design_pending", "design_approved"];
const PRODUCTION_STAGES: ProjectStage[] = [
  "cnc_laser_cutting",
  "acrylic_fabrication",
  "led_wiring",
  "powder_coating",
  "assembly",
  "testing"
];
const PACKING_STAGES: ProjectStage[] = ["packing", "shipped"];

export default async function ProductionPage() {
  const profile = await getCurrentProfile();
  const admin = isAdmin(profile);
  const supabase = createClient();

  let relevantStages: ProjectStage[] = [...DESIGN_STAGES, ...PRODUCTION_STAGES, ...PACKING_STAGES];
  if (profile.role === "designer") relevantStages = DESIGN_STAGES;
  if (profile.role === "production") relevantStages = PRODUCTION_STAGES;
  if (profile.role === "packing") relevantStages = PACKING_STAGES;

  const { data } = await supabase
    .from("projects")
    .select("*")
    .in("current_stage", relevantStages)
    .order("expected_delivery_date", { ascending: true, nullsFirst: false });

  const projects = (data ?? []) as Project[];

  const grouped = relevantStages.reduce<Record<string, Project[]>>((acc, stage) => {
    acc[stage] = projects.filter((p) => p.current_stage === stage);
    return acc;
  }, {});

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Production</h1>
        <p className="text-sm text-slate-500">
          {admin ? "All active projects by stage" : `Projects in your workflow (${profile.role})`}
        </p>
      </div>

      <div className="flex gap-4 overflow-x-auto pb-4">
        {relevantStages.map((stage) => (
          <div key={stage} className="w-72 shrink-0">
            <div className="mb-2 flex items-center justify-between px-1">
              <h3 className="text-sm font-semibold text-slate-700">{PROJECT_STAGE_LABELS[stage]}</h3>
              <span className="text-xs text-slate-400">{grouped[stage]?.length ?? 0}</span>
            </div>
            <div className="space-y-2">
              {(grouped[stage] ?? []).map((p) => (
                <Link
                  key={p.id}
                  href={`/projects/${p.id}`}
                  className="card block p-3 transition-shadow hover:shadow-elevated"
                >
                  <p className="text-sm font-medium text-slate-900">{p.project_code}</p>
                  <p className="text-xs text-slate-500">{p.client_name}</p>
                  {p.expected_delivery_date && (
                    <p className="mt-1 text-xs text-orange-600">Due {p.expected_delivery_date}</p>
                  )}
                  <div className="mt-2">
                    <StageBadge stage={p.current_stage} />
                  </div>
                </Link>
              ))}
              {(grouped[stage] ?? []).length === 0 && (
                <div className="rounded-lg border border-dashed border-slate-200 p-4 text-center text-xs text-slate-400">
                  Nothing here
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
