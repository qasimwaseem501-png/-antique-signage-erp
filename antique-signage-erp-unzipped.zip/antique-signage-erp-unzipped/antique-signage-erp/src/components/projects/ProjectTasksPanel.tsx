"use client";

import { useState, useTransition } from "react";
import { createProjectTask, updateTaskStatus } from "@/app/(app)/projects/taskActions";
import { PriorityBadge } from "@/components/tasks/TaskBadges";
import { TASK_STATUS_LABELS, type Profile, type Task } from "@/types/database";

export function ProjectTasksPanel({
  projectId,
  tasks,
  team
}: {
  projectId: string;
  tasks: Task[];
  team: Profile[];
}) {
  const [title, setTitle] = useState("");
  const [assignedTo, setAssignedTo] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [isPending, startTransition] = useTransition();

  function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    startTransition(async () => {
      await createProjectTask(projectId, title, assignedTo || null, dueDate || null);
      setTitle("");
      setAssignedTo("");
      setDueDate("");
    });
  }

  return (
    <div className="card p-5">
      <h3 className="mb-3 text-sm font-semibold text-slate-900">Task Assignment</h3>

      <form onSubmit={handleAdd} className="mb-4 grid grid-cols-1 gap-2 sm:grid-cols-4">
        <input
          className="input sm:col-span-2"
          placeholder="New task title..."
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <select className="input" value={assignedTo} onChange={(e) => setAssignedTo(e.target.value)}>
          <option value="">Unassigned</option>
          {team.map((m) => (
            <option key={m.id} value={m.id}>{m.full_name}</option>
          ))}
        </select>
        <div className="flex gap-2">
          <input type="date" className="input" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
          <button type="submit" disabled={isPending || !title.trim()} className="btn-primary shrink-0">Add</button>
        </div>
      </form>

      <div className="space-y-2">
        {tasks.map((task) => (
          <div key={task.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-slate-100 px-3 py-2">
            <div>
              <p className="text-sm font-medium text-slate-900">{task.title}</p>
              <p className="text-xs text-slate-500">
                {task.assigned_to ? team.find((m) => m.id === task.assigned_to)?.full_name ?? "—" : "Unassigned"}
                {task.due_date && ` · Due ${task.due_date}`}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <PriorityBadge priority={task.priority} />
              <select
                className="input max-w-[140px] py-1 text-xs"
                value={task.status}
                disabled={isPending}
                onChange={(e) => startTransition(() => updateTaskStatus(task.id, e.target.value, projectId))}
              >
                {Object.entries(TASK_STATUS_LABELS).map(([value, label]) => (
                  <option key={value} value={value}>{label}</option>
                ))}
              </select>
            </div>
          </div>
        ))}
        {tasks.length === 0 && <p className="text-sm text-slate-500">No tasks assigned to this project yet.</p>}
      </div>
    </div>
  );
}
