"use client";

import { useState, useTransition } from "react";
import { updateShippingRate } from "@/app/(app)/shipping/actions";
import type { ShippingRate } from "@/types/database";

export function ShippingRatesEditor({ rates }: { rates: ShippingRate[] }) {
  return (
    <div className="space-y-2">
      {rates.map((rate) => (
        <RateRow key={rate.country} rate={rate} />
      ))}
    </div>
  );
}

function RateRow({ rate }: { rate: ShippingRate }) {
  const [ratePkr, setRatePkr] = useState(rate.rate_pkr_per_kg);
  const [dutyStatus, setDutyStatus] = useState(rate.duty_status);
  const [isPending, startTransition] = useTransition();

  function handleSave() {
    startTransition(() => updateShippingRate(rate.country, ratePkr, dutyStatus));
  }

  return (
    <div className="flex items-center gap-3 rounded-lg border border-slate-100 p-3">
      <span className="w-24 shrink-0 text-sm font-medium text-slate-900">{rate.country}</span>
      <input
        type="number"
        className="input max-w-[120px]"
        value={ratePkr}
        onChange={(e) => setRatePkr(Number(e.target.value))}
      />
      <span className="text-xs text-slate-500">PKR/kg</span>
      <select className="input max-w-[160px]" value={dutyStatus} onChange={(e) => setDutyStatus(e.target.value as ShippingRate["duty_status"])}>
        <option value="duty_paid">Duty Paid</option>
        <option value="duty_unpaid">Non Duty Paid</option>
        <option value="not_applicable">Not Applicable</option>
      </select>
      <button onClick={handleSave} disabled={isPending} className="btn-secondary ml-auto">
        Save
      </button>
    </div>
  );
}
