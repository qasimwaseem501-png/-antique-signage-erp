"use client";

import { useTransition } from "react";
import { Download, Check, X, ArrowRight, Send } from "lucide-react";
import { updateQuotationStatus, convertQuotationToProject } from "@/app/(app)/quotations/actions";
import { generateQuotationPdf } from "@/lib/generateQuotationPdf";
import type { Quotation, QuotationItem } from "@/types/database";

export function QuotationActions({
  quotation,
  items,
  canManage
}: {
  quotation: Quotation;
  items: QuotationItem[];
  canManage: boolean;
}) {
  const [isPending, startTransition] = useTransition();

  function handleStatus(status: string) {
    startTransition(() => updateQuotationStatus(quotation.id, status));
  }

  function handleConvert() {
    startTransition(() => convertQuotationToProject(quotation.id));
  }

  return (
    <div className="flex flex-wrap gap-2">
      <button onClick={() => generateQuotationPdf(quotation, items)} className="btn-secondary">
        <Download className="h-4 w-4" />
        Download PDF
      </button>

      {canManage && quotation.status === "draft" && (
        <button onClick={() => handleStatus("sent")} disabled={isPending} className="btn-secondary">
          <Send className="h-4 w-4" />
          Mark as Sent
        </button>
      )}

      {canManage && quotation.status === "sent" && (
        <>
          <button onClick={() => handleStatus("approved")} disabled={isPending} className="btn-primary">
            <Check className="h-4 w-4" />
            Approve
          </button>
          <button onClick={() => handleStatus("rejected")} disabled={isPending} className="btn-secondary">
            <X className="h-4 w-4" />
            Reject
          </button>
        </>
      )}

      {canManage && quotation.status === "approved" && (
        <button onClick={handleConvert} disabled={isPending} className="btn-primary">
          <ArrowRight className="h-4 w-4" />
          Convert to Project
        </button>
      )}
    </div>
  );
}
