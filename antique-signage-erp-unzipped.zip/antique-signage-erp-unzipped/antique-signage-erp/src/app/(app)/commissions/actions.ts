"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile } from "@/lib/auth";

export async function updateCommissionStatus(commissionId: string, status: string) {
  const profile = await getCurrentProfile();
  const supabase = createClient();

  const update: Record<string, unknown> = { status };
  if (status === "approved") {
    update.approved_by = profile.id;
    update.approved_at = new Date().toISOString();
  }

  const { error } = await supabase.from("commissions").update(update).eq("id", commissionId);
  if (error) throw new Error(error.message);
  revalidatePath("/commissions");
}

export async function overrideCommissionAmount(commissionId: string, overrideAmount: number, notes: string) {
  const supabase = createClient();
  const { error } = await supabase
    .from("commissions")
    .update({ override_amount: overrideAmount, notes: notes || null })
    .eq("id", commissionId);
  if (error) throw new Error(error.message);
  revalidatePath("/commissions");
}
