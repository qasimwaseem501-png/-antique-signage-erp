import { PaymentForm } from "@/components/payments/PaymentForm";
import { PAYMENT_METHOD_LABELS, PAYMENT_TYPE_LABELS, type Payment, type ProjectPaymentSummary } from "@/types/database";

export function PaymentPanel({
  projectId,
  payments,
  summary,
  canManage
}: {
  projectId: string;
  payments: Payment[];
  summary: ProjectPaymentSummary | undefined;
  canManage: boolean;
}) {
  return (
    <div className="card p-5">
      <h3 className="mb-3 text-sm font-semibold text-slate-900">Payments</h3>

      {summary && (
        <div className="mb-4 grid grid-cols-2 gap-3 text-sm">
          <div>
            <p className="text-slate-500">Received</p>
            <p className="font-medium text-emerald-600">${summary.total_received.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-slate-500">Balance Pending</p>
            <p className={`font-medium ${summary.balance_pending > 0 ? "text-amber-600" : "text-slate-400"}`}>
              ${summary.balance_pending.toLocaleString()}
            </p>
          </div>
        </div>
      )}

      {canManage && (
        <div className="border-t border-slate-100 pt-4">
          <PaymentForm projectId={projectId} />
        </div>
      )}

      <div className="mt-4 space-y-2 border-t border-slate-100 pt-4">
        {payments.map((p) => (
          <div key={p.id} className="flex items-center justify-between text-sm">
            <div>
              <p className="font-medium text-slate-900">{PAYMENT_TYPE_LABELS[p.payment_type]}</p>
              <p className="text-xs text-slate-500">
                {PAYMENT_METHOD_LABELS[p.payment_method]} · {new Date(p.created_at).toLocaleDateString()}
              </p>
            </div>
            <span className="font-medium text-slate-900">${p.amount.toLocaleString()}</span>
          </div>
        ))}
        {payments.length === 0 && <p className="text-sm text-slate-500">No payments recorded yet.</p>}
      </div>
    </div>
  );
}
