import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { PriorityBadge } from "@/components/tasks/TaskBadges";
import { TaskDetailPanel } from "@/components/tasks/TaskDetailPanel";
import type { Task, TaskComment, Profile } from "@/types/database";

export default async function TaskDetailPage({ params }: { params: { id: string } }) {
  const supabase = createClient();

  const { data: task } = await supabase.from("tasks").select("*").eq("id", params.id).single();
  if (!task) notFound();
  const typedTask = task as Task;

  const { data: commentsData } = await supabase
    .from("task_comments")
    .select("*")
    .eq("task_id", params.id)
    .order("created_at", { ascending: true });

  const comments = (commentsData ?? []) as TaskComment[];

  const authorIds = Array.from(new Set(comments.map((c) => c.created_by).filter(Boolean))) as string[];
  let authors: Record<string, Profile> = {};
  if (authorIds.length > 0) {
    const { data: authorsData } = await supabase.from("profiles").select("*").in("id", authorIds);
    authors = Object.fromEntries((authorsData ?? []).map((p) => [p.id, p as Profile]));
  }

  return (
    <div className="max-w-2xl">
      <Link href="/tasks" className="mb-4 inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-900">
        <ArrowLeft className="h-4 w-4" />
        Back to Tasks
      </Link>

      <div className="mb-6">
        <div className="mb-2"><PriorityBadge priority={typedTask.priority} /></div>
        <h1 className="text-2xl font-bold text-slate-900">{typedTask.title}</h1>
        {typedTask.description && <p className="mt-2 text-sm text-slate-600">{typedTask.description}</p>}
        {typedTask.due_date && <p className="mt-2 text-sm text-slate-500">Due: {typedTask.due_date}</p>}
      </div>

      <TaskDetailPanel taskId={typedTask.id} currentStatus={typedTask.status} comments={comments} authors={authors} />
    </div>
  );
}
