-- =========================================================
-- Phase 2 — Migration 0005
-- Data migration + admin helper + phone visibility + activity log
-- =========================================================

-- Migrate existing 'owner' accounts to 'admin' (the Phase 2 standard name).
-- Safe no-op if you have no owner accounts yet.
update public.profiles set role = 'admin' where role = 'owner';

-- ---------------------------------------------------------
-- is_admin(): the Phase 2 standard check. Treats 'owner' (legacy)
-- and 'admin' as equivalent so nothing depending on is_owner() breaks.
-- ---------------------------------------------------------
create or replace function public.is_admin()
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select coalesce(
    (select role from public.profiles where id = auth.uid()) in ('admin', 'owner'),
    false
  );
$$;

-- ---------------------------------------------------------
-- Phone visibility control (Admin decides whether Sales can see
-- a client's phone/WhatsApp number). Default: visible.
-- Masking itself happens in the application layer (server-side),
-- so the raw number is never sent to a browser that shouldn't see it.
-- ---------------------------------------------------------
alter table public.leads
  add column if not exists phone_visible_to_assignee boolean not null default true;

-- ---------------------------------------------------------
-- Activity log — records important actions across the system
-- for audit purposes (who did what, when).
-- ---------------------------------------------------------
create table if not exists public.activity_log (
  id uuid primary key default uuid_generate_v4(),
  actor_id uuid references public.profiles(id),
  action text not null,
  entity_type text not null,
  entity_id uuid,
  details jsonb,
  created_at timestamptz not null default now()
);

create index if not exists idx_activity_log_entity on public.activity_log (entity_type, entity_id);
create index if not exists idx_activity_log_actor on public.activity_log (actor_id, created_at desc);

alter table public.activity_log enable row level security;

-- Only Admin can read the activity log
create policy activity_log_select_admin_only
  on public.activity_log for select
  using (public.is_admin());

-- Any authenticated user's actions can be logged (system writes on their behalf)
create policy activity_log_insert_authenticated
  on public.activity_log for insert
  with check (auth.uid() is not null);

create or replace function public.log_activity(
  p_action text,
  p_entity_type text,
  p_entity_id uuid,
  p_details jsonb default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.activity_log (actor_id, action, entity_type, entity_id, details)
  values (auth.uid(), p_action, p_entity_type, p_entity_id, p_details);
end;
$$;
