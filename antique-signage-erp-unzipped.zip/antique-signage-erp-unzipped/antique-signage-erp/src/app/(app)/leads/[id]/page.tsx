import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Phone, Mail, MapPin, Globe, MessageCircle } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile, isOwner } from "@/lib/auth";
import { LeadTimeline } from "@/components/leads/LeadTimeline";
import { PhoneVisibilityToggle } from "@/components/leads/PhoneVisibilityToggle";
import { RepeatClientHistory } from "@/components/leads/RepeatClientHistory";
import { FollowUpEditor } from "@/components/leads/FollowUpEditor";
import { LEAD_SOURCE_LABELS, type Lead, type LeadTimelineEntry, type Profile } from "@/types/database";

export default async function LeadDetailPage({ params }: { params: { id: string } }) {
  const profile = await getCurrentProfile();
  const supabase = createClient();
  const owner = isOwner(profile);

  const { data: lead } = await supabase
    .from("leads")
    .select("*")
    .eq("id", params.id)
    .single();

  if (!lead) notFound();

  const typedLead = lead as Lead;
  const canEdit = owner || typedLead.assigned_to === profile.id;

  const { data: timelineData } = await supabase
    .from("lead_timeline")
    .select("*")
    .eq("lead_id", params.id)
    .order("created_at", { ascending: false });

  const timeline = (timelineData ?? []) as LeadTimelineEntry[];

  const authorIds = Array.from(new Set(timeline.map((t) => t.created_by).filter(Boolean))) as string[];
  let authors: Record<string, Profile> = {};
  if (authorIds.length > 0) {
    const { data: authorsData } = await supabase.from("profiles").select("*").in("id", authorIds);
    authors = Object.fromEntries((authorsData ?? []).map((p) => [p.id, p as Profile]));
  }

  const canSeePhone = owner || typedLead.phone_visible_to_assignee;
  const whatsappNumber = canSeePhone ? typedLead.whatsapp?.replace(/[^\d]/g, "") : undefined;

  let previousLeads: Lead[] = [];
  if (!typedLead.is_new_client) {
    const orFilters = [
      typedLead.email ? `email.eq.${typedLead.email}` : null,
      typedLead.phone ? `phone.eq.${typedLead.phone}` : null,
      typedLead.whatsapp ? `whatsapp.eq.${typedLead.whatsapp}` : null
    ].filter(Boolean);

    if (orFilters.length > 0) {
      const { data: prevData } = await supabase
        .from("leads")
        .select("*")
        .neq("id", typedLead.id)
        .eq("status", "closed_won")
        .or(orFilters.join(","))
        .order("created_at", { ascending: false });
      previousLeads = (prevData ?? []) as Lead[];
    }
  }

  return (
    <div>
      <Link href="/leads" className="mb-4 inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-900">
        <ArrowLeft className="h-4 w-4" />
        Back to Leads
      </Link>

      <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-sm font-medium text-brand-blue-600">{typedLead.lead_code}</p>
          <h1 className="text-2xl font-bold text-slate-900">{typedLead.client_name}</h1>
          {typedLead.company_name && (
            <p className="text-sm text-slate-500">{typedLead.company_name}</p>
          )}
        </div>
        {whatsappNumber && (
          <a
            href={`https://wa.me/${whatsappNumber}`}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary"
          >
            <MessageCircle className="h-4 w-4" />
            WhatsApp Client
          </a>
        )}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-1">
          <div className="card p-5">
            <div className="mb-3 flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900">Contact Details</h3>
              {owner && <PhoneVisibilityToggle leadId={typedLead.id} visible={typedLead.phone_visible_to_assignee} />}
            </div>
            <div className="space-y-2.5 text-sm">
              {typedLead.phone && (
                <div className="flex items-center gap-2 text-slate-600">
                  <Phone className="h-3.5 w-3.5 text-slate-400" />
                  {canSeePhone ? typedLead.phone : <span className="italic text-slate-400">Hidden by admin</span>}
                </div>
              )}
              {typedLead.email && (
                <div className="flex items-center gap-2 text-slate-600">
                  <Mail className="h-3.5 w-3.5 text-slate-400" />
                  {typedLead.email}
                </div>
              )}
              {(typedLead.city || typedLead.country) && (
                <div className="flex items-center gap-2 text-slate-600">
                  <MapPin className="h-3.5 w-3.5 text-slate-400" />
                  {[typedLead.city, typedLead.country].filter(Boolean).join(", ")}
                </div>
              )}
              {typedLead.website && (
                <div className="flex items-center gap-2 text-slate-600">
                  <Globe className="h-3.5 w-3.5 text-slate-400" />
                  {typedLead.website}
                </div>
              )}
            </div>
          </div>

          <div className="card p-5">
            <h3 className="mb-3 text-sm font-semibold text-slate-900">Lead Info</h3>
            <dl className="space-y-2.5 text-sm">
              <div className="flex justify-between">
                <dt className="text-slate-500">Source</dt>
                <dd className="font-medium text-slate-900">{LEAD_SOURCE_LABELS[typedLead.source]}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-500">Follow Up</dt>
                <dd className="font-medium text-slate-900">{typedLead.follow_up_date ?? "—"}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-500">Expected Close</dt>
                <dd className="font-medium text-slate-900">{typedLead.expected_close_date ?? "—"}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-500">New Client</dt>
                <dd className="font-medium text-slate-900">{typedLead.is_new_client ? "Yes" : "No (Repeat)"}</dd>
              </div>
            </dl>
            {typedLead.next_action && (
              <div className="mt-3 border-t border-slate-100 pt-3">
                <p className="text-xs font-medium uppercase text-slate-400">Next Action</p>
                <p className="mt-1 text-sm text-slate-700">{typedLead.next_action}</p>
              </div>
            )}
            {canEdit && (
              <div className="mt-3 border-t border-slate-100 pt-3">
                <FollowUpEditor leadId={typedLead.id} followUpDate={typedLead.follow_up_date} nextAction={typedLead.next_action} />
              </div>
            )}
          </div>

          <RepeatClientHistory previousLeads={previousLeads} />

          {typedLead.notes && (
            <div className="card p-5">
              <h3 className="mb-2 text-sm font-semibold text-slate-900">Initial Notes</h3>
              <p className="text-sm text-slate-600">{typedLead.notes}</p>
            </div>
          )}
        </div>

        <div className="lg:col-span-2">
          <LeadTimeline
            leadId={typedLead.id}
            currentStatus={typedLead.status}
            timeline={timeline}
            authors={authors}
            canEdit={canEdit}
          />
        </div>
      </div>
    </div>
  );
}
