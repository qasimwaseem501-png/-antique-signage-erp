import { AlertTriangle } from "lucide-react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile, isAdmin } from "@/lib/auth";
import { NewInventoryItemForm, StockTransactionForm } from "@/components/inventory/InventoryForms";
import { INVENTORY_CATEGORY_LABELS, type InventoryItem } from "@/types/database";

export default async function InventoryPage() {
  const profile = await getCurrentProfile();
  const admin = isAdmin(profile);
  const canManage = admin || ["production", "packing"].includes(profile.role);
  const supabase = createClient();

  const { data } = await supabase.from("inventory_items").select("*").order("name");
  const items = (data ?? []) as InventoryItem[];
  const lowStockItems = items.filter((i) => i.current_stock <= i.low_stock_threshold);

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Inventory</h1>
          <p className="text-sm text-slate-500">Raw material stock levels</p>
        </div>
        <div className="flex gap-2">
          <Link href="/inventory/suppliers" className="btn-secondary">Suppliers</Link>
          <Link href="/inventory/purchase-orders" className="btn-secondary">Purchase Orders</Link>
        </div>
      </div>

      {lowStockItems.length > 0 && (
        <div className="mb-6 rounded-lg border border-red-200 bg-red-50 p-4">
          <div className="mb-2 flex items-center gap-2 text-sm font-semibold text-red-700">
            <AlertTriangle className="h-4 w-4" />
            Low Stock Alert ({lowStockItems.length})
          </div>
          <ul className="space-y-1 text-sm text-red-700">
            {lowStockItems.map((item) => (
              <li key={item.id}>{item.name}: {item.current_stock} {item.unit} remaining (threshold: {item.low_stock_threshold})</li>
            ))}
          </ul>
        </div>
      )}

      {canManage && (
        <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="card p-5">
            <h3 className="mb-3 text-sm font-semibold text-slate-900">Add New Item</h3>
            <NewInventoryItemForm />
          </div>
          <div className="card p-5">
            <h3 className="mb-3 text-sm font-semibold text-slate-900">Stock In / Out</h3>
            <StockTransactionForm items={items} />
          </div>
        </div>
      )}

      <div className="card overflow-hidden overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase text-slate-500">
            <tr>
              <th className="px-4 py-3 font-medium">Item</th>
              <th className="px-4 py-3 font-medium">Category</th>
              <th className="px-4 py-3 font-medium">Current Stock</th>
              <th className="px-4 py-3 font-medium">Low Stock Threshold</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {items.map((item) => (
              <tr key={item.id} className={item.current_stock <= item.low_stock_threshold ? "bg-red-50" : "hover:bg-slate-50"}>
                <td className="px-4 py-3 font-medium text-slate-900">{item.name}</td>
                <td className="px-4 py-3 text-slate-600">{INVENTORY_CATEGORY_LABELS[item.category]}</td>
                <td className="px-4 py-3 text-slate-600">{item.current_stock} {item.unit}</td>
                <td className="px-4 py-3 text-slate-600">{item.low_stock_threshold} {item.unit}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {items.length === 0 && (
          <div className="p-10 text-center text-sm text-slate-500">No inventory items yet. Add one above.</div>
        )}
      </div>
    </div>
  );
}
