# Antique Signage & Advertising — ERP/CRM

Internal ERP + CRM system for Antique Signage & Advertising (antiquesignage.com).

**Phases 1–4**: Authentication & RBAC, Leads/Quotations/Projects/Production, Payments/
Shipping/Commissions/Inventory, and now a Client Portal, Task Management, Supplier/PO
management, dark mode, and reporting charts.

👉 **Start here: [docs/SETUP_GUIDE.md](./docs/SETUP_GUIDE.md)** for full Supabase setup,
migration order, installation, test login users for every role, and deployment instructions.

## Quick Start

```bash
npm install
cp .env.example .env.local   # fill in your Supabase keys — see docs/SETUP_GUIDE.md
npm run dev
```

Run all SQL files in `supabase/migrations/` **in numeric order** (0001 → 0025) via the
Supabase SQL Editor before first use. Optionally run `supabase/seed.sql` afterward for
demo data.

## Tech Stack

- Next.js 14 (App Router) + TypeScript
- Tailwind CSS (light/dark mode)
- Supabase (PostgreSQL + Auth + Storage + Row Level Security)
- recharts (dashboard/report charts), jsPDF (quotation PDFs)

## Who Sees What

Admin/Owner sees everything. Sales, Designer, Production, Packing, and Accounts each see
only their relevant modules and data (enforced by Supabase Row Level Security, not just
the UI). Clients log in separately and land on `/portal`, a read-mostly view of their own
orders — they never see the staff app at all.
