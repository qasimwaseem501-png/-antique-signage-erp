import { LEAD_STATUS_LABELS, type LeadStatus } from "@/types/database";

const STATUS_STYLES: Record<LeadStatus, string> = {
  new: "bg-blue-100 text-blue-700",
  contacted: "bg-indigo-100 text-indigo-700",
  quote_requested: "bg-purple-100 text-purple-700",
  quote_sent: "bg-fuchsia-100 text-fuchsia-700",
  negotiation: "bg-amber-100 text-amber-700",
  deposit_received: "bg-yellow-100 text-yellow-700",
  confirmed: "bg-green-100 text-green-700",
  production: "bg-orange-100 text-orange-700",
  packing: "bg-sky-100 text-sky-700",
  shipping: "bg-cyan-100 text-cyan-700",
  delivered: "bg-emerald-100 text-emerald-700",
  completed: "bg-teal-100 text-teal-700",
  lost: "bg-red-100 text-red-700"
};

export function StatusBadge({ status }: { status: LeadStatus }) {
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ${STATUS_STYLES[status]}`}
    >
      {LEAD_STATUS_LABELS[status]}
    </span>
  );
}
