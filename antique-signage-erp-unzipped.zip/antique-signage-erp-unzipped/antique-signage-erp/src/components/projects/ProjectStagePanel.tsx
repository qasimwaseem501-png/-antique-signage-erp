"use client";

import { useState, useTransition } from "react";
import { updateProjectStage, addProjectExpense } from "@/app/(app)/projects/actions";
import { StageBadge } from "./StageBadge";
import {
  EXPENSE_CATEGORY_LABELS,
  PROJECT_STAGE_LABELS,
  PROJECT_STAGE_ORDER,
  type ExpenseCategory,
  type Profile,
  type ProjectStage
} from "@/types/database";

export function ProjectStagePanel({
  projectId,
  currentStage,
  stageAssignee,
  team,
  canEdit
}: {
  projectId: string;
  currentStage: ProjectStage;
  stageAssignee: string | null;
  team: Profile[];
  canEdit: boolean;
}) {
  const [isPending, startTransition] = useTransition();

  function handleStageChange(stage: string) {
    startTransition(() => updateProjectStage(projectId, stage, stageAssignee));
  }

  function handleAssigneeChange(assignee: string) {
    startTransition(() => updateProjectStage(projectId, currentStage, assignee || null));
  }

  return (
    <div className="card p-5">
      <h3 className="mb-3 text-sm font-semibold text-slate-900">Production Stage</h3>
      <div className="mb-3">
        <StageBadge stage={currentStage} />
      </div>
      {canEdit ? (
        <div className="space-y-3">
          <div>
            <label className="label">Stage</label>
            <select className="input" value={currentStage} disabled={isPending} onChange={(e) => handleStageChange(e.target.value)}>
              {PROJECT_STAGE_ORDER.map((stage) => (
                <option key={stage} value={stage}>{PROJECT_STAGE_LABELS[stage]}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">Assigned To</label>
            <select className="input" value={stageAssignee ?? ""} disabled={isPending} onChange={(e) => handleAssigneeChange(e.target.value)}>
              <option value="">Unassigned</option>
              {team.map((member) => (
                <option key={member.id} value={member.id}>{member.full_name}</option>
              ))}
            </select>
          </div>
        </div>
      ) : (
        <p className="text-sm text-slate-500">
          {stageAssignee ? team.find((m) => m.id === stageAssignee)?.full_name ?? "Assigned" : "Unassigned"}
        </p>
      )}
    </div>
  );
}

export function ExpenseForm({ projectId }: { projectId: string }) {
  const [category, setCategory] = useState<ExpenseCategory>("material");
  const [amount, setAmount] = useState(0);
  const [description, setDescription] = useState("");
  const [isPending, startTransition] = useTransition();

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (amount <= 0) return;
    startTransition(async () => {
      await addProjectExpense(projectId, category, amount, description);
      setAmount(0);
      setDescription("");
    });
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <div className="grid grid-cols-2 gap-3">
        <select className="input" value={category} onChange={(e) => setCategory(e.target.value as ExpenseCategory)}>
          {Object.entries(EXPENSE_CATEGORY_LABELS).map(([value, label]) => (
            <option key={value} value={value}>{label}</option>
          ))}
        </select>
        <input
          type="number"
          min={0}
          step="0.01"
          className="input"
          placeholder="Amount (USD)"
          value={amount || ""}
          onChange={(e) => setAmount(Number(e.target.value))}
        />
      </div>
      <input
        className="input"
        placeholder="Description (optional)"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
      />
      <button type="submit" disabled={isPending || amount <= 0} className="btn-primary">
        Add Expense
      </button>
    </form>
  );
}
