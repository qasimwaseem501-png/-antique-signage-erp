"use client";

import { useState, useTransition } from "react";
import { format } from "date-fns";
import { Clock, MessageSquare, ArrowRightLeft, UserCog, CalendarClock, Zap } from "lucide-react";
import { addTimelineNote, updateLeadStatus } from "@/app/(app)/leads/actions";
import { StatusBadge } from "@/components/leads/StatusBadge";
import { LEAD_STATUS_LABELS, type LeadStatus, type LeadTimelineEntry, type Profile } from "@/types/database";

const STATUS_OPTIONS = Object.entries(LEAD_STATUS_LABELS) as [LeadStatus, string][];

const EVENT_ICONS: Record<string, typeof Clock> = {
  status_change: ArrowRightLeft,
  note_added: MessageSquare,
  assigned: UserCog,
  follow_up_set: CalendarClock,
  system: Zap
};

export function LeadTimeline({
  leadId,
  currentStatus,
  timeline,
  authors,
  canEdit
}: {
  leadId: string;
  currentStatus: LeadStatus;
  timeline: LeadTimelineEntry[];
  authors: Record<string, Profile>;
  canEdit: boolean;
}) {
  const [note, setNote] = useState("");
  const [isPending, startTransition] = useTransition();

  function handleStatusChange(status: string) {
    startTransition(() => updateLeadStatus(leadId, status));
  }

  function handleAddNote(e: React.FormEvent) {
    e.preventDefault();
    if (!note.trim()) return;
    startTransition(async () => {
      await addTimelineNote(leadId, note);
      setNote("");
    });
  }

  return (
    <div className="space-y-6">
      <div className="card p-5">
        <h3 className="mb-3 text-sm font-semibold text-slate-900">Status</h3>
        <div className="flex items-center gap-3">
          <StatusBadge status={currentStatus} />
          {canEdit && (
            <select
              className="input max-w-[220px]"
              value={currentStatus}
              disabled={isPending}
              onChange={(e) => handleStatusChange(e.target.value)}
            >
              {STATUS_OPTIONS.map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </select>
          )}
        </div>
      </div>

      {canEdit && (
        <div className="card p-5">
          <h3 className="mb-3 text-sm font-semibold text-slate-900">Add Note</h3>
          <form onSubmit={handleAddNote} className="space-y-3">
            <textarea
              className="input"
              rows={2}
              placeholder="Log a call, WhatsApp message, or client update..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />
            <button type="submit" disabled={isPending || !note.trim()} className="btn-primary">
              Add Note
            </button>
          </form>
        </div>
      )}

      <div className="card p-5">
        <h3 className="mb-4 text-sm font-semibold text-slate-900">Timeline</h3>
        <div className="space-y-4">
          {timeline.map((entry) => {
            const Icon = EVENT_ICONS[entry.event_type] ?? Clock;
            const author = entry.created_by ? authors[entry.created_by] : undefined;
            return (
              <div key={entry.id} className="flex gap-3">
                <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-brand-blue-50">
                  <Icon className="h-3.5 w-3.5 text-brand-blue-600" />
                </div>
                <div className="flex-1 border-b border-slate-100 pb-4">
                  <p className="text-sm font-medium text-slate-900">{entry.title}</p>
                  {entry.description && (
                    <p className="mt-0.5 text-sm text-slate-600">{entry.description}</p>
                  )}
                  {entry.old_value && entry.new_value && (
                    <p className="mt-0.5 text-xs text-slate-500">
                      {entry.old_value} → {entry.new_value}
                    </p>
                  )}
                  <p className="mt-1 text-xs text-slate-400">
                    {author ? `${author.full_name} · ` : ""}
                    {format(new Date(entry.created_at), "MMM d, yyyy 'at' h:mm a")}
                  </p>
                </div>
              </div>
            );
          })}
          {timeline.length === 0 && (
            <p className="text-sm text-slate-500">No activity yet.</p>
          )}
        </div>
      </div>
    </div>
  );
}
