"use client";

import { useRef, useState, useTransition } from "react";
import { createClient } from "@/lib/supabase/client";
import { recordPayment } from "@/app/(app)/payments/actions";
import {
  PAYMENT_METHOD_LABELS,
  PAYMENT_TYPE_LABELS,
  type PaymentMethod,
  type PaymentType
} from "@/types/database";

export function PaymentForm({ projectId }: { projectId: string }) {
  const [paymentType, setPaymentType] = useState<PaymentType>("advance");
  const [amount, setAmount] = useState(0);
  const [method, setMethod] = useState<PaymentMethod>("bank_transfer");
  const [notes, setNotes] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const supabase = createClient();

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (amount <= 0) return;
    setError(null);

    startTransition(async () => {
      try {
        let proofPath: string | null = null;

        if (file) {
          const path = `payments/${projectId}/${Date.now()}-${file.name}`;
          const { error: uploadError } = await supabase.storage.from("client-files").upload(path, file);
          if (uploadError) throw uploadError;
          proofPath = path;
        }

        await recordPayment({
          project_id: projectId,
          payment_type: paymentType,
          amount,
          payment_method: method,
          proof_storage_path: proofPath,
          notes
        });

        setAmount(0);
        setNotes("");
        setFile(null);
        if (fileRef.current) fileRef.current.value = "";
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to record payment");
      }
    });
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      {error && <p className="text-sm text-red-600">{error}</p>}
      <div className="grid grid-cols-2 gap-3">
        <select className="input" value={paymentType} onChange={(e) => setPaymentType(e.target.value as PaymentType)}>
          {Object.entries(PAYMENT_TYPE_LABELS).map(([value, label]) => (
            <option key={value} value={value}>{label}</option>
          ))}
        </select>
        <input
          type="number"
          min={0}
          step="0.01"
          className="input"
          placeholder="Amount (USD)"
          value={amount || ""}
          onChange={(e) => setAmount(Number(e.target.value))}
        />
      </div>
      <select className="input" value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)}>
        {Object.entries(PAYMENT_METHOD_LABELS).map(([value, label]) => (
          <option key={value} value={value}>{label}</option>
        ))}
      </select>
      <input className="input" placeholder="Notes (optional)" value={notes} onChange={(e) => setNotes(e.target.value)} />
      <div>
        <label className="label">Payment Proof (optional)</label>
        <input ref={fileRef} type="file" className="input" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
      </div>
      <button type="submit" disabled={isPending || amount <= 0} className="btn-primary">
        {isPending ? "Recording..." : "Record Payment"}
      </button>
    </form>
  );
}
