"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile } from "@/lib/auth";

export interface QuotationItemInput {
  sign_type: string;
  size: string;
  material: string;
  lighting_type: string;
  quantity: number;
  unit_price: number;
}

export async function createQuotation(input: {
  lead_id: string | null;
  client_name: string;
  company_name: string;
  country: string;
  email: string;
  phone: string;
  shipping_included: boolean;
  shipping_cost: number;
  notes: string;
  items: QuotationItemInput[];
}) {
  const profile = await getCurrentProfile();
  const supabase = createClient();

  const { data: quotation, error } = await supabase
    .from("quotations")
    .insert({
      lead_id: input.lead_id,
      client_name: input.client_name,
      company_name: input.company_name || null,
      country: input.country || null,
      email: input.email || null,
      phone: input.phone || null,
      shipping_included: input.shipping_included,
      shipping_cost: input.shipping_cost,
      notes: input.notes || null,
      created_by: profile.id
    })
    .select()
    .single();

  if (error) throw new Error(error.message);

  if (input.items.length > 0) {
    const { error: itemsError } = await supabase.from("quotation_items").insert(
      input.items.map((item, index) => ({
        quotation_id: quotation.id,
        sign_type: item.sign_type,
        size: item.size || null,
        material: item.material || null,
        lighting_type: item.lighting_type || null,
        quantity: item.quantity,
        unit_price: item.unit_price,
        sort_order: index
      }))
    );
    if (itemsError) throw new Error(itemsError.message);
  }

  revalidatePath("/quotations");
  redirect(`/quotations/${quotation.id}`);
}

export async function updateQuotationStatus(quotationId: string, status: string) {
  const profile = await getCurrentProfile();
  const supabase = createClient();

  const update: Record<string, unknown> = { status };
  if (status === "approved") {
    update.approved_by = profile.id;
    update.approved_at = new Date().toISOString();
  }

  const { error } = await supabase.from("quotations").update(update).eq("id", quotationId);
  if (error) throw new Error(error.message);

  revalidatePath(`/quotations/${quotationId}`);
  revalidatePath("/quotations");
}

export async function convertQuotationToProject(quotationId: string) {
  const supabase = createClient();
  const { data, error } = await supabase.rpc("convert_quotation_to_project", {
    p_quotation_id: quotationId
  });

  if (error) throw new Error(error.message);

  revalidatePath("/quotations");
  revalidatePath("/projects");
  redirect(`/projects/${data}`);
}
