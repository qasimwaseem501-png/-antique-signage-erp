import Link from "next/link";
import type { Lead } from "@/types/database";

export function RepeatClientHistory({ previousLeads }: { previousLeads: Lead[] }) {
  if (previousLeads.length === 0) return null;

  return (
    <div className="card p-5">
      <h3 className="mb-3 text-sm font-semibold text-slate-900">Previous Orders (Repeat Client)</h3>
      <div className="space-y-2">
        {previousLeads.map((lead) => (
          <Link
            key={lead.id}
            href={`/leads/${lead.id}`}
            className="block rounded-lg border border-slate-100 px-3 py-2 text-sm hover:bg-slate-50"
          >
            <div className="flex items-center justify-between">
              <span className="font-medium text-brand-blue-600">{lead.lead_code}</span>
              <span className="text-xs text-slate-400">{new Date(lead.created_at).toLocaleDateString()}</span>
            </div>
            <p className="text-xs text-slate-500">{lead.notes ?? "No notes"}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
