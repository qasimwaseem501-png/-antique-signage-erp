-- =========================================================
-- Phase 3 — Migration 0014
-- Design Approval workflow
-- =========================================================

create type design_approval_status as enum ('pending', 'changes_required', 'approved');

create table public.design_approvals (
  id uuid primary key default uuid_generate_v4(),
  project_id uuid not null references public.projects(id) on delete cascade,

  status design_approval_status not null default 'pending',
  revision_notes text,
  approved_at timestamptz,

  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_design_approvals_project on public.design_approvals (project_id, created_at desc);

create trigger trg_design_approvals_updated_at before update on public.design_approvals
  for each row execute function public.set_updated_at();

-- When a design is approved, auto-advance the project stage to Design Approved
-- (only if it's currently sitting in Design Pending, so we don't override
-- someone who's already moved further along).
create or replace function public.handle_design_approved_update()
returns trigger
language plpgsql
as $$
begin
  if new.status = 'approved' and old.status is distinct from 'approved' then
    new.approved_at := now();
    update public.projects
    set current_stage = 'design_approved'
    where id = new.project_id and current_stage = 'design_pending';
  end if;
  return new;
end;
$$;

create trigger trg_design_approvals_advance_stage_update
  before update on public.design_approvals
  for each row execute function public.handle_design_approved_update();

create or replace function public.handle_design_approved_insert()
returns trigger
language plpgsql
as $$
begin
  if new.status = 'approved' then
    new.approved_at := now();
  end if;
  return new;
end;
$$;

create trigger trg_design_approvals_set_approved_at_insert
  before insert on public.design_approvals
  for each row execute function public.handle_design_approved_insert();

-- Separate AFTER trigger to advance the project stage on insert
-- (can't update a different table's row safely from a BEFORE trigger
-- on this table in the same statement in all cases, so we use AFTER here)
create or replace function public.advance_stage_on_design_approved_insert()
returns trigger
language plpgsql
as $$
begin
  if new.status = 'approved' then
    update public.projects
    set current_stage = 'design_approved'
    where id = new.project_id and current_stage = 'design_pending';
  end if;
  return new;
end;
$$;

create trigger trg_design_approvals_advance_stage_insert
  after insert on public.design_approvals
  for each row execute function public.advance_stage_on_design_approved_insert();
