-- =========================================================
-- Phase 3 — Migration 0015
-- Shipping rewrite: country rate table + multiple boxes per shipment
-- =========================================================

create table public.shipping_rates (
  country text primary key,
  rate_pkr_per_kg numeric(10,2) not null,
  duty_status duty_status not null default 'not_applicable',
  updated_at timestamptz not null default now()
);

create trigger trg_shipping_rates_updated_at before update on public.shipping_rates
  for each row execute function public.set_updated_at();

insert into public.shipping_rates (country, rate_pkr_per_kg, duty_status) values
  ('UK', 1700, 'duty_paid'),
  ('USA', 2300, 'duty_unpaid'),
  ('Canada', 2300, 'duty_unpaid'),
  ('Europe', 2250, 'duty_paid'),
  ('Australia', 2100, 'duty_paid'),
  ('Dubai', 1100, 'duty_paid')
on conflict (country) do nothing;

-- ---------------------------------------------------------
-- Shipment boxes — a shipment can now contain multiple boxes.
-- ---------------------------------------------------------

create table public.shipment_boxes (
  id uuid primary key default uuid_generate_v4(),
  shipment_id uuid not null references public.shipments(id) on delete cascade,

  box_number integer not null default 1,
  length_cm numeric(8,2) not null,
  width_cm numeric(8,2) not null,
  height_cm numeric(8,2) not null,
  actual_weight_kg numeric(8,2) not null,

  volumetric_weight_kg numeric(8,2),
  chargeable_weight_kg numeric(8,2),
  is_oversize boolean not null default false,
  is_overweight boolean not null default false,

  created_at timestamptz not null default now()
);

create index idx_shipment_boxes_shipment on public.shipment_boxes (shipment_id);

create or replace function public.calc_box_weights()
returns trigger
language plpgsql
as $$
begin
  new.volumetric_weight_kg := round((new.length_cm * new.width_cm * new.height_cm) / 5000.0, 2);
  new.chargeable_weight_kg := greatest(new.actual_weight_kg, new.volumetric_weight_kg);
  new.is_oversize := (new.length_cm > 100 or new.width_cm > 100 or new.height_cm > 100);
  new.is_overweight := (new.actual_weight_kg > 25);
  return new;
end;
$$;

create trigger trg_shipment_boxes_calc
  before insert or update on public.shipment_boxes
  for each row execute function public.calc_box_weights();

-- ---------------------------------------------------------
-- Extend shipments with rate/charge fields for total cost calculation
-- ---------------------------------------------------------

alter table public.shipments
  add column if not exists rate_pkr_per_kg numeric(10,2),
  add column if not exists oversize_charge numeric(12,2) not null default 0,
  add column if not exists overweight_charge numeric(12,2) not null default 0,
  add column if not exists total_shipping_cost numeric(12,2) not null default 0;

create or replace function public.recalc_shipment_total()
returns trigger
language plpgsql
as $$
declare
  target_shipment_id uuid;
  total_chargeable numeric(12,2);
  rate numeric(10,2);
  oversize numeric(12,2);
  overweight numeric(12,2);
begin
  target_shipment_id := coalesce(new.shipment_id, old.shipment_id);

  select coalesce(sum(chargeable_weight_kg), 0) into total_chargeable
  from public.shipment_boxes
  where shipment_id = target_shipment_id;

  select rate_pkr_per_kg, oversize_charge, overweight_charge
  into rate, oversize, overweight
  from public.shipments
  where id = target_shipment_id;

  update public.shipments
  set total_shipping_cost = (total_chargeable * coalesce(rate, 0)) + coalesce(oversize, 0) + coalesce(overweight, 0)
  where id = target_shipment_id;

  return coalesce(new, old);
end;
$$;

create trigger trg_recalc_shipment_total_after_box_change
  after insert or update or delete on public.shipment_boxes
  for each row execute function public.recalc_shipment_total();

create or replace function public.recalc_shipment_total_on_self_change()
returns trigger
language plpgsql
as $$
declare
  total_chargeable numeric(12,2);
begin
  select coalesce(sum(chargeable_weight_kg), 0) into total_chargeable
  from public.shipment_boxes
  where shipment_id = new.id;

  new.total_shipping_cost := (total_chargeable * coalesce(new.rate_pkr_per_kg, 0))
    + coalesce(new.oversize_charge, 0) + coalesce(new.overweight_charge, 0);

  return new;
end;
$$;

create trigger trg_recalc_shipment_total_on_update
  before update of rate_pkr_per_kg, oversize_charge, overweight_charge on public.shipments
  for each row execute function public.recalc_shipment_total_on_self_change();

alter table public.shipping_rates enable row level security;
alter table public.shipment_boxes enable row level security;

create policy shipping_rates_select_authenticated
  on public.shipping_rates for select
  using (auth.uid() is not null);

create policy shipping_rates_write_admin_only
  on public.shipping_rates for all
  using (public.is_admin())
  with check (public.is_admin());

create policy shipment_boxes_select_via_shipment
  on public.shipment_boxes for select
  using (
    exists (
      select 1 from public.shipments s
      where s.id = shipment_boxes.shipment_id
      and (
        public.is_admin()
        or public.current_role() in ('accounts', 'packing')
        or exists (
          select 1 from public.projects p
          join public.leads l on l.id = p.lead_id
          where p.id = s.project_id and l.assigned_to = auth.uid()
        )
      )
    )
  );

create policy shipment_boxes_write_admin_or_packing
  on public.shipment_boxes for all
  using (public.is_admin() or public.current_role() = 'packing')
  with check (public.is_admin() or public.current_role() = 'packing');
