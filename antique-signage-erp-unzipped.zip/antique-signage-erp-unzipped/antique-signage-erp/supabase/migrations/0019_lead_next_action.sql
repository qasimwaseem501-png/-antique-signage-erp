-- =========================================================
-- Phase 3 — Migration 0019
-- Add "Next Action" field to leads (paired with follow_up_date)
-- =========================================================

alter table public.leads
  add column if not exists next_action text;
