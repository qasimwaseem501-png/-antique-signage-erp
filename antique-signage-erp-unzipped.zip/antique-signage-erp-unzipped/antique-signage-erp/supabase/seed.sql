-- =========================================================
-- OPTIONAL Seed / Demo Data
-- Run this AFTER all migrations (0001-0011) and AFTER you've
-- created at least one Admin user (see docs/SETUP_GUIDE.md Step 3).
--
-- This script is safe to run multiple times conceptually, but it
-- will create duplicate demo rows if run more than once — intended
-- for a fresh demo/staging database, not production data.
--
-- It automatically uses your first Admin account as the "creator"
-- of all demo records, and creates a second synthetic "Sales Demo"
-- profile row is NOT created here (Supabase Auth users can't be
-- created via plain SQL) — instead, demo leads/projects are
-- assigned to whichever Admin/Sales accounts already exist.
-- =========================================================

do $$
declare
  admin_id uuid;
  sales_id uuid;
  lead1_id uuid;
  lead2_id uuid;
  lead3_id uuid;
  quote1_id uuid;
  quote2_id uuid;
  project1_id uuid;
begin
  select id into admin_id from public.profiles where role in ('admin','owner') order by created_at limit 1;

  if admin_id is null then
    raise notice 'No admin account found — create one first (see docs/SETUP_GUIDE.md Step 3). Seed skipped.';
    return;
  end if;

  -- Use a sales account if one exists, otherwise fall back to admin
  select id into sales_id from public.profiles where role = 'sales' and is_active order by created_at limit 1;
  if sales_id is null then
    sales_id := admin_id;
  end if;

  -- ---------------------------------------------------------
  -- Demo Leads
  -- ---------------------------------------------------------
  insert into public.leads (client_name, company_name, country, city, phone, whatsapp, email, source, status, assigned_to, created_by, follow_up_date, notes)
  values (
    'John Miller', 'Miller Auto Detailing', 'USA', 'Austin', '+1-512-555-0142', '+15125550142',
    'john@millerautodetailing.com', 'facebook_ads', 'quotation_sent', sales_id, admin_id,
    current_date + interval '3 days', 'Wants 3D channel letters for new storefront, 8ft wide.'
  ) returning id into lead1_id;

  insert into public.leads (client_name, company_name, country, city, phone, whatsapp, email, source, status, assigned_to, created_by, follow_up_date, notes)
  values (
    'Sarah Thompson', 'Thompson Nail Bar', 'UK', 'Manchester', '+44-161-555-0199', '+441615550199',
    'sarah@thompsonnailbar.co.uk', 'instagram', 'negotiation', sales_id, admin_id,
    current_date + interval '1 day', 'Interested in a neon sign, negotiating on price for 2 units.'
  ) returning id into lead2_id;

  insert into public.leads (client_name, company_name, country, city, phone, whatsapp, email, source, status, assigned_to, created_by, notes)
  values (
    'Ahmed Al-Farsi', 'Al-Farsi Cafe', 'Canada', 'Toronto', '+1-416-555-0110', '+14165550110',
    'ahmed@alfarsicafe.ca', 'whatsapp', 'new', sales_id, admin_id,
    'Fresh WhatsApp inquiry about an ACM board shopfront sign.'
  ) returning id into lead3_id;

  -- ---------------------------------------------------------
  -- Demo Quotations (with line items — totals auto-calculated by triggers)
  -- ---------------------------------------------------------
  insert into public.quotations (lead_id, client_name, company_name, country, email, phone, shipping_included, shipping_cost, status, created_by)
  values (lead1_id, 'John Miller', 'Miller Auto Detailing', 'USA', 'john@millerautodetailing.com', '+1-512-555-0142', true, 350, 'sent', sales_id)
  returning id into quote1_id;

  insert into public.quotation_items (quotation_id, sign_type, size, material, lighting_type, quantity, unit_price)
  values (quote1_id, '3D Channel Letters', '8ft x 2ft', 'Aluminum + Acrylic Face', 'Front-lit LED', 1, 2400);

  insert into public.quotations (lead_id, client_name, company_name, country, email, phone, shipping_included, shipping_cost, status, created_by, approved_by, approved_at)
  values (lead2_id, 'Sarah Thompson', 'Thompson Nail Bar', 'UK', 'sarah@thompsonnailbar.co.uk', '+44-161-555-0199', true, 220, 'approved', sales_id, admin_id, now())
  returning id into quote2_id;

  insert into public.quotation_items (quotation_id, sign_type, size, material, lighting_type, quantity, unit_price)
  values (quote2_id, 'Neon Sign', '3ft x 1.5ft', 'Flex Neon on Acrylic Backing', 'Neon Flex', 2, 650);

  -- ---------------------------------------------------------
  -- Demo Project — converted from the approved quotation
  -- ---------------------------------------------------------
  select public.convert_quotation_to_project(quote2_id) into project1_id;

  update public.projects
  set current_stage = 'cnc_laser_cutting',
      stage_assignee = admin_id,
      expected_delivery_date = current_date + interval '14 days',
      internal_notes = 'Client requested pink + blue neon colorway.'
  where id = project1_id;

  -- Demo expenses on the project
  insert into public.project_expenses (project_id, category, amount, description, created_by)
  values
    (project1_id, 'material', 280, 'Acrylic backing + neon flex tubing', admin_id),
    (project1_id, 'labor', 150, 'Fabrication labor', admin_id),
    (project1_id, 'packing', 40, 'Export crate + packing materials', admin_id);

  -- Demo shipment
  insert into public.shipments (project_id, country, courier, box_length_cm, box_width_cm, box_height_cm, actual_weight_kg, shipping_cost, duty_status, delivery_status, created_by)
  values (project1_id, 'UK', 'DHL Express', 100, 60, 40, 12.5, 220, 'duty_unpaid', 'pending', admin_id);

  raise notice 'Seed data created successfully. Admin: %, Sales: %, Demo Project: %', admin_id, sales_id, project1_id;

  -- ---------------------------------------------------------
  -- Phase 4 demo data: a task, a supplier, and an ad spend entry
  -- ---------------------------------------------------------
  insert into public.tasks (title, description, project_id, assigned_to, priority, status, due_date, created_by)
  values (
    'Confirm powder coating color with client',
    'Client requested a custom RAL color match — confirm before proceeding.',
    project1_id, admin_id, 'high', 'todo', current_date + interval '2 days', admin_id
  );

  insert into public.suppliers (name, contact_person, phone, email)
  values ('Lahore Acrylic Traders', 'Imran Sheikh', '+92-300-1234567', 'sales@lahoreacrylic.example');

  insert into public.ad_spend (platform, spend_date, amount, notes, created_by)
  values ('meta', current_date - interval '10 days', 150.00, 'Facebook lead campaign — USA signage', admin_id);

end $$;
