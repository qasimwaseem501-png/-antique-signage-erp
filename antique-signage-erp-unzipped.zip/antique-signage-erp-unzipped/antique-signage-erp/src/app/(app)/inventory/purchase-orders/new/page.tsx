import { createClient } from "@/lib/supabase/server";
import { PurchaseOrderForm } from "./PurchaseOrderForm";
import type { InventoryItem, Supplier } from "@/types/database";

export default async function NewPurchaseOrderPage() {
  const supabase = createClient();
  const [{ data: suppliersData }, { data: itemsData }] = await Promise.all([
    supabase.from("suppliers").select("*").order("name"),
    supabase.from("inventory_items").select("*").order("name")
  ]);

  return (
    <div className="max-w-3xl">
      <h1 className="mb-6 text-2xl font-bold text-slate-900">New Purchase Order</h1>
      <PurchaseOrderForm suppliers={(suppliersData ?? []) as Supplier[]} inventoryItems={(itemsData ?? []) as InventoryItem[]} />
    </div>
  );
}
