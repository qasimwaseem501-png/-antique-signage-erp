-- =========================================================
-- Phase 2 — Migration 0007
-- Projects / Production Workflow + Commission System
-- =========================================================

create type project_stage as enum (
  'design_pending',
  'design_approved',
  'material_purchase',
  'cnc_laser_cutting',
  'letter_bending',
  'welding_fabrication',
  'powder_coating',
  'led_wiring',
  'testing',
  'packing',
  'ready_to_ship',
  'shipped',
  'delivered'
);

create sequence if not exists project_code_seq start 1;

create or replace function public.generate_project_code()
returns text
language plpgsql
as $$
declare
  next_val int;
begin
  next_val := nextval('project_code_seq');
  return 'PRJ-' || to_char(now(), 'YYYY') || '-' || lpad(next_val::text, 4, '0');
end;
$$;

create table public.projects (
  id uuid primary key default uuid_generate_v4(),
  project_code text not null unique default public.generate_project_code(),

  quotation_id uuid references public.quotations(id) on delete set null,
  lead_id uuid references public.leads(id) on delete set null,

  client_name text not null,
  company_name text,
  country text,

  current_stage project_stage not null default 'design_pending',
  stage_assignee uuid references public.profiles(id),

  expected_delivery_date date,
  internal_notes text,

  sale_amount numeric(12,2) not null default 0,

  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_projects_stage on public.projects (current_stage);
create index idx_projects_stage_assignee on public.projects (stage_assignee);
create index idx_projects_quotation on public.projects (quotation_id);
create index idx_projects_lead on public.projects (lead_id);

create trigger trg_projects_updated_at before update on public.projects
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------
-- Convert an approved quotation into a project (order).
-- Callable via RPC from the app: select public.convert_quotation_to_project(quotation_id);
-- ---------------------------------------------------------
create or replace function public.convert_quotation_to_project(p_quotation_id uuid)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  q record;
  new_project_id uuid;
begin
  select * into q from public.quotations where id = p_quotation_id;

  if q is null then
    raise exception 'Quotation not found';
  end if;

  if q.status != 'approved' then
    raise exception 'Only approved quotations can be converted to a project';
  end if;

  insert into public.projects (quotation_id, lead_id, client_name, company_name, country, sale_amount, created_by)
  values (q.id, q.lead_id, q.client_name, q.company_name, q.country, q.total_amount, auth.uid())
  returning id into new_project_id;

  if q.lead_id is not null then
    update public.leads set status = 'closed_won' where id = q.lead_id;

    insert into public.lead_timeline (lead_id, event_type, title, description, created_by)
    values (q.lead_id, 'system', 'Converted to project', 'Project created from quotation ' || q.quotation_number, auth.uid());
  end if;

  return new_project_id;
end;
$$;

-- ---------------------------------------------------------
-- Project stage history — immutable audit trail, mirrors lead_timeline
-- ---------------------------------------------------------

create table public.project_stage_history (
  id uuid primary key default uuid_generate_v4(),
  project_id uuid not null references public.projects(id) on delete cascade,
  stage project_stage not null,
  assigned_to uuid references public.profiles(id),
  notes text,
  changed_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create index idx_stage_history_project on public.project_stage_history (project_id, created_at desc);

create or replace function public.log_project_stage_change()
returns trigger
language plpgsql
as $$
begin
  if TG_OP = 'INSERT' then
    insert into public.project_stage_history (project_id, stage, assigned_to, notes, changed_by)
    values (new.id, new.current_stage, new.stage_assignee, 'Project created', auth.uid());
    return new;
  end if;

  if TG_OP = 'UPDATE' and (old.current_stage is distinct from new.current_stage or old.stage_assignee is distinct from new.stage_assignee) then
    insert into public.project_stage_history (project_id, stage, assigned_to, changed_by)
    values (new.id, new.current_stage, new.stage_assignee, auth.uid());
  end if;

  return new;
end;
$$;

create trigger trg_projects_log_insert
  after insert on public.projects
  for each row execute function public.log_project_stage_change();

create trigger trg_projects_log_stage_change
  after update on public.projects
  for each row execute function public.log_project_stage_change();

-- ---------------------------------------------------------
-- Project files (design files, photos, videos, invoices, shipping docs)
-- ---------------------------------------------------------

create type project_file_category as enum (
  'design', 'photo', 'video', 'invoice', 'shipping_doc', 'packing_photo', 'tracking_receipt', 'other'
);

create table public.project_files (
  id uuid primary key default uuid_generate_v4(),
  project_id uuid not null references public.projects(id) on delete cascade,
  category project_file_category not null default 'other',
  file_name text not null,
  storage_path text not null,
  uploaded_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create index idx_project_files_project on public.project_files (project_id);

-- =========================================================
-- COMMISSION SYSTEM
-- =========================================================

create type commission_status as enum ('pending', 'approved', 'paid');

create table public.commissions (
  id uuid primary key default uuid_generate_v4(),
  lead_id uuid references public.leads(id) on delete set null,
  project_id uuid references public.projects(id) on delete set null,
  employee_id uuid not null references public.profiles(id),

  sale_amount numeric(12,2) not null default 0,
  calculated_amount numeric(12,2) not null default 0,
  override_amount numeric(12,2),
  final_amount numeric(12,2) not null default 0,

  status commission_status not null default 'pending',
  notes text,

  approved_by uuid references public.profiles(id),
  approved_at timestamptz,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_commissions_employee on public.commissions (employee_id);
create index idx_commissions_status on public.commissions (status);
create index idx_commissions_lead on public.commissions (lead_id);
create index idx_commissions_project on public.commissions (project_id);

create trigger trg_commissions_updated_at before update on public.commissions
  for each row execute function public.set_updated_at();

-- Commission tier calculation per spec:
--  <= 1000            = 30
--  1001 - 3000         = 50
--  3001 - 5000         = 100
--  5001 - 7000         = 150
--  7000+                = 200
create or replace function public.calc_commission_tier(p_amount numeric)
returns numeric
language plpgsql
immutable
as $$
begin
  if p_amount <= 1000 then
    return 30;
  elsif p_amount <= 3000 then
    return 50;
  elsif p_amount <= 5000 then
    return 100;
  elsif p_amount <= 7000 then
    return 150;
  else
    return 200;
  end if;
end;
$$;

create or replace function public.set_commission_final_amount()
returns trigger
language plpgsql
as $$
begin
  new.final_amount := coalesce(new.override_amount, new.calculated_amount);
  return new;
end;
$$;

create trigger trg_commissions_final_amount
  before insert or update on public.commissions
  for each row execute function public.set_commission_final_amount();

-- Auto-create a pending commission when a lead is marked Closed Won,
-- based on the most recent approved quotation for that lead.
create or replace function public.handle_lead_closed_won()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  latest_quote record;
  tier_amount numeric;
begin
  if new.status = 'closed_won' and old.status is distinct from 'closed_won' and new.assigned_to is not null then

    select * into latest_quote
    from public.quotations
    where lead_id = new.id and status = 'approved'
    order by approved_at desc nulls last, created_at desc
    limit 1;

    if latest_quote is not null then
      tier_amount := public.calc_commission_tier(latest_quote.total_amount);

      insert into public.commissions (lead_id, employee_id, sale_amount, calculated_amount, status)
      values (new.id, new.assigned_to, latest_quote.total_amount, tier_amount, 'pending');
    end if;

  end if;

  return new;
end;
$$;

create trigger trg_leads_closed_won_commission
  after update on public.leads
  for each row execute function public.handle_lead_closed_won();
