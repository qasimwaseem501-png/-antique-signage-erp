"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile } from "@/lib/auth";
import type { DesignApprovalStatus } from "@/types/database";

export async function submitDesignApproval(
  projectId: string,
  status: DesignApprovalStatus,
  revisionNotes: string
) {
  const profile = await getCurrentProfile();
  const supabase = createClient();

  const { error } = await supabase.from("design_approvals").insert({
    project_id: projectId,
    status,
    revision_notes: revisionNotes || null,
    created_by: profile.id
  });

  if (error) throw new Error(error.message);
  revalidatePath(`/projects/${projectId}`);
}
