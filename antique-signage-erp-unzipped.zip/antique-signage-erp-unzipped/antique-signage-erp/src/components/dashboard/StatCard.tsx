import type { LucideIcon } from "lucide-react";

export function StatCard({
  label,
  value,
  icon: Icon,
  accent = "blue",
  suffix
}: {
  label: string;
  value: string | number;
  icon: LucideIcon;
  accent?: "blue" | "green" | "orange" | "red" | "slate";
  suffix?: string;
}) {
  const accentClasses: Record<string, string> = {
    blue: "bg-brand-blue-50 text-brand-blue-600",
    green: "bg-emerald-50 text-emerald-600",
    orange: "bg-orange-50 text-orange-600",
    red: "bg-red-50 text-red-600",
    slate: "bg-slate-100 text-slate-600"
  };

  return (
    <div className="card p-5">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-slate-500">{label}</p>
          <p className="mt-2 text-2xl font-bold text-slate-900">
            {value}
            {suffix && <span className="ml-1 text-sm font-normal text-slate-500">{suffix}</span>}
          </p>
        </div>
        <div className={`rounded-lg p-2.5 ${accentClasses[accent]}`}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </div>
  );
}
