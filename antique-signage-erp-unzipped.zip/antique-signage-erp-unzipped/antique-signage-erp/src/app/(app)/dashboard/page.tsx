import {
  Users,
  UserPlus,
  Trophy,
  XCircle,
  DollarSign,
  FileClock,
  FolderKanban,
  PackageCheck,
  TrendingUp,
  Percent,
  CalendarClock,
  Receipt,
  Wallet
} from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile, isAdmin } from "@/lib/auth";
import { StatCard } from "@/components/dashboard/StatCard";
import {
  ACTIVE_LEAD_SOURCES,
  LEAD_SOURCE_LABELS,
  PROJECT_STAGE_LABELS,
  PROJECT_STAGE_ORDER,
  type Lead,
  type Project,
  type Quotation,
  type Commission,
  type ProjectExpense,
  type ProjectPaymentSummary
} from "@/types/database";

export default async function DashboardPage() {
  const profile = await getCurrentProfile();
  const supabase = createClient();
  const admin = isAdmin(profile);

  let leadsQuery = supabase.from("leads").select("*");
  if (!admin) leadsQuery = leadsQuery.eq("assigned_to", profile.id);
  const { data: leadsData } = await leadsQuery;
  const leads = (leadsData ?? []) as Lead[];

  const { data: quotationsData } = await supabase.from("quotations").select("*");
  const quotations = (quotationsData ?? []) as Quotation[];

  const { data: projectsData } = await supabase.from("projects").select("*");
  const projects = (projectsData ?? []) as Project[];

  let commissionsQuery = supabase.from("commissions").select("*");
  if (!admin && profile.role !== "accounts") commissionsQuery = commissionsQuery.eq("employee_id", profile.id);
  const { data: commissionsData } = await commissionsQuery;
  const commissions = (commissionsData ?? []) as Commission[];

  const today = new Date().toISOString().slice(0, 10);
  const startOfMonth = today.slice(0, 7); // YYYY-MM

  const totalLeads = leads.length;
  const todaysLeads = leads.filter((l) => l.created_at.slice(0, 10) === today).length;
  const followUpsDue = leads.filter((l) => l.follow_up_date && l.follow_up_date <= today && !["closed_won", "closed_lost"].includes(l.status)).length;
  const closedWon = leads.filter((l) => l.status === "closed_won").length;
  const closedLost = leads.filter((l) => l.status === "closed_lost").length;

  const monthlySales = projects
    .filter((p) => p.created_at.slice(0, 7) === startOfMonth)
    .reduce((sum, p) => sum + p.sale_amount, 0);

  const pendingQuotations = quotations.filter((q) => q.status === "sent" || q.status === "draft").length;
  const activeProjects = projects.filter((p) => !["shipped", "delivered", "completed"].includes(p.current_stage)).length;
  const readyToShip = projects.filter((p) => p.current_stage === "ready_to_ship").length;

  const stageCounts = PROJECT_STAGE_ORDER.map((stage) => ({
    stage,
    label: PROJECT_STAGE_LABELS[stage],
    count: projects.filter((p) => p.current_stage === stage).length
  })).filter((s) => s.count > 0);

  const commissionPayable = commissions
    .filter((c) => c.status === "pending" || c.status === "approved")
    .reduce((sum, c) => sum + c.final_amount, 0);

  // Profit + expenses + pending balances: admin/accounts only
  let profitThisMonth: number | null = null;
  let expensesThisMonth: number | null = null;
  let pendingBalances: number | null = null;

  if (admin || profile.role === "accounts") {
    const { data: profitData } = await supabase.from("project_profit_summary").select("*");
    const monthlyProjectIds = new Set(
      projects.filter((p) => p.created_at.slice(0, 7) === startOfMonth).map((p) => p.id)
    );
    profitThisMonth = (profitData ?? [])
      .filter((row) => monthlyProjectIds.has(row.project_id))
      .reduce((sum, row) => sum + row.gross_profit, 0);

    const { data: expensesData } = await supabase
      .from("project_expenses")
      .select("*")
      .gte("created_at", `${startOfMonth}-01`);
    expensesThisMonth = ((expensesData ?? []) as ProjectExpense[]).reduce((sum, e) => sum + e.amount, 0);

    const { data: paymentSummaryData } = await supabase.from("project_payment_summary").select("*");
    pendingBalances = ((paymentSummaryData ?? []) as ProjectPaymentSummary[])
      .reduce((sum, row) => sum + Math.max(row.balance_pending, 0), 0);
  }

  const sourcePerformance = ACTIVE_LEAD_SOURCES.map((source) => ({
    source,
    label: LEAD_SOURCE_LABELS[source],
    total: leads.filter((l) => l.source === source).length,
    won: leads.filter((l) => l.source === source && l.status === "closed_won").length
  })).filter((s) => s.total > 0);

  const maxSourceTotal = Math.max(1, ...sourcePerformance.map((s) => s.total));

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">
          Welcome back, {profile.full_name.split(" ")[0]}
        </h1>
        <p className="text-sm text-slate-500">
          {admin ? "Company-wide overview" : "Your overview"} ·{" "}
          {new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Today's New Leads" value={todaysLeads} icon={UserPlus} accent="blue" />
        <StatCard label="Follow-ups Due" value={followUpsDue} icon={CalendarClock} accent="orange" />
        <StatCard label="Pending Quotations" value={pendingQuotations} icon={FileClock} accent="orange" />
        <StatCard label="Active Projects" value={activeProjects} icon={FolderKanban} accent="blue" />
        <StatCard label="Ready to Ship" value={readyToShip} icon={PackageCheck} accent="green" />
        <StatCard label="Total Leads" value={totalLeads} icon={Users} accent="blue" />
        <StatCard label="Closed Won" value={closedWon} icon={Trophy} accent="green" />
        <StatCard label="Closed Lost" value={closedLost} icon={XCircle} accent="red" />
      </div>

      <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="This Month's Sales" value={`$${monthlySales.toLocaleString()}`} icon={DollarSign} accent="green" />
        {expensesThisMonth !== null && (
          <StatCard label="This Month's Expenses" value={`$${expensesThisMonth.toLocaleString()}`} icon={Receipt} accent="orange" />
        )}
        {profitThisMonth !== null && (
          <StatCard
            label="Profit This Month"
            value={`$${profitThisMonth.toLocaleString()}`}
            icon={TrendingUp}
            accent={profitThisMonth >= 0 ? "green" : "red"}
          />
        )}
        {pendingBalances !== null && (
          <StatCard label="Pending Balances" value={`$${pendingBalances.toLocaleString()}`} icon={Wallet} accent="orange" />
        )}
        <StatCard label="Commission Payable" value={`$${commissionPayable.toLocaleString()}`} icon={Percent} accent="orange" />
      </div>

      {stageCounts.length > 0 && (
        <div className="mt-8 card p-6">
          <h2 className="mb-4 text-base font-semibold text-slate-900">Stage-wise Production Count</h2>
          <div className="flex flex-wrap gap-3">
            {stageCounts.map(({ stage, label, count }) => (
              <div key={stage} className="rounded-lg border border-slate-200 px-3 py-2 text-sm">
                <span className="font-medium text-slate-900">{count}</span>
                <span className="ml-1.5 text-slate-500">{label}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {sourcePerformance.length > 0 && (
        <div className="mt-8 card p-6">
          <h2 className="mb-4 text-base font-semibold text-slate-900">Lead Source Performance</h2>
          <div className="space-y-3">
            {sourcePerformance.map(({ source, label, total, won }) => (
              <div key={source} className="flex items-center gap-3">
                <span className="w-32 shrink-0 text-sm text-slate-600">{label}</span>
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-100">
                  <div
                    className="h-full rounded-full bg-brand-blue-500"
                    style={{ width: `${(total / maxSourceTotal) * 100}%` }}
                  />
                </div>
                <span className="w-24 shrink-0 text-right text-xs text-slate-500">
                  {total} leads · {won} won
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {!admin && totalLeads === 0 && (
        <div className="mt-8 rounded-lg border border-dashed border-slate-300 p-8 text-center text-sm text-slate-500">
          No leads assigned to you yet. New leads assigned by the Admin will appear here.
        </div>
      )}
    </div>
  );
}
