import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import type { Quotation, QuotationItem } from "@/types/database";

const COMPANY_NAME = "Antique Signage & Advertising";
const COMPANY_WEBSITE = "https://antiquesignage.com";
const BRAND_BLUE: [number, number, number] = [0, 64, 230];

export function generateQuotationPdf(quotation: Quotation, items: QuotationItem[]) {
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 40;

  // Header
  doc.setFillColor(...BRAND_BLUE);
  doc.rect(0, 0, pageWidth, 90, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(18);
  doc.setFont("helvetica", "bold");
  doc.text(COMPANY_NAME, margin, 40);
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.text(COMPANY_WEBSITE, margin, 58);
  doc.text("Custom Signage Manufacturing & Export", margin, 72);

  doc.setFontSize(16);
  doc.setFont("helvetica", "bold");
  doc.text("QUOTATION", pageWidth - margin, 40, { align: "right" });
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.text(quotation.quotation_number, pageWidth - margin, 58, { align: "right" });
  doc.text(new Date(quotation.created_at).toLocaleDateString(), pageWidth - margin, 72, { align: "right" });

  // Client info
  doc.setTextColor(20, 20, 20);
  let y = 120;
  doc.setFontSize(11);
  doc.setFont("helvetica", "bold");
  doc.text("Bill To:", margin, y);
  doc.setFont("helvetica", "normal");
  y += 16;
  doc.text(quotation.client_name, margin, y);
  if (quotation.company_name) {
    y += 14;
    doc.text(quotation.company_name, margin, y);
  }
  if (quotation.country) {
    y += 14;
    doc.text(quotation.country, margin, y);
  }
  if (quotation.email) {
    y += 14;
    doc.text(quotation.email, margin, y);
  }
  if (quotation.phone) {
    y += 14;
    doc.text(quotation.phone, margin, y);
  }

  // Line items table
  const tableStartY = y + 30;
  autoTable(doc, {
    startY: tableStartY,
    head: [["Sign Type", "Size", "Material", "Lighting", "Qty", "Unit Price", "Total"]],
    body: items.map((item) => [
      item.sign_type,
      item.size ?? "—",
      item.material ?? "—",
      item.lighting_type ?? "—",
      String(item.quantity),
      `$${item.unit_price.toLocaleString()}`,
      `$${item.line_total.toLocaleString()}`
    ]),
    headStyles: { fillColor: BRAND_BLUE, textColor: 255 },
    styles: { fontSize: 9, cellPadding: 6 },
    margin: { left: margin, right: margin }
  });

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const finalY = (doc as any).lastAutoTable.finalY as number;

  let totalsY = finalY + 24;
  doc.setFontSize(10);
  doc.text(`Subtotal:`, pageWidth - 200, totalsY);
  doc.text(`$${quotation.subtotal.toLocaleString()}`, pageWidth - margin, totalsY, { align: "right" });

  if (quotation.shipping_included) {
    totalsY += 16;
    doc.text(`Shipping:`, pageWidth - 200, totalsY);
    doc.text(`$${quotation.shipping_cost.toLocaleString()}`, pageWidth - margin, totalsY, { align: "right" });
  }

  totalsY += 20;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(12);
  doc.text(`Total:`, pageWidth - 200, totalsY);
  doc.text(`$${quotation.total_amount.toLocaleString()} USD`, pageWidth - margin, totalsY, { align: "right" });

  if (quotation.notes) {
    totalsY += 40;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.text("Notes:", margin, totalsY);
    doc.setFont("helvetica", "normal");
    const noteLines = doc.splitTextToSize(quotation.notes, pageWidth - margin * 2);
    doc.text(noteLines, margin, totalsY + 14);
  }

  // Footer
  const pageHeight = doc.internal.pageSize.getHeight();
  doc.setFontSize(8);
  doc.setTextColor(120, 120, 120);
  doc.text(
    `${COMPANY_NAME} · ${COMPANY_WEBSITE} · This quotation is valid for 30 days from the date above.`,
    pageWidth / 2,
    pageHeight - 30,
    { align: "center" }
  );

  doc.save(`${quotation.quotation_number}.pdf`);
}
