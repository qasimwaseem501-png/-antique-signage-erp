-- =========================================================
-- Phase 4 — Migration 0025
-- Ad spend tracking (company-wide, not tied to one project) —
-- needed for the "Ads Spend vs Sales" dashboard report.
-- =========================================================

create table public.ad_spend (
  id uuid primary key default uuid_generate_v4(),
  platform text not null,
  spend_date date not null default current_date,
  amount numeric(12,2) not null,
  notes text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create index idx_ad_spend_date on public.ad_spend (spend_date);
create index idx_ad_spend_platform on public.ad_spend (platform);

alter table public.ad_spend enable row level security;

create policy ad_spend_select_admin_or_accounts
  on public.ad_spend for select
  using (public.is_admin() or public.current_role() = 'accounts');

create policy ad_spend_write_admin_or_accounts
  on public.ad_spend for all
  using (public.is_admin() or public.current_role() = 'accounts')
  with check (public.is_admin() or public.current_role() = 'accounts');
