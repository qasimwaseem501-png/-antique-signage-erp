import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile, isOwner } from "@/lib/auth";
import { createLead } from "../actions";
import { ACTIVE_LEAD_SOURCES, LEAD_SOURCE_LABELS, type Profile } from "@/types/database";

export default async function NewLeadPage() {
  const profile = await getCurrentProfile();
  const owner = isOwner(profile);

  let salesTeam: Profile[] = [];
  if (owner) {
    const supabase = createClient();
    const { data } = await supabase
      .from("profiles")
      .select("*")
      .in("role", ["sales", "owner"])
      .eq("is_active", true);
    salesTeam = (data ?? []) as Profile[];
  }

  return (
    <div className="max-w-3xl">
      <h1 className="mb-6 text-2xl font-bold text-slate-900">New Lead</h1>

      <form action={createLead} className="card space-y-6 p-6">
        <div>
          <h2 className="mb-3 text-sm font-semibold text-slate-900">Client Information</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor="client_name">Client Name *</label>
              <input id="client_name" name="client_name" required className="input" />
            </div>
            <div>
              <label className="label" htmlFor="company_name">Company Name</label>
              <input id="company_name" name="company_name" className="input" />
            </div>
            <div>
              <label className="label" htmlFor="country">Country</label>
              <input id="country" name="country" className="input" placeholder="USA, UK, Canada..." />
            </div>
            <div>
              <label className="label" htmlFor="city">City</label>
              <input id="city" name="city" className="input" />
            </div>
            <div>
              <label className="label" htmlFor="phone">Phone</label>
              <input id="phone" name="phone" className="input" />
            </div>
            <div>
              <label className="label" htmlFor="whatsapp">WhatsApp</label>
              <input id="whatsapp" name="whatsapp" className="input" />
            </div>
            <div>
              <label className="label" htmlFor="email">Email</label>
              <input id="email" name="email" type="email" className="input" />
            </div>
            <div>
              <label className="label" htmlFor="website">Website</label>
              <input id="website" name="website" className="input" />
            </div>
          </div>
        </div>

        <div>
          <h2 className="mb-3 text-sm font-semibold text-slate-900">Lead Details</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor="source">Source *</label>
              <select id="source" name="source" required className="input" defaultValue="">
                <option value="" disabled>Select source</option>
                {ACTIVE_LEAD_SOURCES.map((source) => (
                  <option key={source} value={source}>
                    {LEAD_SOURCE_LABELS[source]}
                  </option>
                ))}
              </select>
            </div>

            {owner && (
              <div>
                <label className="label" htmlFor="assigned_to">Assign To</label>
                <select id="assigned_to" name="assigned_to" className="input" defaultValue={profile.id}>
                  {salesTeam.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.full_name}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div>
              <label className="label" htmlFor="follow_up_date">Follow Up Date</label>
              <input id="follow_up_date" name="follow_up_date" type="date" className="input" />
            </div>
            <div>
              <label className="label" htmlFor="expected_close_date">Expected Close Date</label>
              <input id="expected_close_date" name="expected_close_date" type="date" className="input" />
            </div>
          </div>
          <div className="mt-4">
            <label className="label" htmlFor="notes">Notes</label>
            <textarea id="notes" name="notes" rows={3} className="input" />
          </div>
        </div>

        <div className="flex justify-end gap-3 border-t border-slate-100 pt-4">
          <button type="submit" className="btn-primary">
            Create Lead
          </button>
        </div>
      </form>
    </div>
  );
}
