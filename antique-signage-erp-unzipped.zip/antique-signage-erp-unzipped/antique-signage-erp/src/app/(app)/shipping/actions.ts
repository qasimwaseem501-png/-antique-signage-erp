"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile } from "@/lib/auth";

export interface BoxInput {
  length_cm: number;
  width_cm: number;
  height_cm: number;
  actual_weight_kg: number;
}

export async function createShipment(input: {
  project_id: string;
  country: string;
  courier: string;
  tracking_number: string;
  duty_status: string;
  oversize_charge: number;
  overweight_charge: number;
  boxes: BoxInput[];
}) {
  const profile = await getCurrentProfile();
  const supabase = createClient();

  const { data: rateRow } = await supabase
    .from("shipping_rates")
    .select("*")
    .eq("country", input.country)
    .maybeSingle();

  const { data: shipment, error } = await supabase
    .from("shipments")
    .insert({
      project_id: input.project_id,
      country: input.country,
      courier: input.courier || null,
      tracking_number: input.tracking_number || null,
      duty_status: (rateRow?.duty_status as string) ?? input.duty_status,
      rate_pkr_per_kg: rateRow?.rate_pkr_per_kg ?? 0,
      oversize_charge: input.oversize_charge,
      overweight_charge: input.overweight_charge,
      created_by: profile.id
    })
    .select()
    .single();

  if (error) throw new Error(error.message);

  if (input.boxes.length > 0) {
    const { error: boxError } = await supabase.from("shipment_boxes").insert(
      input.boxes.map((box, index) => ({
        shipment_id: shipment.id,
        box_number: index + 1,
        length_cm: box.length_cm,
        width_cm: box.width_cm,
        height_cm: box.height_cm,
        actual_weight_kg: box.actual_weight_kg
      }))
    );
    if (boxError) throw new Error(boxError.message);
  }

  revalidatePath("/shipping");
  redirect("/shipping");
}

export async function updateDeliveryStatus(shipmentId: string, status: string) {
  const supabase = createClient();
  const { error } = await supabase.from("shipments").update({ delivery_status: status }).eq("id", shipmentId);
  if (error) throw new Error(error.message);
  revalidatePath("/shipping");
}

export async function updateShippingRate(country: string, ratePkrPerKg: number, dutyStatus: string) {
  const supabase = createClient();
  const { error } = await supabase
    .from("shipping_rates")
    .upsert({ country, rate_pkr_per_kg: ratePkrPerKg, duty_status: dutyStatus });
  if (error) throw new Error(error.message);
  revalidatePath("/shipping");
}
