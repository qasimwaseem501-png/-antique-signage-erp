"use client";

import { useState, useTransition } from "react";
import { createInventoryItem, recordInventoryTransaction } from "@/app/(app)/inventory/actions";
import { INVENTORY_CATEGORY_LABELS, type InventoryCategory, type InventoryItem, type InventoryTransactionType } from "@/types/database";

export function NewInventoryItemForm() {
  const [name, setName] = useState("");
  const [category, setCategory] = useState<InventoryCategory>("acm_sheet");
  const [unit, setUnit] = useState("pcs");
  const [threshold, setThreshold] = useState(5);
  const [isPending, startTransition] = useTransition();

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    startTransition(async () => {
      await createInventoryItem(name, category, unit, threshold);
      setName("");
    });
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <div className="grid grid-cols-2 gap-3">
        <input className="input" placeholder="Item name" value={name} onChange={(e) => setName(e.target.value)} />
        <select className="input" value={category} onChange={(e) => setCategory(e.target.value as InventoryCategory)}>
          {Object.entries(INVENTORY_CATEGORY_LABELS).map(([value, label]) => (
            <option key={value} value={value}>{label}</option>
          ))}
        </select>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <input className="input" placeholder="Unit (pcs, sheet, roll...)" value={unit} onChange={(e) => setUnit(e.target.value)} />
        <input type="number" min={0} className="input" placeholder="Low stock threshold" value={threshold} onChange={(e) => setThreshold(Number(e.target.value))} />
      </div>
      <button type="submit" disabled={isPending || !name.trim()} className="btn-primary">
        Add Item
      </button>
    </form>
  );
}

export function StockTransactionForm({ items }: { items: InventoryItem[] }) {
  const [itemId, setItemId] = useState("");
  const [type, setType] = useState<InventoryTransactionType>("in");
  const [quantity, setQuantity] = useState(0);
  const [notes, setNotes] = useState("");
  const [isPending, startTransition] = useTransition();

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!itemId || quantity <= 0) return;
    startTransition(async () => {
      await recordInventoryTransaction(itemId, type, quantity, null, notes);
      setQuantity(0);
      setNotes("");
    });
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <select className="input" value={itemId} onChange={(e) => setItemId(e.target.value)}>
        <option value="" disabled>Select item</option>
        {items.map((item) => (
          <option key={item.id} value={item.id}>{item.name} ({item.current_stock} {item.unit})</option>
        ))}
      </select>
      <div className="grid grid-cols-2 gap-3">
        <select className="input" value={type} onChange={(e) => setType(e.target.value as InventoryTransactionType)}>
          <option value="in">Stock In</option>
          <option value="out">Stock Out</option>
        </select>
        <input type="number" min={0} step="0.01" className="input" placeholder="Quantity" value={quantity || ""} onChange={(e) => setQuantity(Number(e.target.value))} />
      </div>
      <input className="input" placeholder="Notes (optional)" value={notes} onChange={(e) => setNotes(e.target.value)} />
      <button type="submit" disabled={isPending || !itemId || quantity <= 0} className="btn-primary">
        Record Transaction
      </button>
    </form>
  );
}
