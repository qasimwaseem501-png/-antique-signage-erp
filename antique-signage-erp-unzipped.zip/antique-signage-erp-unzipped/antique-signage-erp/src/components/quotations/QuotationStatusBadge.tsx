import { QUOTATION_STATUS_LABELS, type QuotationStatus } from "@/types/database";

const STYLES: Record<QuotationStatus, string> = {
  draft: "bg-slate-100 text-slate-700",
  sent: "bg-blue-100 text-blue-700",
  approved: "bg-green-100 text-green-700",
  rejected: "bg-red-100 text-red-700"
};

export function QuotationStatusBadge({ status }: { status: QuotationStatus }) {
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ${STYLES[status]}`}>
      {QUOTATION_STATUS_LABELS[status]}
    </span>
  );
}
