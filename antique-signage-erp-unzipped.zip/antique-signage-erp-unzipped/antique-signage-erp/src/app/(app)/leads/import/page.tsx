import { createClient } from "@/lib/supabase/server";
import { LeadImportForm } from "./LeadImportForm";
import type { Profile } from "@/types/database";

export default async function ImportLeadsPage() {
  const supabase = createClient();
  const { data } = await supabase
    .from("profiles")
    .select("*")
    .in("role", ["sales", "admin", "owner"])
    .eq("is_active", true);

  return <LeadImportForm team={(data ?? []) as Profile[]} />;
}
