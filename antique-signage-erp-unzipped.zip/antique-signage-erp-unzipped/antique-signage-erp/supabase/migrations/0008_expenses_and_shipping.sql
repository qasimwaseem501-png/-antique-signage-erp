-- =========================================================
-- Phase 2 — Migration 0008
-- Expenses & Profit + Shipping Module
-- =========================================================

create type expense_category as enum (
  'material', 'labor', 'powder_coating', 'led_power_supply', 'packing', 'shipping', 'ads', 'other'
);

create table public.project_expenses (
  id uuid primary key default uuid_generate_v4(),
  project_id uuid not null references public.projects(id) on delete cascade,
  category expense_category not null,
  amount numeric(12,2) not null default 0,
  description text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create index idx_expenses_project on public.project_expenses (project_id);
create index idx_expenses_category on public.project_expenses (category);

-- Convenience view: per-project cost, sale amount, gross profit, profit %
-- security_invoker ensures this view respects the querying user's RLS
-- permissions on projects/project_expenses, rather than the view owner's.
create view public.project_profit_summary
with (security_invoker = true)
as
select
  p.id as project_id,
  p.project_code,
  p.client_name,
  p.sale_amount,
  coalesce(sum(e.amount), 0) as total_cost,
  p.sale_amount - coalesce(sum(e.amount), 0) as gross_profit,
  case
    when p.sale_amount > 0
    then round(((p.sale_amount - coalesce(sum(e.amount), 0)) / p.sale_amount) * 100, 2)
    else 0
  end as profit_percentage
from public.projects p
left join public.project_expenses e on e.project_id = p.id
group by p.id, p.project_code, p.client_name, p.sale_amount;

-- =========================================================
-- SHIPPING MODULE
-- =========================================================

create type duty_status as enum ('duty_paid', 'duty_unpaid', 'not_applicable');

create table public.shipments (
  id uuid primary key default uuid_generate_v4(),
  project_id uuid not null references public.projects(id) on delete cascade,

  country text not null,
  courier text,

  box_length_cm numeric(8,2),
  box_width_cm numeric(8,2),
  box_height_cm numeric(8,2),
  actual_weight_kg numeric(8,2),
  volumetric_weight_kg numeric(8,2),

  tracking_number text,
  shipping_cost numeric(12,2) not null default 0,
  duty_status duty_status not null default 'not_applicable',
  delivery_status text not null default 'pending',

  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_shipments_project on public.shipments (project_id);

create trigger trg_shipments_updated_at before update on public.shipments
  for each row execute function public.set_updated_at();

-- Auto-calculate volumetric weight using the standard air-freight divisor (5000)
create or replace function public.calc_volumetric_weight()
returns trigger
language plpgsql
as $$
begin
  if new.box_length_cm is not null and new.box_width_cm is not null and new.box_height_cm is not null then
    new.volumetric_weight_kg := round(
      (new.box_length_cm * new.box_width_cm * new.box_height_cm) / 5000.0, 2
    );
  end if;
  return new;
end;
$$;

create trigger trg_shipments_calc_volumetric
  before insert or update on public.shipments
  for each row execute function public.calc_volumetric_weight();

-- When a shipment is marked delivered, advance the project stage automatically
create or replace function public.handle_shipment_delivered()
returns trigger
language plpgsql
as $$
begin
  if new.delivery_status = 'delivered' and old.delivery_status is distinct from 'delivered' then
    update public.projects set current_stage = 'delivered' where id = new.project_id;
  end if;
  return new;
end;
$$;

create trigger trg_shipments_delivered
  after update on public.shipments
  for each row execute function public.handle_shipment_delivered();
