import { createClient } from "@/lib/supabase/server";
import { createTask } from "../actions";
import type { Profile, Project } from "@/types/database";

export default async function NewTaskPage() {
  const supabase = createClient();

  const [{ data: teamData }, { data: projectsData }] = await Promise.all([
    supabase.from("profiles").select("*").eq("is_active", true).neq("role", "client"),
    supabase.from("projects").select("*").order("created_at", { ascending: false })
  ]);

  const team = (teamData ?? []) as Profile[];
  const projects = (projectsData ?? []) as Project[];

  return (
    <div className="max-w-2xl">
      <h1 className="mb-6 text-2xl font-bold text-slate-900">New Task</h1>

      <form action={createTask} className="card space-y-4 p-6">
        <div>
          <label className="label">Title *</label>
          <input name="title" required className="input" />
        </div>
        <div>
          <label className="label">Description</label>
          <textarea name="description" rows={3} className="input" />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label">Assign To</label>
            <select name="assigned_to" className="input" defaultValue="">
              <option value="">Unassigned</option>
              {team.map((member) => (
                <option key={member.id} value={member.id}>{member.full_name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">Related Project (optional)</label>
            <select name="project_id" className="input" defaultValue="">
              <option value="">None</option>
              {projects.map((p) => (
                <option key={p.id} value={p.id}>{p.project_code} · {p.client_name}</option>
              ))}
            </select>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label">Priority</label>
            <select name="priority" className="input" defaultValue="medium">
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
              <option value="urgent">Urgent</option>
            </select>
          </div>
          <div>
            <label className="label">Due Date</label>
            <input name="due_date" type="date" className="input" />
          </div>
        </div>
        <div className="flex justify-end border-t border-slate-100 pt-4">
          <button type="submit" className="btn-primary">Create Task</button>
        </div>
      </form>
    </div>
  );
}
