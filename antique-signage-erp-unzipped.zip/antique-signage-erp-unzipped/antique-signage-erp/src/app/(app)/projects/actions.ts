"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile } from "@/lib/auth";
import type { ExpenseCategory, ProjectFileCategory } from "@/types/database";

export async function updateProjectStage(
  projectId: string,
  stage: string,
  stageAssignee: string | null
) {
  const supabase = createClient();
  const { error } = await supabase
    .from("projects")
    .update({ current_stage: stage, stage_assignee: stageAssignee })
    .eq("id", projectId);
  if (error) throw new Error(error.message);
  revalidatePath(`/projects/${projectId}`);
  revalidatePath("/projects");
  revalidatePath("/production");
}

export async function updateProjectDetails(
  projectId: string,
  data: { expected_delivery_date: string | null; internal_notes: string }
) {
  const supabase = createClient();
  const { error } = await supabase
    .from("projects")
    .update({
      expected_delivery_date: data.expected_delivery_date,
      internal_notes: data.internal_notes
    })
    .eq("id", projectId);
  if (error) throw new Error(error.message);
  revalidatePath(`/projects/${projectId}`);
}

export async function addProjectExpense(
  projectId: string,
  category: ExpenseCategory,
  amount: number,
  description: string
) {
  const profile = await getCurrentProfile();
  const supabase = createClient();
  const { error } = await supabase.from("project_expenses").insert({
    project_id: projectId,
    category,
    amount,
    description: description || null,
    created_by: profile.id
  });
  if (error) throw new Error(error.message);
  revalidatePath(`/projects/${projectId}`);
  revalidatePath("/expenses");
}

export async function addProjectFile(
  projectId: string,
  category: ProjectFileCategory,
  fileName: string,
  storagePath: string
) {
  const profile = await getCurrentProfile();
  const supabase = createClient();
  const { error } = await supabase.from("project_files").insert({
    project_id: projectId,
    category,
    file_name: fileName,
    storage_path: storagePath,
    uploaded_by: profile.id
  });
  if (error) throw new Error(error.message);
  revalidatePath(`/projects/${projectId}`);
}
