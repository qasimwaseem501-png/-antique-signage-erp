"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile } from "@/lib/auth";
import type { InventoryCategory, InventoryTransactionType } from "@/types/database";

export async function createInventoryItem(
  name: string,
  category: InventoryCategory,
  unit: string,
  lowStockThreshold: number
) {
  const supabase = createClient();
  const { error } = await supabase.from("inventory_items").insert({
    name,
    category,
    unit,
    low_stock_threshold: lowStockThreshold
  });
  if (error) throw new Error(error.message);
  revalidatePath("/inventory");
}

export async function recordInventoryTransaction(
  itemId: string,
  type: InventoryTransactionType,
  quantity: number,
  projectId: string | null,
  notes: string
) {
  const profile = await getCurrentProfile();
  const supabase = createClient();
  const { error } = await supabase.from("inventory_transactions").insert({
    item_id: itemId,
    transaction_type: type,
    quantity,
    project_id: projectId,
    notes: notes || null,
    created_by: profile.id
  });
  if (error) throw new Error(error.message);
  revalidatePath("/inventory");
}

export async function createSupplier(formData: FormData) {
  const supabase = createClient();
  const { error } = await supabase.from("suppliers").insert({
    name: formData.get("name") as string,
    contact_person: (formData.get("contact_person") as string) || null,
    phone: (formData.get("phone") as string) || null,
    email: (formData.get("email") as string) || null,
    address: (formData.get("address") as string) || null
  });
  if (error) throw new Error(error.message);
  revalidatePath("/inventory/suppliers");
}

export interface PoItemInput {
  description: string;
  inventory_item_id: string | null;
  quantity: number;
  unit_cost: number;
}

export async function createPurchaseOrder(input: {
  supplier_id: string;
  expected_date: string;
  notes: string;
  items: PoItemInput[];
}) {
  const profile = await getCurrentProfile();
  const supabase = createClient();

  const { data: po, error } = await supabase
    .from("purchase_orders")
    .insert({
      supplier_id: input.supplier_id,
      expected_date: input.expected_date || null,
      notes: input.notes || null,
      created_by: profile.id
    })
    .select()
    .single();

  if (error) throw new Error(error.message);

  if (input.items.length > 0) {
    const { error: itemsError } = await supabase.from("purchase_order_items").insert(
      input.items.map((item) => ({
        po_id: po.id,
        description: item.description,
        inventory_item_id: item.inventory_item_id,
        quantity: item.quantity,
        unit_cost: item.unit_cost
      }))
    );
    if (itemsError) throw new Error(itemsError.message);
  }

  revalidatePath("/inventory/purchase-orders");
  redirect("/inventory/purchase-orders");
}

export async function updatePoStatus(poId: string, status: string) {
  const supabase = createClient();
  const { error } = await supabase.from("purchase_orders").update({ status }).eq("id", poId);
  if (error) throw new Error(error.message);
  revalidatePath("/inventory/purchase-orders");
}
