-- =========================================================
-- Phase 4 — Migration 0022
-- Task & Team Management
-- =========================================================

create type task_priority as enum ('low', 'medium', 'high', 'urgent');
create type task_status as enum ('todo', 'in_progress', 'done', 'blocked');

create table public.tasks (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  description text,
  project_id uuid references public.projects(id) on delete set null,

  assigned_to uuid references public.profiles(id),
  priority task_priority not null default 'medium',
  status task_status not null default 'todo',
  due_date date,

  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_tasks_assigned_to on public.tasks (assigned_to);
create index idx_tasks_status on public.tasks (status);
create index idx_tasks_project on public.tasks (project_id);
create index idx_tasks_due_date on public.tasks (due_date);

create trigger trg_tasks_updated_at before update on public.tasks
  for each row execute function public.set_updated_at();

create table public.task_comments (
  id uuid primary key default uuid_generate_v4(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  comment text not null,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create index idx_task_comments_task on public.task_comments (task_id, created_at);

create table public.task_files (
  id uuid primary key default uuid_generate_v4(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  file_name text not null,
  storage_path text not null,
  uploaded_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create index idx_task_files_task on public.task_files (task_id);

alter table public.tasks enable row level security;
alter table public.task_comments enable row level security;
alter table public.task_files enable row level security;

create policy tasks_select_scoped
  on public.tasks for select
  using (public.is_admin() or assigned_to = auth.uid() or created_by = auth.uid());

create policy tasks_insert_authenticated
  on public.tasks for insert
  with check (auth.uid() is not null and public.current_role() != 'client');

create policy tasks_update_scoped
  on public.tasks for update
  using (public.is_admin() or assigned_to = auth.uid() or created_by = auth.uid());

create policy tasks_delete_admin_or_creator
  on public.tasks for delete
  using (public.is_admin() or created_by = auth.uid());

create policy task_comments_select_via_task
  on public.task_comments for select
  using (
    exists (
      select 1 from public.tasks t
      where t.id = task_comments.task_id
      and (public.is_admin() or t.assigned_to = auth.uid() or t.created_by = auth.uid())
    )
  );

create policy task_comments_insert_via_task
  on public.task_comments for insert
  with check (
    exists (
      select 1 from public.tasks t
      where t.id = task_comments.task_id
      and (public.is_admin() or t.assigned_to = auth.uid() or t.created_by = auth.uid())
    )
  );

create policy task_files_select_via_task
  on public.task_files for select
  using (
    exists (
      select 1 from public.tasks t
      where t.id = task_files.task_id
      and (public.is_admin() or t.assigned_to = auth.uid() or t.created_by = auth.uid())
    )
  );

create policy task_files_insert_via_task
  on public.task_files for insert
  with check (
    exists (
      select 1 from public.tasks t
      where t.id = task_files.task_id
      and (public.is_admin() or t.assigned_to = auth.uid() or t.created_by = auth.uid())
    )
  );
