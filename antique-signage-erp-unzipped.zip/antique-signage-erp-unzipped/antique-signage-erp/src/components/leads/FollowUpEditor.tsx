"use client";

import { useState, useTransition } from "react";
import { updateLeadFollowUp } from "@/app/(app)/leads/actions";

export function FollowUpEditor({
  leadId,
  followUpDate,
  nextAction
}: {
  leadId: string;
  followUpDate: string | null;
  nextAction: string | null;
}) {
  const [date, setDate] = useState(followUpDate ?? "");
  const [action, setAction] = useState(nextAction ?? "");
  const [isPending, startTransition] = useTransition();

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    startTransition(() => updateLeadFollowUp(leadId, date || null, action));
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <div>
        <label className="label">Follow-up Date</label>
        <input type="date" className="input" value={date} onChange={(e) => setDate(e.target.value)} />
      </div>
      <div>
        <label className="label">Next Action</label>
        <input
          className="input"
          placeholder="e.g. Call client about design approval"
          value={action}
          onChange={(e) => setAction(e.target.value)}
        />
      </div>
      <button type="submit" disabled={isPending} className="btn-secondary">
        {isPending ? "Saving..." : "Save"}
      </button>
    </form>
  );
}
