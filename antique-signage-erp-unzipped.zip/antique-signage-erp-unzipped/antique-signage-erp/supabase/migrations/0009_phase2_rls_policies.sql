-- =========================================================
-- Phase 2 — Migration 0009
-- Row Level Security for Quotations, Projects, Production,
-- Commission, Expenses, Shipping.
--
-- Role summary enforced below:
--   admin     — full access everywhere
--   sales     — own assigned leads/quotations + own commissions only
--   designer  — projects/stages in design_pending / design_approved
--   production— projects/stages in the fabrication stages
--   packing   — projects/stages in packing/ready_to_ship + shipments
--   accounts  — quotations, expenses, commissions (read), for finance ops
-- =========================================================

-- ---------------------------------------------------------
-- Helper: production-stage set, used by the 'production' role
-- ---------------------------------------------------------
create or replace function public.is_production_stage(s project_stage)
returns boolean
language sql
immutable
as $$
  select s in (
    'material_purchase', 'cnc_laser_cutting', 'letter_bending',
    'welding_fabrication', 'powder_coating', 'led_wiring', 'testing'
  );
$$;

create or replace function public.is_design_stage(s project_stage)
returns boolean
language sql
immutable
as $$
  select s in ('design_pending', 'design_approved');
$$;

create or replace function public.is_packing_stage(s project_stage)
returns boolean
language sql
immutable
as $$
  select s in ('packing', 'ready_to_ship');
$$;

-- =========================================================
-- QUOTATIONS
-- =========================================================

alter table public.quotations enable row level security;
alter table public.quotation_items enable row level security;

create policy quotations_select_scoped
  on public.quotations for select
  using (
    public.is_admin()
    or public.current_role() = 'accounts'
    or created_by = auth.uid()
    or exists (
      select 1 from public.leads l
      where l.id = quotations.lead_id and l.assigned_to = auth.uid()
    )
  );

create policy quotations_insert_scoped
  on public.quotations for insert
  with check (
    public.is_admin()
    or public.current_role() = 'sales'
  );

create policy quotations_update_scoped
  on public.quotations for update
  using (
    public.is_admin()
    or created_by = auth.uid()
  );

-- Only Admin can delete quotations
create policy quotations_delete_admin_only
  on public.quotations for delete
  using (public.is_admin());

-- Quotation items follow their parent quotation's visibility
create policy quotation_items_select_via_quotation
  on public.quotation_items for select
  using (
    exists (
      select 1 from public.quotations q
      where q.id = quotation_items.quotation_id
      and (
        public.is_admin()
        or public.current_role() = 'accounts'
        or q.created_by = auth.uid()
        or exists (select 1 from public.leads l where l.id = q.lead_id and l.assigned_to = auth.uid())
      )
    )
  );

create policy quotation_items_write_via_quotation
  on public.quotation_items for all
  using (
    exists (
      select 1 from public.quotations q
      where q.id = quotation_items.quotation_id
      and (public.is_admin() or q.created_by = auth.uid())
    )
  )
  with check (
    exists (
      select 1 from public.quotations q
      where q.id = quotation_items.quotation_id
      and (public.is_admin() or q.created_by = auth.uid())
    )
  );

-- =========================================================
-- PROJECTS
-- Visibility: Admin sees all. Sales sees projects tied to their
-- own leads. Designer/Production/Packing see projects currently
-- in their relevant stage(s). Accounts sees all (for cost/quote context).
-- =========================================================

alter table public.projects enable row level security;
alter table public.project_stage_history enable row level security;
alter table public.project_files enable row level security;

create policy projects_select_scoped
  on public.projects for select
  using (
    public.is_admin()
    or public.current_role() = 'accounts'
    or exists (select 1 from public.leads l where l.id = projects.lead_id and l.assigned_to = auth.uid())
    or (public.current_role() = 'designer' and public.is_design_stage(current_stage))
    or (public.current_role() = 'production' and public.is_production_stage(current_stage))
    or (public.current_role() = 'packing' and public.is_packing_stage(current_stage))
  );

create policy projects_insert_admin_or_sales
  on public.projects for insert
  with check (public.is_admin() or public.current_role() = 'sales');

-- Stage updates allowed for Admin, or whoever's role matches the
-- project's current stage (so a designer can only move design-stage
-- projects forward, production only production-stage, etc.)
create policy projects_update_scoped
  on public.projects for update
  using (
    public.is_admin()
    or (public.current_role() = 'designer' and public.is_design_stage(current_stage))
    or (public.current_role() = 'production' and public.is_production_stage(current_stage))
    or (public.current_role() = 'packing' and public.is_packing_stage(current_stage))
  );

create policy projects_delete_admin_only
  on public.projects for delete
  using (public.is_admin());

create policy stage_history_select_via_project
  on public.project_stage_history for select
  using (
    exists (
      select 1 from public.projects p where p.id = project_stage_history.project_id
    )
    and (
      public.is_admin()
      or public.current_role() = 'accounts'
      or exists (
        select 1 from public.projects p
        where p.id = project_stage_history.project_id
        and (
          exists (select 1 from public.leads l where l.id = p.lead_id and l.assigned_to = auth.uid())
          or (public.current_role() = 'designer' and public.is_design_stage(p.current_stage))
          or (public.current_role() = 'production' and public.is_production_stage(p.current_stage))
          or (public.current_role() = 'packing' and public.is_packing_stage(p.current_stage))
        )
      )
    )
  );

-- Stage history is an immutable system-generated audit trail: insert only, via trigger (security definer not required since trigger runs as invoker by default here; allow authenticated insert)
create policy stage_history_insert_authenticated
  on public.project_stage_history for insert
  with check (auth.uid() is not null);

create policy project_files_select_via_project
  on public.project_files for select
  using (
    public.is_admin()
    or public.current_role() = 'accounts'
    or exists (
      select 1 from public.projects p
      where p.id = project_files.project_id
      and (
        exists (select 1 from public.leads l where l.id = p.lead_id and l.assigned_to = auth.uid())
        or (public.current_role() = 'designer' and public.is_design_stage(p.current_stage))
        or (public.current_role() = 'production' and public.is_production_stage(p.current_stage))
        or (public.current_role() = 'packing' and public.is_packing_stage(p.current_stage))
      )
    )
  );

create policy project_files_insert_via_project
  on public.project_files for insert
  with check (auth.uid() is not null);

create policy project_files_delete_admin_only
  on public.project_files for delete
  using (public.is_admin());

-- =========================================================
-- COMMISSIONS
-- Sales can see only their own commissions. Accounts can see all
-- (needed to approve/pay). Admin full access + override.
-- =========================================================

alter table public.commissions enable row level security;

create policy commissions_select_scoped
  on public.commissions for select
  using (
    public.is_admin()
    or public.current_role() = 'accounts'
    or employee_id = auth.uid()
  );

-- Only Admin/Accounts can create commissions manually (auto-creation
-- via trigger runs as the table owner and bypasses RLS on insert).
create policy commissions_insert_admin_or_accounts
  on public.commissions for insert
  with check (public.is_admin() or public.current_role() = 'accounts');

-- Only Admin/Accounts can update (approve, override, mark paid)
create policy commissions_update_admin_or_accounts
  on public.commissions for update
  using (public.is_admin() or public.current_role() = 'accounts');

create policy commissions_delete_admin_only
  on public.commissions for delete
  using (public.is_admin());

-- =========================================================
-- PROJECT EXPENSES
-- Admin + Accounts full visibility (needed for profit reporting).
-- Production/Packing can log costs for projects in their own stage.
-- =========================================================

alter table public.project_expenses enable row level security;

create policy expenses_select_scoped
  on public.project_expenses for select
  using (
    public.is_admin()
    or public.current_role() = 'accounts'
    or exists (
      select 1 from public.projects p
      where p.id = project_expenses.project_id
      and (
        (public.current_role() = 'production' and public.is_production_stage(p.current_stage))
        or (public.current_role() = 'packing' and public.is_packing_stage(p.current_stage))
        or (public.current_role() = 'designer' and public.is_design_stage(p.current_stage))
      )
    )
  );

create policy expenses_insert_scoped
  on public.project_expenses for insert
  with check (
    public.is_admin()
    or public.current_role() = 'accounts'
    or exists (
      select 1 from public.projects p
      where p.id = project_expenses.project_id
      and (
        (public.current_role() = 'production' and public.is_production_stage(p.current_stage))
        or (public.current_role() = 'packing' and public.is_packing_stage(p.current_stage))
      )
    )
  );

create policy expenses_update_admin_or_accounts
  on public.project_expenses for update
  using (public.is_admin() or public.current_role() = 'accounts');

create policy expenses_delete_admin_only
  on public.project_expenses for delete
  using (public.is_admin());

-- =========================================================
-- SHIPMENTS
-- Packing role manages shipments. Admin/Accounts full visibility.
-- =========================================================

alter table public.shipments enable row level security;

create policy shipments_select_scoped
  on public.shipments for select
  using (
    public.is_admin()
    or public.current_role() in ('accounts', 'packing')
    or exists (
      select 1 from public.projects p
      join public.leads l on l.id = p.lead_id
      where p.id = shipments.project_id and l.assigned_to = auth.uid()
    )
  );

create policy shipments_insert_scoped
  on public.shipments for insert
  with check (public.is_admin() or public.current_role() = 'packing');

create policy shipments_update_scoped
  on public.shipments for update
  using (public.is_admin() or public.current_role() = 'packing');

create policy shipments_delete_admin_only
  on public.shipments for delete
  using (public.is_admin());

-- =========================================================
-- Extend existing profiles RLS: 'accounts' role should be able to
-- see basic profile info (names) for reporting/commission context.
-- (Existing policy already allows self + admin; this adds read-all
-- for accounts specifically, scoped to non-sensitive columns is not
-- enforceable via RLS alone, so the app layer avoids rendering
-- salary/HR fields for accounts — RLS just grants row visibility.)
-- =========================================================

create policy profiles_select_accounts_readonly
  on public.profiles for select
  using (public.current_role() = 'accounts');
