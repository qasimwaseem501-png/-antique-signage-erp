-- =========================================================
-- Phase 2 — Migration 0010
-- CRITICAL: Phase 1's RLS policies (clients, leads, client_files,
-- storage.objects) all call public.is_owner(), which only checked
-- role = 'owner'. Since migration 0005 moved existing owner accounts
-- to role = 'admin', we must update is_owner() itself so every
-- existing Phase 1 policy keeps working without being rewritten.
-- =========================================================

create or replace function public.is_owner()
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select coalesce(
    (select role from public.profiles where id = auth.uid()) in ('owner', 'admin'),
    false
  );
$$;
