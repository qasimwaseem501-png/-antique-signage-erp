"use client";

import { useRef, useState } from "react";
import { Upload } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { addProjectFile } from "@/app/(app)/projects/actions";
import type { ProjectFileCategory } from "@/types/database";

const CATEGORIES: { value: ProjectFileCategory; label: string }[] = [
  { value: "design", label: "Design File" },
  { value: "photo", label: "Photo" },
  { value: "video", label: "Video" },
  { value: "invoice", label: "Invoice" },
  { value: "shipping_doc", label: "Shipping Document" },
  { value: "packing_photo", label: "Packing Photo" },
  { value: "tracking_receipt", label: "Tracking Receipt" },
  { value: "other", label: "Other" }
];

export function ProjectFileUpload({ projectId }: { projectId: string }) {
  const [category, setCategory] = useState<ProjectFileCategory>("photo");
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const supabase = createClient();

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setError(null);

    try {
      const path = `projects/${projectId}/${Date.now()}-${file.name}`;
      const { error: uploadError } = await supabase.storage.from("client-files").upload(path, file);
      if (uploadError) throw uploadError;

      await addProjectFile(projectId, category, file.name, path);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setUploading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  return (
    <div className="space-y-2">
      {error && <p className="text-sm text-red-600">{error}</p>}
      <div className="flex flex-wrap items-center gap-2">
        <select className="input max-w-[200px]" value={category} onChange={(e) => setCategory(e.target.value as ProjectFileCategory)}>
          {CATEGORIES.map((c) => (
            <option key={c.value} value={c.value}>{c.label}</option>
          ))}
        </select>
        <label className="btn-secondary cursor-pointer">
          <Upload className="h-4 w-4" />
          {uploading ? "Uploading..." : "Upload File"}
          <input ref={inputRef} type="file" className="hidden" onChange={handleFileChange} disabled={uploading} />
        </label>
      </div>
    </div>
  );
}
