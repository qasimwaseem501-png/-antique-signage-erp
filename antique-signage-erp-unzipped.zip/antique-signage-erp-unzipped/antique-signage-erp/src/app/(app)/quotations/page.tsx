import Link from "next/link";
import { Plus } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile } from "@/lib/auth";
import { QuotationStatusBadge } from "@/components/quotations/QuotationStatusBadge";
import type { Quotation } from "@/types/database";

export default async function QuotationsPage() {
  const profile = await getCurrentProfile();
  const supabase = createClient();

  const { data } = await supabase
    .from("quotations")
    .select("*")
    .order("created_at", { ascending: false });

  const quotations = (data ?? []) as Quotation[];
  const canCreate = ["owner", "admin", "sales"].includes(profile.role);

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Quotations</h1>
          <p className="text-sm text-slate-500">Create and track client quotations</p>
        </div>
        {canCreate && (
          <Link href="/quotations/new" className="btn-primary">
            <Plus className="h-4 w-4" />
            New Quotation
          </Link>
        )}
      </div>

      <div className="card overflow-hidden overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase text-slate-500">
            <tr>
              <th className="px-4 py-3 font-medium">Quote #</th>
              <th className="px-4 py-3 font-medium">Client</th>
              <th className="px-4 py-3 font-medium">Country</th>
              <th className="px-4 py-3 font-medium">Total</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Date</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {quotations.map((q) => (
              <tr key={q.id} className="hover:bg-slate-50">
                <td className="px-4 py-3">
                  <Link href={`/quotations/${q.id}`} className="font-medium text-brand-blue-600 hover:underline">
                    {q.quotation_number}
                  </Link>
                </td>
                <td className="px-4 py-3">
                  <p className="font-medium text-slate-900">{q.client_name}</p>
                  {q.company_name && <p className="text-xs text-slate-500">{q.company_name}</p>}
                </td>
                <td className="px-4 py-3 text-slate-600">{q.country ?? "—"}</td>
                <td className="px-4 py-3 font-medium text-slate-900">${q.total_amount.toLocaleString()}</td>
                <td className="px-4 py-3">
                  <QuotationStatusBadge status={q.status} />
                </td>
                <td className="px-4 py-3 text-slate-600">
                  {new Date(q.created_at).toLocaleDateString()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {quotations.length === 0 && (
          <div className="p-10 text-center text-sm text-slate-500">No quotations yet.</div>
        )}
      </div>
    </div>
  );
}
