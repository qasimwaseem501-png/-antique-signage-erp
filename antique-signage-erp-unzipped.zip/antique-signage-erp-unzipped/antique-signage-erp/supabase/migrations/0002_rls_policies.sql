-- =========================================================
-- Row Level Security (RLS)
-- Rules enforced:
--  - Owner: full access to everything
--  - Sales: can see/edit only leads assigned to them (+ leads they created)
--  - Sales: CANNOT delete leads, CANNOT see other employees' leads,
--           CANNOT export client list (enforced at app layer + no bulk select policy)
--  - Production / Designer / Accounts: read access scoped to what they need
--    (Phase 1 gives them read on leads/clients; Phase 2 tightens per workflow stage)
-- =========================================================

alter table public.profiles enable row level security;
alter table public.clients enable row level security;
alter table public.leads enable row level security;
alter table public.lead_timeline enable row level security;
alter table public.client_files enable row level security;

-- ---------------------------------------------------------
-- Helper: get current user's role without recursive RLS lookups
-- ---------------------------------------------------------
create or replace function public.current_role()
returns user_role
language sql
security definer
stable
set search_path = public
as $$
  select role from public.profiles where id = auth.uid();
$$;

create or replace function public.is_owner()
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select coalesce((select role from public.profiles where id = auth.uid()) = 'owner', false);
$$;

-- =========================================================
-- PROFILES
-- =========================================================

-- Everyone can read their own profile; Owner can read all
create policy profiles_select_own_or_owner
  on public.profiles for select
  using (id = auth.uid() or public.is_owner());

-- Only Owner can insert profiles directly (normal signups go through trigger)
create policy profiles_insert_owner_only
  on public.profiles for insert
  with check (public.is_owner());

-- Users can update limited fields on their own profile; Owner can update anyone
create policy profiles_update_own_or_owner
  on public.profiles for update
  using (id = auth.uid() or public.is_owner());

-- Only Owner can delete/deactivate employee profiles
create policy profiles_delete_owner_only
  on public.profiles for delete
  using (public.is_owner());

-- =========================================================
-- CLIENTS
-- Employees can VIEW client records tied to leads they own.
-- Full client list / export is Owner-only (app layer also blocks
-- bulk export UI for non-owners; this policy blocks it at the DB level too
-- by only exposing clients linked to the employee's own leads).
-- =========================================================

create policy clients_select_owner_all
  on public.clients for select
  using (
    public.is_owner()
    or exists (
      select 1 from public.leads l
      where l.client_id = clients.id
      and l.assigned_to = auth.uid()
    )
  );

create policy clients_insert_authenticated
  on public.clients for insert
  with check (auth.uid() is not null);

create policy clients_update_owner_or_assigned
  on public.clients for update
  using (
    public.is_owner()
    or exists (
      select 1 from public.leads l
      where l.client_id = clients.id
      and l.assigned_to = auth.uid()
    )
  );

-- Employees cannot delete clients — Owner only
create policy clients_delete_owner_only
  on public.clients for delete
  using (public.is_owner());

-- =========================================================
-- LEADS
-- Core rule: Sales sees only leads assigned to them.
-- Owner sees everything. Production/Designer/Accounts get
-- read-only visibility (needed for cross-functional workflow)
-- but cannot see leads not yet in their stage — refined in Phase 2
-- once production/quote stage tables exist. For Phase 1 they can
-- read leads in production-relevant statuses only.
-- =========================================================

create policy leads_select_scoped
  on public.leads for select
  using (
    public.is_owner()
    or assigned_to = auth.uid()
    or created_by = auth.uid()
    or (
      public.current_role() in ('production', 'designer', 'accounts')
      and status in ('confirmed', 'production', 'packing', 'shipping', 'delivered', 'completed')
    )
  );

create policy leads_insert_authenticated
  on public.leads for insert
  with check (auth.uid() is not null);

-- Sales can update only their own assigned leads; Owner can update all
create policy leads_update_owner_or_assigned
  on public.leads for update
  using (
    public.is_owner()
    or assigned_to = auth.uid()
  );

-- CRITICAL: Employees cannot delete leads. Owner only.
create policy leads_delete_owner_only
  on public.leads for delete
  using (public.is_owner());

-- =========================================================
-- LEAD TIMELINE
-- Visible to anyone who can see the parent lead.
-- Insert allowed for anyone who can update the parent lead
-- (manual notes); system-triggered inserts run as the trigger owner.
-- =========================================================

create policy timeline_select_via_lead
  on public.lead_timeline for select
  using (
    exists (
      select 1 from public.leads l
      where l.id = lead_timeline.lead_id
      and (
        public.is_owner()
        or l.assigned_to = auth.uid()
        or l.created_by = auth.uid()
        or public.current_role() in ('production', 'designer', 'accounts')
      )
    )
  );

create policy timeline_insert_via_lead
  on public.lead_timeline for insert
  with check (
    exists (
      select 1 from public.leads l
      where l.id = lead_timeline.lead_id
      and (public.is_owner() or l.assigned_to = auth.uid())
    )
  );

-- No update/delete on timeline entries — immutable audit trail.
-- (No policy = no access, since RLS defaults deny.)

-- =========================================================
-- CLIENT FILES
-- Download restricted: employees cannot bulk-download company files.
-- Phase 1 stores metadata; Storage bucket policies (separate, see
-- docs/SETUP_GUIDE.md) mirror this same assigned-lead restriction.
-- =========================================================

create policy files_select_scoped
  on public.client_files for select
  using (
    public.is_owner()
    or exists (
      select 1 from public.leads l
      where l.id = client_files.lead_id
      and l.assigned_to = auth.uid()
    )
  );

create policy files_insert_scoped
  on public.client_files for insert
  with check (
    public.is_owner()
    or exists (
      select 1 from public.leads l
      where l.id = client_files.lead_id
      and l.assigned_to = auth.uid()
    )
  );

-- Only Owner can delete company files
create policy files_delete_owner_only
  on public.client_files for delete
  using (public.is_owner());
