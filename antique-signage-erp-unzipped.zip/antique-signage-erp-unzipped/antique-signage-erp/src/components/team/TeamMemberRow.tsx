"use client";

import { useTransition } from "react";
import { updateEmployeeRole, toggleEmployeeActive } from "@/app/(app)/team/actions";
import type { Profile } from "@/types/database";

const ROLES = ["admin", "sales", "designer", "production", "packing", "accounts"];

export function TeamMemberRow({ member, isSelf }: { member: Profile; isSelf: boolean }) {
  const [isPending, startTransition] = useTransition();

  return (
    <tr className="hover:bg-slate-50">
      <td className="px-4 py-3">
        <p className="font-medium text-slate-900">{member.full_name}</p>
        <p className="text-xs text-slate-500">{member.email}</p>
      </td>
      <td className="px-4 py-3">
        <select
          className="input max-w-[160px]"
          value={member.role === "owner" ? "admin" : member.role}
          disabled={isPending || isSelf}
          onChange={(e) => startTransition(() => updateEmployeeRole(member.id, e.target.value))}
        >
          {ROLES.map((r) => (
            <option key={r} value={r}>{r}</option>
          ))}
        </select>
        {isSelf && <p className="mt-1 text-xs text-slate-400">Can&apos;t change your own role</p>}
      </td>
      <td className="px-4 py-3 text-slate-600">{member.phone ?? "—"}</td>
      <td className="px-4 py-3">
        <label className="inline-flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={member.is_active}
            disabled={isPending || isSelf}
            onChange={(e) => startTransition(() => toggleEmployeeActive(member.id, e.target.checked))}
          />
          {member.is_active ? "Active" : "Inactive"}
        </label>
      </td>
    </tr>
  );
}
