"use client";

import { useRef, useState, useTransition } from "react";
import Link from "next/link";
import Papa from "papaparse";
import { ArrowLeft, Upload, Download } from "lucide-react";
import { bulkImportLeads, type ImportedLeadRow } from "../actions";
import type { Profile } from "@/types/database";

const SAMPLE_CSV = `client_name,company_name,country,city,phone,whatsapp,email,source,notes
John Miller,Miller Auto Detailing,USA,Austin,+15125550142,+15125550142,john@example.com,whatsapp,Interested in channel letters
Sarah Thompson,Thompson Nail Bar,UK,Manchester,+441615550199,+441615550199,sarah@example.com,facebook_ads,Wants a neon sign quote`;

export function LeadImportForm({ team }: { team: Profile[] }) {
  const [rows, setRows] = useState<ImportedLeadRow[]>([]);
  const [assignedTo, setAssignedTo] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();
  const fileRef = useRef<HTMLInputElement>(null);

  function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setError(null);
    setResult(null);

    Papa.parse<ImportedLeadRow>(file, {
      header: true,
      skipEmptyLines: true,
      transformHeader: (h) => h.trim().toLowerCase().replace(/\s+/g, "_"),
      complete: (results) => {
        if (results.errors.length > 0) {
          setError(results.errors[0].message);
          return;
        }
        setRows(results.data);
      }
    });
  }

  function downloadSample() {
    const blob = new Blob([SAMPLE_CSV], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "lead_import_sample.csv";
    a.click();
    URL.revokeObjectURL(url);
  }

  function handleImport() {
    setError(null);
    startTransition(async () => {
      try {
        const { imported } = await bulkImportLeads(rows, assignedTo || null);
        setResult(`Successfully imported ${imported} lead${imported === 1 ? "" : "s"}.`);
        setRows([]);
        if (fileRef.current) fileRef.current.value = "";
      } catch (err) {
        setError(err instanceof Error ? err.message : "Import failed");
      }
    });
  }

  return (
    <div>
      <Link href="/leads" className="mb-4 inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-900">
        <ArrowLeft className="h-4 w-4" />
        Back to Leads
      </Link>

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Import Leads</h1>
        <p className="text-sm text-slate-500">Bulk-add leads from WhatsApp exports or any CSV file</p>
      </div>

      <div className="card mb-6 space-y-4 p-6">
        <div className="flex flex-wrap items-center gap-3">
          <label className="btn-secondary cursor-pointer">
            <Upload className="h-4 w-4" />
            Choose CSV File
            <input ref={fileRef} type="file" accept=".csv" className="hidden" onChange={handleFile} />
          </label>
          <button onClick={downloadSample} className="flex items-center gap-1.5 text-sm text-brand-blue-600 hover:underline">
            <Download className="h-3.5 w-3.5" />
            Download sample format
          </button>
        </div>
        <p className="text-xs text-slate-500">
          Required column: <code>client_name</code>. Optional: company_name, country, city, phone,
          whatsapp, email, source (whatsapp/facebook_ads/google_ads/instagram/website/referral),
          notes. Unknown sources default to WhatsApp.
        </p>

        {rows.length > 0 && (
          <>
            <div>
              <label className="label">Assign all imported leads to</label>
              <select className="input max-w-xs" value={assignedTo} onChange={(e) => setAssignedTo(e.target.value)}>
                <option value="">Myself</option>
                {team.map((m) => (
                  <option key={m.id} value={m.id}>{m.full_name}</option>
                ))}
              </select>
            </div>

            <div className="overflow-x-auto rounded-lg border border-slate-200">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500">
                  <tr>
                    <th className="px-3 py-2">Client</th>
                    <th className="px-3 py-2">Company</th>
                    <th className="px-3 py-2">Country</th>
                    <th className="px-3 py-2">Phone</th>
                    <th className="px-3 py-2">Source</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {rows.slice(0, 20).map((r, i) => (
                    <tr key={i}>
                      <td className="px-3 py-2">{r.client_name}</td>
                      <td className="px-3 py-2">{r.company_name ?? "—"}</td>
                      <td className="px-3 py-2">{r.country ?? "—"}</td>
                      <td className="px-3 py-2">{r.phone ?? "—"}</td>
                      <td className="px-3 py-2">{r.source ?? "whatsapp"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {rows.length > 20 && (
                <p className="p-2 text-center text-xs text-slate-400">...and {rows.length - 20} more rows</p>
              )}
            </div>

            <button onClick={handleImport} disabled={isPending} className="btn-primary">
              {isPending ? "Importing..." : `Import ${rows.length} Lead${rows.length === 1 ? "" : "s"}`}
            </button>
          </>
        )}

        {error && <p className="text-sm text-red-600">{error}</p>}
        {result && <p className="text-sm text-emerald-600">{result}</p>}
      </div>
    </div>
  );
}
