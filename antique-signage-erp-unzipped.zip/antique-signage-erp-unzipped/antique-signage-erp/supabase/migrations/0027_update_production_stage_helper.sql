-- =========================================================
-- Phase 5 — Migration 0027
-- Update is_production_stage() so Production role RLS correctly
-- includes the new Acrylic and Assembly stages added in 0026.
-- Kept as a separate migration from the ALTER TYPE statements,
-- since newly added enum values are safest to reference only
-- after their own transaction has committed.
-- =========================================================

create or replace function public.is_production_stage(s project_stage)
returns boolean
language sql
immutable
as $$
  select s in (
    'material_purchase', 'cnc_laser_cutting', 'letter_bending',
    'welding_fabrication', 'powder_coating', 'led_wiring', 'testing',
    'acrylic_fabrication', 'assembly'
  );
$$;

create or replace function public.is_packing_stage(s project_stage)
returns boolean
language sql
immutable
as $$
  select s in ('packing', 'ready_to_ship', 'shipped');
$$;
