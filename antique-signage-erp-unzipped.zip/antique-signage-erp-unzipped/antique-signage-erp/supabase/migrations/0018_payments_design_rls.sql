-- =========================================================
-- Phase 3 — Migration 0018
-- RLS: Payments, Design Approvals + storage for payment proofs
-- =========================================================

alter table public.payments enable row level security;
alter table public.design_approvals enable row level security;

create policy payments_select_scoped
  on public.payments for select
  using (
    public.is_admin()
    or public.current_role() = 'accounts'
    or exists (
      select 1 from public.projects p
      join public.leads l on l.id = p.lead_id
      where p.id = payments.project_id and l.assigned_to = auth.uid()
    )
  );

create policy payments_insert_admin_or_accounts
  on public.payments for insert
  with check (public.is_admin() or public.current_role() = 'accounts');

create policy payments_update_admin_or_accounts
  on public.payments for update
  using (public.is_admin() or public.current_role() = 'accounts');

create policy payments_delete_admin_only
  on public.payments for delete
  using (public.is_admin());

create policy design_approvals_select_scoped
  on public.design_approvals for select
  using (
    public.is_admin()
    or public.current_role() in ('accounts', 'designer')
    or exists (
      select 1 from public.projects p
      join public.leads l on l.id = p.lead_id
      where p.id = design_approvals.project_id and l.assigned_to = auth.uid()
    )
  );

create policy design_approvals_write_admin_or_designer
  on public.design_approvals for all
  using (public.is_admin() or public.current_role() = 'designer')
  with check (public.is_admin() or public.current_role() = 'designer');

create policy storage_select_payment_proofs
  on storage.objects for select
  using (
    bucket_id = 'client-files'
    and (storage.foldername(name))[1] = 'payments'
    and (public.is_admin() or public.current_role() = 'accounts')
  );

create policy storage_insert_payment_proofs
  on storage.objects for insert
  with check (
    bucket_id = 'client-files'
    and (storage.foldername(name))[1] = 'payments'
    and (public.is_admin() or public.current_role() = 'accounts')
  );

create policy storage_delete_payment_proofs
  on storage.objects for delete
  using (
    bucket_id = 'client-files'
    and (storage.foldername(name))[1] = 'payments'
    and public.is_admin()
  );
