import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile, isAdmin } from "@/lib/auth";
import { TeamMemberRow } from "@/components/team/TeamMemberRow";
import type { Profile } from "@/types/database";

export default async function TeamPage() {
  const profile = await getCurrentProfile();
  if (!isAdmin(profile)) redirect("/dashboard");

  const supabase = createClient();
  const { data } = await supabase.from("profiles").select("*").order("created_at");
  const members = (data ?? []) as Profile[];

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Team</h1>
        <p className="text-sm text-slate-500">Manage employee roles and access</p>
      </div>

      <div className="mb-4 rounded-lg border border-dashed border-slate-300 bg-white p-4 text-sm text-slate-600">
        To add a new employee: create their login in Supabase → Authentication → Users, then set
        their role here. See <code className="text-xs">docs/SETUP_GUIDE.md</code> for details.
      </div>

      <div className="card overflow-hidden overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase text-slate-500">
            <tr>
              <th className="px-4 py-3 font-medium">Employee</th>
              <th className="px-4 py-3 font-medium">Role</th>
              <th className="px-4 py-3 font-medium">Phone</th>
              <th className="px-4 py-3 font-medium">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {members.map((m) => (
              <TeamMemberRow key={m.id} member={m} isSelf={m.id === profile.id} />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
