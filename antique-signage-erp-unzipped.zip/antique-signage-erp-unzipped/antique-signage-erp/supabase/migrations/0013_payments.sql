-- =========================================================
-- Phase 3 — Migration 0013
-- Payments: advance/balance tracking per project
-- =========================================================

create type payment_type as enum ('advance', 'balance', 'full', 'refund');
create type payment_method as enum ('cash', 'bank_transfer', 'card', 'wire_transfer', 'other');

create table public.payments (
  id uuid primary key default uuid_generate_v4(),
  project_id uuid not null references public.projects(id) on delete cascade,

  payment_type payment_type not null,
  amount numeric(12,2) not null,
  payment_method payment_method not null default 'bank_transfer',

  proof_storage_path text,
  notes text,

  received_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create index idx_payments_project on public.payments (project_id);

-- Convenience view: total received / balance pending per project.
-- security_invoker so it respects the querying user's RLS on the
-- underlying payments/projects tables.
create view public.project_payment_summary
with (security_invoker = true)
as
select
  p.id as project_id,
  p.project_code,
  p.sale_amount,
  coalesce(sum(pay.amount) filter (where pay.payment_type != 'refund'), 0)
    - coalesce(sum(pay.amount) filter (where pay.payment_type = 'refund'), 0) as total_received,
  p.sale_amount - (
    coalesce(sum(pay.amount) filter (where pay.payment_type != 'refund'), 0)
    - coalesce(sum(pay.amount) filter (where pay.payment_type = 'refund'), 0)
  ) as balance_pending
from public.projects p
left join public.payments pay on pay.project_id = p.id
group by p.id, p.project_code, p.sale_amount;

-- Log payment activity to the lead's timeline (if linked)
create or replace function public.log_payment_activity()
returns trigger
language plpgsql
as $$
declare
  v_lead_id uuid;
begin
  select lead_id into v_lead_id from public.projects where id = new.project_id;

  if v_lead_id is not null then
    insert into public.lead_timeline (lead_id, event_type, title, description, created_by)
    values (
      v_lead_id, 'payment_event',
      initcap(new.payment_type::text) || ' payment recorded',
      '$' || new.amount::text || ' via ' || new.payment_method::text,
      new.received_by
    );
  end if;

  return new;
end;
$$;

create trigger trg_payments_log_activity
  after insert on public.payments
  for each row execute function public.log_payment_activity();
