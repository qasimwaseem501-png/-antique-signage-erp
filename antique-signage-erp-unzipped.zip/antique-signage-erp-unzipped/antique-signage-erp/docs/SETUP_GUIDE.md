# Antique Signage & Advertising — ERP/CRM
## Phase 1 Setup Guide

This is a production Next.js + Supabase application. Phase 1 includes: authentication,
role-based access control, Row Level Security, the Dashboard, and the full Leads CRM
with timeline history.

---

## 1. Create Your Supabase Project

1. Go to https://supabase.com and sign in (create a free account if needed).
2. Click **New Project**.
3. Fill in:
   - **Name**: `antique-signage-erp`
   - **Database Password**: generate a strong one and save it somewhere safe (you won't need it day-to-day, but keep it).
   - **Region**: pick the region closest to your main users (e.g. a US region since most clients are US-based).
4. Click **Create new project** and wait ~2 minutes for provisioning.

### Get your API keys
1. In your project, go to **Project Settings** (gear icon) → **API**.
2. Copy:
   - **Project URL** → this is `NEXT_PUBLIC_SUPABASE_URL`
   - **anon public** key → this is `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - **service_role** key → this is `SUPABASE_SERVICE_ROLE_KEY` (keep this secret — never commit it or expose it to the browser)

---

## 2. Run the Database Migrations

1. In Supabase, go to **SQL Editor** (left sidebar).
2. Click **New query**.
3. Open `supabase/migrations/0001_core_schema.sql` from this project, copy the entire contents, paste into the SQL editor, and click **Run**.
4. Repeat the same process for:
   - `supabase/migrations/0002_rls_policies.sql`
   - `supabase/migrations/0003_storage_buckets.sql`
5. Run them **in order** (0001 → 0002 → 0003) — later files depend on tables/functions created earlier.

You should see "Success. No rows returned" after each one. If you get an error, check that
you ran them in order and didn't skip one.

### Verify it worked
Go to **Table Editor** in Supabase — you should see: `profiles`, `clients`, `leads`,
`lead_timeline`, `client_files`.

---

## 3. Create Your Owner Account

1. In Supabase, go to **Authentication** → **Users** → **Add user** → **Create new user**.
2. Enter your email and a password. Check **Auto Confirm User**.
3. Click **Create user**. A matching row is auto-created in `profiles` with role `sales` by default.
4. Promote yourself to Owner: go to **Table Editor** → `profiles` table, find your row, and change the `role` column from `sales` to `owner`.

You (and only the Owner) can now create other employee accounts the same way — create the
auth user in Supabase, then set their role in the `profiles` table (`sales`, `production`,
`designer`, or `accounts`). A future Phase will add an in-app "Create Employee" screen for
the Owner so you don't need to touch Supabase directly for this.

---

## 4. Install and Run Locally

Requires **Node.js 18.17+** (check with `node -v`).

```bash
# 1. Unzip the project and enter the folder
cd antique-signage-erp

# 2. Install dependencies
npm install

# 3. Set up environment variables
cp .env.example .env.local
# then open .env.local and paste in your Supabase URL + keys from Step 1

# 4. Run the dev server
npm run dev
```

Open http://localhost:3000 — you'll be redirected to `/login`. Sign in with the Owner
account you created in Step 3.

---

## 5. Deploy to Vercel

1. Push this project to a GitHub repository (private is fine).
2. Go to https://vercel.com and sign in with GitHub.
3. Click **Add New Project**, select your repo.
4. Under **Environment Variables**, add the same three variables from your `.env.local`:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
5. Click **Deploy**.
6. Once deployed, go back to Supabase → **Authentication** → **URL Configuration** and add
   your Vercel domain (e.g. `https://antique-signage-erp.vercel.app`) to **Site URL** and
   **Redirect URLs** — this is required for auth to work in production.

---

## What's Included in Phase 1

- **Auth**: email/password login via Supabase Auth, session handled via middleware
- **Roles**: Owner, Sales, Production, Designer, Accounts (enum-enforced in the database)
- **Row Level Security**: enforced at the database level, not just in the UI —
  - Sales employees can only see/edit leads assigned to them
  - Sales cannot delete leads (Owner only)
  - Only Owner can see the full client list / all leads
  - File downloads are scoped the same way
- **Dashboard**: live counts for total leads, today's leads, pending follow-ups, quotes sent,
  production/ready/shipped orders, and a pipeline breakdown — scoped per role automatically
- **Leads CRM**: full lead fields per your spec (client info, source, status, assigned
  employee, follow-up/close dates, notes), searchable/filterable list, and a detail page
  with a full timeline (auto-logged status changes, reassignments, and manual notes)
- **Auto lead codes**: `LEAD-2026-0001` style, generated automatically
- **WhatsApp click-to-chat**: opens a chat with the client's WhatsApp number directly from
  the lead page (architecture is ready for full WhatsApp Business API integration in Phase 4)

## What's Coming in Phase 2

Quotation system (auto quote numbers, PDF generation, owner approval), Production Workflow
(stage-by-stage tracking), Shipping, and Payments/Invoicing.

---

## Project Structure

```
antique-signage-erp/
├── supabase/migrations/       # SQL schema, RLS policies, storage — run in Supabase SQL Editor
├── src/
│   ├── app/
│   │   ├── login/             # Login page
│   │   ├── auth/callback/     # Supabase auth callback route
│   │   └── (app)/             # Authenticated app shell (sidebar layout)
│   │       ├── dashboard/
│   │       └── leads/         # List, new lead form, detail + timeline
│   ├── components/
│   │   ├── layout/            # Sidebar
│   │   ├── dashboard/         # StatCard
│   │   └── leads/             # StatusBadge, LeadTimeline
│   ├── lib/
│   │   ├── supabase/          # Browser + server Supabase clients
│   │   └── auth.ts            # getCurrentProfile() helper
│   ├── types/database.ts      # TypeScript types mirroring the SQL schema
│   └── middleware.ts          # Session refresh + route protection
├── .env.example
└── package.json
```

---

# Phase 2 Addendum — Quotations, Production, Commission, Expenses, Shipping

Phase 2 is additive: it does **not** remove or break anything from Phase 1. Your existing
Owner account, leads, and data all keep working. Here's what changed and how to upgrade.

## 1. Run the New Migrations

In the Supabase SQL Editor, run these **in order**, after your existing 0001–0003:

```
0004_extend_roles_and_enums.sql
0005_admin_migration_and_activity_log.sql
0006_quotation_system.sql
0007_projects_production_commission.sql
0008_expenses_and_shipping.sql
0009_phase2_rls_policies.sql
0010_fix_is_owner_for_admin_role.sql
0011_project_storage_policies.sql
```

**What 0004/0005 do to your existing data:** they rename the `owner` role to `admin`
(the Phase 2 standard name) for any existing accounts, and add `packing` as a new role.
Nothing about how you log in changes — same email/password, same account.

## 2. Install New Dependencies

Phase 2 adds PDF export for quotations:

```bash
npm install
```

(`jspdf` and `jspdf-autotable` are already added to `package.json`.)

## 3. (Optional) Load Sample Demo Data

If you want to see the app populated with realistic sample leads, quotations, a project,
expenses, and a shipment: open `supabase/seed.sql`, copy its contents, paste into the
Supabase SQL Editor, and run it. It automatically attaches everything to your existing
Admin account — no setup needed. **Only run this on a demo/staging database**, not on
real production data, since it creates fictional client records.

## 4. New Roles

| Role | Sees |
|---|---|
| **Admin** (formerly Owner) | Everything |
| **Sales** | Own assigned leads, own quotations, own commissions |
| **Designer** | Projects in Design Pending / Design Approved |
| **Production** | Projects in Material Purchase → Testing stages |
| **Packing** | Projects in Packing / Ready to Ship + all Shipments |
| **Accounts** | Quotations, Expenses, Commissions (read/manage), profiles |

Manage roles from the new **Team** page (Admin only).

## 5. New Modules & Workflow

1. **Leads** — now uses the Phase 2 status set (New → Contacted → Quotation Sent →
   Negotiation → Closed Won / Closed Lost / Repeat Client) and sources (WhatsApp, Facebook
   Ads, Google Ads, Instagram, Website, Referral). Old Phase 1 leads keep their original
   status/source values and still display correctly.
2. **Quotations** — create from scratch or link to a lead. Add multiple line items (sign
   type, size, material, lighting, quantity, unit price) — totals calculate automatically.
   Draft → Sent → Approved/Rejected. Download a branded PDF at any stage.
3. **Projects** — click "Convert to Project" on an approved quotation. This automatically
   marks the linked lead Closed Won and creates a matching commission.
4. **Production** — a per-role kanban board. Move a project through its 13 stages; every
   change is logged to an immutable history table.
5. **Commissions** — auto-created when a lead becomes Closed Won, using the tier table
   (up to $1,000 → $30 · $1,001–3,000 → $50 · $3,001–5,000 → $100 · $5,001–7,000 → $150 ·
   $7,000+ → $200). Admin/Accounts can override the amount or approve/mark paid.
6. **Expenses** — log costs per project (material, labor, powder coating, LEDs, packing,
   shipping, ads, other). The Expenses page shows sale amount, total cost, gross profit,
   and profit % for every project automatically.
7. **Shipping** — log courier, box dimensions (volumetric weight auto-calculates), tracking
   number, and duty status. Marking a shipment "Delivered" automatically advances the
   linked project to the Delivered stage.

## 6. Security Notes

- **Phone number privacy**: on any lead's detail page, Admin sees a Visible/Hidden toggle
  next to Contact Details. When hidden, the assigned sales rep's browser never receives
  the phone/WhatsApp number — it's stripped server-side before rendering, not just
  hidden with CSS.
- **No bulk export**: RLS restricts sales reps to only the rows they're allowed to see at
  the database level, so there's no query that can pull the full client list as a non-admin,
  regardless of what the UI does.
- **Activity log**: sensitive actions are logged to `activity_log` (Admin-only visibility).
- All new tables (quotations, projects, commissions, expenses, shipments) have Row Level
  Security enabled and enforced — see `supabase/migrations/0009_phase2_rls_policies.sql`
  for the full policy set.

## Updated Sidebar

Dashboard · Leads · Quotations · Projects · Production · Shipping · Expenses ·
Commissions · Team · Settings — each item is automatically hidden for roles that
shouldn't see it (e.g. Designers don't see Team or Settings).

---

# Phase 3 Addendum — Payments, Design Approval, Multi-Box Shipping, Inventory

Phase 3 is additive on top of Phase 1 + Phase 2. Nothing existing breaks.

## 1. New Files Added

**Migrations:**
- `0012_production_and_expense_updates.sql` — adds "Completed" stage, per-stage due dates, Acrylic/ACM/Stainless Steel expense categories
- `0013_payments.sql` — payments table + `project_payment_summary` view
- `0014_design_approvals.sql` — design approval workflow + auto stage advancement
- `0015_shipping_rewrite.sql` — country rate table, multi-box shipments, auto weight/charge calculation
- `0016_commission_eligibility.sql` — new-client vs repeat-client commission rules, auto repeat-client detection
- `0017_inventory.sql` — inventory items, stock transactions, low-stock view
- `0018_payments_design_rls.sql` — RLS for payments/design approvals + storage policies
- `0019_lead_next_action.sql` — adds `next_action` field to leads

**App pages:**
- `src/app/(app)/payments/` — payments overview page + actions
- `src/app/(app)/inventory/` — inventory list page + actions
- `src/app/(app)/design/actions.ts` — design approval actions
- `src/app/(app)/shipping/new/ShipmentForm.tsx` — rewritten multi-box shipment form

**Components:**
- `src/components/payments/PaymentForm.tsx`, `PaymentPanel.tsx`
- `src/components/projects/DesignApprovalPanel.tsx`
- `src/components/inventory/InventoryForms.tsx`
- `src/components/shipping/ShippingRatesEditor.tsx`
- `src/components/leads/RepeatClientHistory.tsx`, `FollowUpEditor.tsx`

**Modified (not rebuilt):** `types/database.ts`, `Sidebar.tsx`, dashboard page, commission row/page,
lead detail page, project detail page, shipping list page, settings page.

## 2. Migration Order

Run in the Supabase SQL Editor, **in exact numeric order**, after your existing 0001–0011:

```
0012_production_and_expense_updates.sql
0013_payments.sql
0014_design_approvals.sql
0015_shipping_rewrite.sql
0016_commission_eligibility.sql
0017_inventory.sql
0018_payments_design_rls.sql
0019_lead_next_action.sql
```

## 3. Supabase Setup Instructions

No new project setup needed — this uses your existing Supabase project. Just:
1. Run migrations 0012–0019 in order (SQL Editor → paste each file → Run).
2. That's it. `0015` auto-seeds the country shipping rate table (UK, USA, Canada, Europe,
   Australia, Dubai) so shipping works immediately — edit rates anytime from **Settings**.

## 4. Environment Variables

**No new environment variables required.** Phase 3 uses your existing
`NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, and `SUPABASE_SERVICE_ROLE_KEY`.
Payment proofs and design files reuse the existing `client-files` storage bucket.

## 5. New Workflow Details

- **Full pipeline**: Lead → Quotation → Approved → Convert to Project (auto-marks lead
  Closed Won + creates commission) → Design Approval → Payments (advance) → Production
  stages → Design/QC → Packing → Shipping (auto weight/cost calc) → Delivered → Completed
  → Balance Payment → Commission payout.
- **Commission eligibility**: a lead is automatically flagged as a repeat client if any
  prior *Closed Won* lead shares the same email, phone, or WhatsApp number. New-client
  commissions go straight to "Pending" for normal approval; repeat-client commissions are
  created with eligibility "Needs Review" and require explicit Admin/Accounts sign-off —
  they're never silently paid out. Admin can override any amount or reject a commission.
- **Shipping**: add multiple boxes per shipment; each box's volumetric weight
  (L×W×H÷5000), chargeable weight (max of actual/volumetric), oversize flag (>100cm any
  side), and overweight flag (>25kg) calculate automatically. Total cost = Σ(chargeable
  weight × country rate) + oversize/overweight surcharges. Country rates are editable in
  Settings.
- **Repeat client history**: opening a lead flagged as a repeat client shows all its
  previous Closed Won orders with links.

## 6. Testing Checklist

**Leads**
- [ ] Create a lead with each source (WhatsApp, Facebook Ads, Google Ads, Instagram, Website, Referral)
- [ ] As Admin, toggle a lead's phone visibility off — confirm the assigned Sales rep no longer sees the number
- [ ] Set a follow-up date + next action on a lead, confirm it saves
- [ ] Create a second lead with the same email as a previously Closed Won lead — confirm it's auto-marked "No (Repeat)" and shows Previous Orders

**Quotations → Projects**
- [ ] Create a quotation with 2+ line items, confirm totals calculate correctly
- [ ] Download the PDF, confirm branding/line items/total are correct
- [ ] Approve the quotation, convert to project — confirm the linked lead becomes Closed Won and a commission row appears

**Commissions**
- [ ] Confirm a new-client conversion creates a commission with eligibility "New Client"
- [ ] Confirm a repeat-client conversion creates one with eligibility "Needs Review"
- [ ] As Admin, override a commission amount and approve/reject/mark paid

**Design Approval**
- [ ] As Designer, submit a design status of "Changes Required" with notes, then "Approved" — confirm the project's stage auto-advances from Design Pending to Design Approved

**Payments**
- [ ] Record an advance payment with a proof file upload
- [ ] Confirm Payments page and project detail page both show correct Balance Pending
- [ ] As Sales (non-Accounts), confirm you can view but not add payments

**Production**
- [ ] Move a project through several stages, confirm each shows in Project Stage History
- [ ] As Designer/Production/Packing, confirm the Production board only shows your relevant stages

**Shipping**
- [ ] Create a shipment with 2 boxes, one oversized (>100cm) and one overweight (>25kg) — confirm both alerts appear
- [ ] Confirm total shipping cost matches manual calculation: Σ(chargeable weight × rate) + surcharges
- [ ] Mark a shipment "Delivered" — confirm the linked project's stage updates to Delivered

**Expenses & Profit**
- [ ] Log expenses across the new categories (Acrylic, ACM, Stainless Steel, etc.)
- [ ] Confirm the Expenses page profit % matches (Sale − Cost) / Sale × 100

**Inventory**
- [ ] Add an inventory item with a low stock threshold
- [ ] Record a Stock Out transaction that brings it below threshold — confirm the low stock alert appears

**Roles/RLS (most important)**
- [ ] Log in as Sales — confirm you cannot see another Sales rep's leads or commissions
- [ ] Log in as Designer — confirm you only see Production board items in Design stages
- [ ] Log in as Packing — confirm you only see Packing/Ready to Ship + Shipping
- [ ] Log in as Accounts — confirm you see Quotations/Expenses/Commissions/Payments but not the full Leads list
- [ ] Confirm no non-Admin role has a way to bulk-export the client list

---

# Phase 4 Addendum — Client Portal, Tasks, Suppliers, Dark Mode, Reports

## What Was Added

1. **Client Portal** (`/portal`) — clients get their own login (role `client`), completely
   separate from the staff sidebar. They can view their quotations (read-only + PDF
   download), see live project status as a progress tracker, approve or request changes
   on designs, view production photos/videos, see their payment balance, track shipping,
   and message the team directly. Staff reply to client messages from the project detail
   page's new "Client Messages" panel.
2. **Task Management** (`/tasks`) — create tasks with priority/due date/assignee, optionally
   linked to a project, with a comment thread per task.
3. **Supplier & Purchase Orders** (`/inventory/suppliers`, `/inventory/purchase-orders`) —
   maintain a supplier list and raise POs with line items; marking a PO "Received"
   automatically stocks the linked inventory items in.
4. **Dark/Light Mode** — toggle in the sidebar (bottom, above Sign Out), persists via
   localStorage, respects system preference on first visit.
5. **Reports** (`/reports`, Admin/Accounts only) — country-wise sales, salesperson-wise
   sales, and Ads Spend vs Sales, all as charts (via `recharts`).
6. **Settings → Integrations** — placeholder fields for WhatsApp Business API, Meta Lead
   Ads, Google Ads, Stripe, PayPal, DHL, and FedEx. These save to the database but are
   **not wired to any live API yet** — that's real integration work for a future phase,
   not something a settings page alone can deliver.
7. **Quotation discount & tax** — quotations now support a discount (% or fixed) and a
   tax %, with totals recalculating automatically.
8. **Lead status refinement** — added a dedicated "Follow Up" status alongside New,
   Contacted, Quotation Sent, Won (was "Closed Won"), Lost (was "Closed Lost").

## New Files

**Migrations:** `0020_quotation_discount_tax.sql`, `0021_client_portal.sql`,
`0022_tasks.sql`, `0023_suppliers_purchase_orders.sql`, `0024_integrations_settings.sql`,
`0025_ad_spend.sql`

**App routes:** `src/app/portal/**` (client portal), `src/app/(app)/tasks/**`,
`src/app/(app)/reports/**`, `src/app/(app)/inventory/suppliers/`,
`src/app/(app)/inventory/purchase-orders/**`

**Components:** `components/portal/*`, `components/tasks/*`, `components/reports/*`,
`components/settings/IntegrationRow.tsx`, `components/layout/ThemeToggle.tsx`,
`components/projects/StaffMessagePanel.tsx`

## Migration Order

Run after your existing 0001–0019, in exact order:
```
0020_quotation_discount_tax.sql
0021_client_portal.sql
0022_tasks.sql
0023_suppliers_purchase_orders.sql
0024_integrations_settings.sql
0025_ad_spend.sql
```

## Environment Variables

**No new environment variables.** Same 3 Supabase vars as before. The Integrations
settings page stores keys in the database for now (not `.env`), since they're meant to be
admin-editable at runtime once the actual API wiring is built.

## Test Login Users (one per role)

Supabase doesn't allow creating auth users via SQL — create each one in
**Supabase Dashboard → Authentication → Users → Add User** (check "Auto Confirm User"),
then set their role in the `profiles` table (Table Editor, or via the app's **Team** page
once you have one Admin). Suggested test accounts:

| Email | Password | Role |
|---|---|---|
| admin@antiquesignage.test | Test1234! | admin |
| sales@antiquesignage.test | Test1234! | sales |
| designer@antiquesignage.test | Test1234! | designer |
| production@antiquesignage.test | Test1234! | production |
| packing@antiquesignage.test | Test1234! | packing |
| accounts@antiquesignage.test | Test1234! | accounts |
| client@antiquesignage.test | Test1234! | client |

**For the client test account specifically**, one extra step is needed after creating the
auth user: link it to a `clients` row so RLS knows which projects/quotations belong to
them. In the SQL Editor:
```sql
-- 1. Create a clients row for your test client (or use one created by seed.sql)
insert into public.clients (client_name, email) values ('Test Client', 'client@antiquesignage.test')
returning id; -- copy this id

-- 2. Link the profile you just created to that client
update public.profiles
set role = 'client', client_id = 'PASTE-THE-ID-HERE'
where email = 'client@antiquesignage.test';
```
The portal matches projects/quotations to a client by `client_name` matching exactly, so
use the same name here as on any quotation/lead you want that test client to see.

## How to Run Locally (recap)

```bash
npm install
cp .env.example .env.local   # fill in Supabase URL + keys
npm run dev
```
Visit `http://localhost:3000` → redirects to `/login`. Staff roles land on `/dashboard`;
the `client` role is automatically redirected to `/portal`.

---

# Phase 5 Addendum — Client Portal Removed, Internal ERP Focus

Per updated direction, the client portal has been **removed**. This phase focuses purely
on Admin/Owner, Sales, Designer, Production, Packing, and Accounts workflows.

## What Changed

- **Client portal removed**: `/portal` and all its pages/components are deleted. If a
  `client`-role account ever logs in, they see a simple "contact your account manager"
  message instead of any business data — no client-facing pages exist anymore.
- **Simplified production workflow**: the stage picker and Production board now show the
  exact 10-stage flow you specified: **Design → Approval → CNC/Laser → Acrylic → LED →
  Powder Coating → Assembly → QC → Packing → Shipping**. Older stage names (Material
  Purchase, Letter Bending, Welding/Fabrication, etc.) are kept in the database as legacy
  values so no historical project data breaks, but new projects only use the 10 clean
  stages.
- **Per-project task assignment**: every project's detail page now has a "Task Assignment"
  panel — add a task, assign it to a team member, set a due date, and update its status,
  all without leaving the project.
- **Lead CSV import**: `/leads/import` — upload a CSV (WhatsApp export, spreadsheet, etc.),
  preview the rows, assign them all to a salesperson, and bulk-create leads in one click.
  A sample CSV template is downloadable from the same page.
- **Follow-up Reminders**: `/leads/follow-ups` — a dedicated page (linked from Leads)
  showing overdue and due-today follow-ups with one-tap Call/WhatsApp buttons.
- **Reports expanded**: monthly sales vs ad spend, pending payments (with total), 
  production status breakdown, and employee performance (leads won, commission paid,
  tasks completed) — in addition to the existing country-wise and salesperson-wise charts.

## New Migrations

Run after your existing 0001–0025, in order:
```
0026_simplified_production_stages.sql
0027_update_production_stage_helper.sql
```

**Note on migration 0021 (`client_portal.sql`)**: if you haven't run it yet, you can skip
it entirely — it's no longer needed. If you already ran it, it's harmless to leave in
place (the `client_messages` table and client RLS policies just sit unused); no down-migration
is included since dropping them isn't necessary for the app to work correctly.

## New Dependency

`papaparse` (+ `@types/papaparse`) for CSV parsing — already added to `package.json`,
picked up by your next `npm install`.

## No New Environment Variables

Same 3 Supabase vars as always.
