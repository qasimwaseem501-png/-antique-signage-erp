-- =========================================================
-- Phase 3 — Migration 0016
-- Commission eligibility: repeat clients require admin review
-- =========================================================

create type commission_eligibility as enum ('new_client', 'repeat_client', 'admin_review');

alter table public.commissions
  add column if not exists eligibility commission_eligibility not null default 'new_client';

alter type commission_status add value if not exists 'rejected';

create or replace function public.handle_lead_closed_won()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  latest_quote record;
  tier_amount numeric;
  eligibility_value commission_eligibility;
begin
  if new.status = 'closed_won' and old.status is distinct from 'closed_won' and new.assigned_to is not null then

    select * into latest_quote
    from public.quotations
    where lead_id = new.id and status = 'approved'
    order by approved_at desc nulls last, created_at desc
    limit 1;

    if latest_quote is not null then
      tier_amount := public.calc_commission_tier(latest_quote.total_amount);

      eligibility_value := case
        when new.is_new_client then 'new_client'
        else 'admin_review'
      end;

      insert into public.commissions (lead_id, employee_id, sale_amount, calculated_amount, status, eligibility)
      values (
        new.id, new.assigned_to, latest_quote.total_amount, tier_amount,
        'pending', eligibility_value
      );
    end if;

  end if;

  return new;
end;
$$;

-- ---------------------------------------------------------
-- Auto-detect repeat clients at lead creation time: if a previous
-- Closed Won lead exists with the same email or phone, mark this
-- new lead as NOT a new client (repeat).
-- ---------------------------------------------------------
create or replace function public.detect_repeat_client()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  prior_count int;
begin
  select count(*) into prior_count
  from public.leads
  where status = 'closed_won'
  and id != new.id
  and (
    (new.email is not null and email = new.email)
    or (new.phone is not null and phone = new.phone)
    or (new.whatsapp is not null and whatsapp = new.whatsapp)
  );

  if prior_count > 0 then
    new.is_new_client := false;
  end if;

  return new;
end;
$$;

create trigger trg_leads_detect_repeat_client
  before insert on public.leads
  for each row execute function public.detect_repeat_client();
