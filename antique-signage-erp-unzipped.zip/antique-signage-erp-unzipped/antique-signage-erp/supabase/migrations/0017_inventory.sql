-- =========================================================
-- Phase 3 — Migration 0017
-- Inventory: raw materials stock tracking
-- =========================================================

create type inventory_category as enum (
  'acm_sheet', 'acrylic_sheet', 'stainless_steel', 'led_module',
  'power_supply', 'wire', 'packing_material', 'other'
);

create type inventory_transaction_type as enum ('in', 'out');

create table public.inventory_items (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  category inventory_category not null,
  unit text not null default 'pcs',
  current_stock numeric(12,2) not null default 0,
  low_stock_threshold numeric(12,2) not null default 5,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_inventory_items_category on public.inventory_items (category);

create trigger trg_inventory_items_updated_at before update on public.inventory_items
  for each row execute function public.set_updated_at();

create table public.inventory_transactions (
  id uuid primary key default uuid_generate_v4(),
  item_id uuid not null references public.inventory_items(id) on delete cascade,

  transaction_type inventory_transaction_type not null,
  quantity numeric(12,2) not null,

  project_id uuid references public.projects(id) on delete set null,
  notes text,

  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create index idx_inventory_transactions_item on public.inventory_transactions (item_id, created_at desc);
create index idx_inventory_transactions_project on public.inventory_transactions (project_id);

create or replace function public.apply_inventory_transaction()
returns trigger
language plpgsql
as $$
begin
  if new.transaction_type = 'in' then
    update public.inventory_items set current_stock = current_stock + new.quantity where id = new.item_id;
  else
    update public.inventory_items set current_stock = current_stock - new.quantity where id = new.item_id;
  end if;
  return new;
end;
$$;

create trigger trg_inventory_transactions_apply
  after insert on public.inventory_transactions
  for each row execute function public.apply_inventory_transaction();

create view public.inventory_low_stock
with (security_invoker = true)
as
select * from public.inventory_items where current_stock <= low_stock_threshold;

alter table public.inventory_items enable row level security;
alter table public.inventory_transactions enable row level security;

create policy inventory_items_select_authenticated
  on public.inventory_items for select
  using (auth.uid() is not null);

create policy inventory_items_write_scoped
  on public.inventory_items for all
  using (public.is_admin() or public.current_role() in ('production', 'packing'))
  with check (public.is_admin() or public.current_role() in ('production', 'packing'));

create policy inventory_transactions_select_authenticated
  on public.inventory_transactions for select
  using (auth.uid() is not null);

create policy inventory_transactions_write_scoped
  on public.inventory_transactions for insert
  with check (public.is_admin() or public.current_role() in ('production', 'packing'));

create policy inventory_transactions_delete_admin_only
  on public.inventory_transactions for delete
  using (public.is_admin());
