"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile } from "@/lib/auth";
import type { LeadSource } from "@/types/database";

export async function createLead(formData: FormData) {
  const profile = await getCurrentProfile();
  const supabase = createClient();

  const assignedTo = (formData.get("assigned_to") as string) || profile.id;

  const { data, error } = await supabase
    .from("leads")
    .insert({
      client_name: formData.get("client_name") as string,
      company_name: (formData.get("company_name") as string) || null,
      country: (formData.get("country") as string) || null,
      city: (formData.get("city") as string) || null,
      phone: (formData.get("phone") as string) || null,
      whatsapp: (formData.get("whatsapp") as string) || null,
      email: (formData.get("email") as string) || null,
      website: (formData.get("website") as string) || null,
      source: formData.get("source") as LeadSource,
      assigned_to: assignedTo,
      created_by: profile.id,
      follow_up_date: (formData.get("follow_up_date") as string) || null,
      expected_close_date: (formData.get("expected_close_date") as string) || null,
      notes: (formData.get("notes") as string) || null
    })
    .select()
    .single();

  if (error) {
    throw new Error(error.message);
  }

  revalidatePath("/leads");
  redirect(`/leads/${data.id}`);
}

export async function updateLeadStatus(leadId: string, status: string) {
  const supabase = createClient();
  const { error } = await supabase.from("leads").update({ status }).eq("id", leadId);
  if (error) throw new Error(error.message);
  revalidatePath(`/leads/${leadId}`);
  revalidatePath("/leads");
}

export async function addTimelineNote(leadId: string, note: string) {
  const profile = await getCurrentProfile();
  const supabase = createClient();
  const { error } = await supabase.from("lead_timeline").insert({
    lead_id: leadId,
    event_type: "note_added",
    title: "Note added",
    description: note,
    created_by: profile.id
  });
  if (error) throw new Error(error.message);
  revalidatePath(`/leads/${leadId}`);
}

export async function updateLeadFollowUp(leadId: string, followUpDate: string | null, nextAction: string) {
  const supabase = createClient();
  const { error } = await supabase
    .from("leads")
    .update({ follow_up_date: followUpDate, next_action: nextAction || null })
    .eq("id", leadId);
  if (error) throw new Error(error.message);
  revalidatePath(`/leads/${leadId}`);
}

export async function togglePhoneVisibility(leadId: string, visible: boolean) {
  const profile = await getCurrentProfile();
  if (profile.role !== "admin" && profile.role !== "owner") {
    throw new Error("Only Admin can control phone number visibility.");
  }
  const supabase = createClient();
  const { error } = await supabase
    .from("leads")
    .update({ phone_visible_to_assignee: visible })
    .eq("id", leadId);
  if (error) throw new Error(error.message);
  revalidatePath(`/leads/${leadId}`);
}

export interface ImportedLeadRow {
  client_name: string;
  company_name?: string;
  country?: string;
  city?: string;
  phone?: string;
  whatsapp?: string;
  email?: string;
  source?: string;
  notes?: string;
}

export async function bulkImportLeads(rows: ImportedLeadRow[], assignedTo: string | null) {
  const profile = await getCurrentProfile();
  const supabase = createClient();

  const validSources = [
    "whatsapp", "facebook_ads", "google_ads", "instagram", "website", "referral"
  ];

  const payload = rows
    .filter((r) => r.client_name && r.client_name.trim())
    .map((r) => ({
      client_name: r.client_name.trim(),
      company_name: r.company_name?.trim() || null,
      country: r.country?.trim() || null,
      city: r.city?.trim() || null,
      phone: r.phone?.trim() || null,
      whatsapp: r.whatsapp?.trim() || null,
      email: r.email?.trim() || null,
      source: validSources.includes((r.source ?? "").toLowerCase().replace(/\s+/g, "_"))
        ? (r.source ?? "").toLowerCase().replace(/\s+/g, "_")
        : "whatsapp",
      notes: r.notes?.trim() || null,
      assigned_to: assignedTo || profile.id,
      created_by: profile.id
    }));

  if (payload.length === 0) {
    throw new Error("No valid rows to import (client_name is required on every row).");
  }

  const { error, count } = await supabase.from("leads").insert(payload).select("id", { count: "exact" });
  if (error) throw new Error(error.message);

  revalidatePath("/leads");
  return { imported: count ?? payload.length };
}
