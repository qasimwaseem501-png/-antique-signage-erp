"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile } from "@/lib/auth";
import type { PaymentMethod, PaymentType } from "@/types/database";

export async function recordPayment(input: {
  project_id: string;
  payment_type: PaymentType;
  amount: number;
  payment_method: PaymentMethod;
  proof_storage_path: string | null;
  notes: string;
}) {
  const profile = await getCurrentProfile();
  const supabase = createClient();

  const { error } = await supabase.from("payments").insert({
    project_id: input.project_id,
    payment_type: input.payment_type,
    amount: input.amount,
    payment_method: input.payment_method,
    proof_storage_path: input.proof_storage_path,
    notes: input.notes || null,
    received_by: profile.id
  });

  if (error) throw new Error(error.message);

  revalidatePath(`/projects/${input.project_id}`);
  revalidatePath("/payments");
}
