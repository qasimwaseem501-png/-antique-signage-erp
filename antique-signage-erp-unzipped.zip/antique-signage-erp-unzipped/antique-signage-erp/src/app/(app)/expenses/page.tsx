import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import type { ProjectProfitSummary } from "@/types/database";

export default async function ExpensesPage() {
  const supabase = createClient();
  const { data } = await supabase
    .from("project_profit_summary")
    .select("*")
    .order("gross_profit", { ascending: false });

  const rows = (data ?? []) as ProjectProfitSummary[];

  const totalSales = rows.reduce((sum, r) => sum + r.sale_amount, 0);
  const totalCost = rows.reduce((sum, r) => sum + r.total_cost, 0);
  const totalProfit = totalSales - totalCost;

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Expenses &amp; Profit</h1>
        <p className="text-sm text-slate-500">Per-project cost breakdown and profitability</p>
      </div>

      <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="card p-5">
          <p className="text-sm text-slate-500">Total Sales</p>
          <p className="mt-1 text-xl font-bold text-slate-900">${totalSales.toLocaleString()}</p>
        </div>
        <div className="card p-5">
          <p className="text-sm text-slate-500">Total Costs</p>
          <p className="mt-1 text-xl font-bold text-slate-900">${totalCost.toLocaleString()}</p>
        </div>
        <div className="card p-5">
          <p className="text-sm text-slate-500">Gross Profit</p>
          <p className={`mt-1 text-xl font-bold ${totalProfit >= 0 ? "text-emerald-600" : "text-red-600"}`}>
            ${totalProfit.toLocaleString()}
          </p>
        </div>
      </div>

      <div className="card overflow-hidden overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase text-slate-500">
            <tr>
              <th className="px-4 py-3 font-medium">Project</th>
              <th className="px-4 py-3 font-medium">Sale Amount</th>
              <th className="px-4 py-3 font-medium">Total Cost</th>
              <th className="px-4 py-3 font-medium">Gross Profit</th>
              <th className="px-4 py-3 font-medium">Profit %</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((r) => (
              <tr key={r.project_id} className="hover:bg-slate-50">
                <td className="px-4 py-3">
                  <Link href={`/projects/${r.project_id}`} className="font-medium text-brand-blue-600 hover:underline">
                    {r.project_code}
                  </Link>
                  <p className="text-xs text-slate-500">{r.client_name}</p>
                </td>
                <td className="px-4 py-3 text-slate-600">${r.sale_amount.toLocaleString()}</td>
                <td className="px-4 py-3 text-slate-600">${r.total_cost.toLocaleString()}</td>
                <td className={`px-4 py-3 font-medium ${r.gross_profit >= 0 ? "text-emerald-600" : "text-red-600"}`}>
                  ${r.gross_profit.toLocaleString()}
                </td>
                <td className="px-4 py-3 text-slate-600">{r.profit_percentage}%</td>
              </tr>
            ))}
          </tbody>
        </table>
        {rows.length === 0 && (
          <div className="p-10 text-center text-sm text-slate-500">No project cost data yet.</div>
        )}
      </div>
    </div>
  );
}
