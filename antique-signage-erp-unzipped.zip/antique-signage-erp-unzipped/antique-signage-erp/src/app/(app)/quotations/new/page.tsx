import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile } from "@/lib/auth";
import { QuotationForm } from "./QuotationForm";
import type { Lead } from "@/types/database";

export default async function NewQuotationPage() {
  const profile = await getCurrentProfile();
  const supabase = createClient();

  let query = supabase.from("leads").select("*").order("created_at", { ascending: false });
  if (!["owner", "admin"].includes(profile.role)) {
    query = query.eq("assigned_to", profile.id);
  }
  const { data } = await query;

  return (
    <div className="max-w-3xl">
      <h1 className="mb-6 text-2xl font-bold text-slate-900">New Quotation</h1>
      <QuotationForm leads={(data ?? []) as Lead[]} />
    </div>
  );
}
