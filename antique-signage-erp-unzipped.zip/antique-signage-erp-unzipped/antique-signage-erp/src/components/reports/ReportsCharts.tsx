"use client";

import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend
} from "recharts";

interface Props {
  countrySales: { country: string; total: number }[];
  salespersonSales: { name: string; total: number }[];
  salesVsAds: { month: string; sales: number; ads: number }[];
  pendingPayments: { project_id: string; project_code: string; client_name: string; balance_pending: number }[];
  totalPendingBalance: number;
  productionStatus: { stage: string; label: string; count: number }[];
  employeePerformance: { name: string; role: string; leadsWon: number; commissionEarned: number; tasksCompleted: number }[];
}

export function ReportsCharts({
  countrySales,
  salespersonSales,
  salesVsAds,
  pendingPayments,
  totalPendingBalance,
  productionStatus,
  employeePerformance
}: Props) {
  return (
    <div className="space-y-6">
      <div className="card p-6">
        <h2 className="mb-4 text-base font-semibold text-slate-900">Monthly Sales vs Ad Spend (Last 6 Months)</h2>
        <ResponsiveContainer width="100%" height={280}>
          <LineChart data={salesVsAds}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis dataKey="month" fontSize={12} />
            <YAxis fontSize={12} />
            <Tooltip formatter={(v) => `$${Number(v).toLocaleString()}`} />
            <Legend />
            <Line type="monotone" dataKey="sales" stroke="#0040e6" strokeWidth={2} name="Sales" />
            <Line type="monotone" dataKey="ads" stroke="#f97316" strokeWidth={2} name="Ad Spend" />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="card p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-base font-semibold text-slate-900">Pending Payments</h2>
          <span className="text-sm font-medium text-amber-600">Total: ${totalPendingBalance.toLocaleString()}</span>
        </div>
        {pendingPayments.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-slate-200 text-xs uppercase text-slate-500">
                <tr>
                  <th className="py-2">Project</th>
                  <th className="py-2">Client</th>
                  <th className="py-2">Balance Due</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {pendingPayments.map((p) => (
                  <tr key={p.project_id}>
                    <td className="py-2 font-medium text-slate-900">{p.project_code}</td>
                    <td className="py-2 text-slate-600">{p.client_name}</td>
                    <td className="py-2 font-medium text-amber-600">${p.balance_pending.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-sm text-slate-500">No pending balances — all caught up.</p>
        )}
      </div>

      <div className="card p-6">
        <h2 className="mb-4 text-base font-semibold text-slate-900">Production Status Breakdown</h2>
        {productionStatus.length > 0 ? (
          <div className="flex flex-wrap gap-3">
            {productionStatus.map((s) => (
              <div key={s.stage} className="rounded-lg border border-slate-200 px-3 py-2 text-sm">
                <span className="font-medium text-slate-900">{s.count}</span>
                <span className="ml-1.5 text-slate-500">{s.label}</span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-slate-500">No active projects yet.</p>
        )}
      </div>

      <div className="card p-6">
        <h2 className="mb-4 text-base font-semibold text-slate-900">Employee Performance</h2>
        {employeePerformance.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-slate-200 text-xs uppercase text-slate-500">
                <tr>
                  <th className="py-2">Employee</th>
                  <th className="py-2">Role</th>
                  <th className="py-2">Leads Won</th>
                  <th className="py-2">Commission Paid</th>
                  <th className="py-2">Tasks Completed</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {employeePerformance.map((e) => (
                  <tr key={e.name}>
                    <td className="py-2 font-medium text-slate-900">{e.name}</td>
                    <td className="py-2 capitalize text-slate-600">{e.role}</td>
                    <td className="py-2 text-slate-600">{e.leadsWon}</td>
                    <td className="py-2 text-slate-600">${e.commissionEarned.toLocaleString()}</td>
                    <td className="py-2 text-slate-600">{e.tasksCompleted}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-sm text-slate-500">No performance data yet.</p>
        )}
      </div>

      <div className="card p-6">
        <h2 className="mb-4 text-base font-semibold text-slate-900">Country-wise Sales</h2>
        {countrySales.length > 0 ? (
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={countrySales}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="country" fontSize={12} />
              <YAxis fontSize={12} />
              <Tooltip formatter={(v) => `$${Number(v).toLocaleString()}`} />
              <Bar dataKey="total" fill="#0040e6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <p className="text-sm text-slate-500">No sales data yet.</p>
        )}
      </div>

      <div className="card p-6">
        <h2 className="mb-4 text-base font-semibold text-slate-900">Salesperson-wise Sales</h2>
        {salespersonSales.length > 0 ? (
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={salespersonSales} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis type="number" fontSize={12} />
              <YAxis dataKey="name" type="category" width={120} fontSize={12} />
              <Tooltip formatter={(v) => `$${Number(v).toLocaleString()}`} />
              <Bar dataKey="total" fill="#22c55e" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <p className="text-sm text-slate-500">No sales data yet.</p>
        )}
      </div>
    </div>
  );
}
