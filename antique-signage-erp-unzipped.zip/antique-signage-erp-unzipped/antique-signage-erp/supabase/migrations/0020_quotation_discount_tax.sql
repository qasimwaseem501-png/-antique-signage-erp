-- =========================================================
-- Phase 4 — Migration 0020
-- Quotation discount/tax + lead status refinement
-- =========================================================

alter table public.quotations
  add column if not exists discount_percentage numeric(5,2) not null default 0,
  add column if not exists discount_amount numeric(12,2) not null default 0,
  add column if not exists tax_percentage numeric(5,2) not null default 0,
  add column if not exists tax_amount numeric(12,2) not null default 0;

alter type lead_status add value if not exists 'follow_up';

create or replace function public.recalc_quotation_totals()
returns trigger
language plpgsql
as $$
declare
  target_quotation_id uuid;
  new_subtotal numeric(12,2);
  q record;
  discount numeric(12,2);
  taxable numeric(12,2);
  tax numeric(12,2);
begin
  target_quotation_id := coalesce(new.quotation_id, old.quotation_id);

  select coalesce(sum(line_total), 0) into new_subtotal
  from public.quotation_items
  where quotation_id = target_quotation_id;

  select * into q from public.quotations where id = target_quotation_id;

  discount := round(new_subtotal * coalesce(q.discount_percentage, 0) / 100.0, 2);
  if q.discount_amount > 0 then
    discount := q.discount_amount;
  end if;

  taxable := new_subtotal - discount;
  tax := round(taxable * coalesce(q.tax_percentage, 0) / 100.0, 2);

  update public.quotations
  set subtotal = new_subtotal,
      discount_amount = discount,
      tax_amount = tax,
      total_amount = taxable + tax + coalesce(q.shipping_cost, 0)
  where id = target_quotation_id;

  return coalesce(new, old);
end;
$$;

create or replace function public.recalc_quotation_totals_on_self_change()
returns trigger
language plpgsql
as $$
declare
  new_subtotal numeric(12,2);
  discount numeric(12,2);
  taxable numeric(12,2);
  tax numeric(12,2);
begin
  select coalesce(sum(line_total), 0) into new_subtotal
  from public.quotation_items
  where quotation_id = new.id;

  discount := round(new_subtotal * coalesce(new.discount_percentage, 0) / 100.0, 2);
  if new.discount_amount > 0 and new.discount_amount is distinct from old.discount_amount then
    discount := new.discount_amount;
  end if;

  taxable := new_subtotal - discount;
  tax := round(taxable * coalesce(new.tax_percentage, 0) / 100.0, 2);

  new.subtotal := new_subtotal;
  new.discount_amount := discount;
  new.tax_amount := tax;
  new.total_amount := taxable + tax + coalesce(new.shipping_cost, 0);

  return new;
end;
$$;

create trigger trg_recalc_quotation_totals_on_update
  before update of discount_percentage, discount_amount, tax_percentage, shipping_cost on public.quotations
  for each row execute function public.recalc_quotation_totals_on_self_change();
