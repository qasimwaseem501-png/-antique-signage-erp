"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile } from "@/lib/auth";

export async function createTask(formData: FormData) {
  const profile = await getCurrentProfile();
  const supabase = createClient();

  const { data, error } = await supabase
    .from("tasks")
    .insert({
      title: formData.get("title") as string,
      description: (formData.get("description") as string) || null,
      project_id: (formData.get("project_id") as string) || null,
      assigned_to: (formData.get("assigned_to") as string) || null,
      priority: formData.get("priority") as string,
      due_date: (formData.get("due_date") as string) || null,
      created_by: profile.id
    })
    .select()
    .single();

  if (error) throw new Error(error.message);

  revalidatePath("/tasks");
  redirect(`/tasks/${data.id}`);
}

export async function updateTaskStatus(taskId: string, status: string) {
  const supabase = createClient();
  const { error } = await supabase.from("tasks").update({ status }).eq("id", taskId);
  if (error) throw new Error(error.message);
  revalidatePath(`/tasks/${taskId}`);
  revalidatePath("/tasks");
}

export async function addTaskComment(taskId: string, comment: string) {
  const profile = await getCurrentProfile();
  const supabase = createClient();
  const { error } = await supabase.from("task_comments").insert({
    task_id: taskId,
    comment,
    created_by: profile.id
  });
  if (error) throw new Error(error.message);
  revalidatePath(`/tasks/${taskId}`);
}
