import { redirect } from "next/navigation";
import { getCurrentProfile, isAdmin } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { ShippingRatesEditor } from "@/components/shipping/ShippingRatesEditor";
import { IntegrationRow } from "@/components/settings/IntegrationRow";
import type { ShippingRate, IntegrationConfig } from "@/types/database";

export default async function SettingsPage() {
  const profile = await getCurrentProfile();
  if (!isAdmin(profile)) redirect("/dashboard");

  const supabase = createClient();
  const { data: ratesData } = await supabase.from("shipping_rates").select("*").order("country");
  const rates = (ratesData ?? []) as ShippingRate[];

  const { data: integrationsData } = await supabase.from("integrations_config").select("*").order("display_name");
  const integrations = (integrationsData ?? []) as IntegrationConfig[];

  return (
    <div className="max-w-2xl">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Settings</h1>
        <p className="text-sm text-slate-500">Company information and system configuration</p>
      </div>

      <div className="card mb-6 p-6">
        <h2 className="mb-3 text-sm font-semibold text-slate-900">Company Information</h2>
        <dl className="space-y-2 text-sm">
          <div className="flex justify-between">
            <dt className="text-slate-500">Company Name</dt>
            <dd className="font-medium text-slate-900">Antique Signage &amp; Advertising</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-slate-500">Website</dt>
            <dd className="font-medium text-slate-900">antiquesignage.com</dd>
          </div>
        </dl>
      </div>

      <div className="card mb-6 p-6">
        <h2 className="mb-3 text-sm font-semibold text-slate-900">Commission Tiers</h2>
        <p className="mb-3 text-sm text-slate-500">Applied automatically when a lead is marked Closed Won.</p>
        <table className="w-full text-left text-sm">
          <thead className="text-xs uppercase text-slate-400">
            <tr>
              <th className="pb-2">Sale Amount</th>
              <th className="pb-2">Commission</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            <tr><td className="py-2">Up to $1,000</td><td className="py-2 font-medium">$30</td></tr>
            <tr><td className="py-2">$1,001 – $3,000</td><td className="py-2 font-medium">$50</td></tr>
            <tr><td className="py-2">$3,001 – $5,000</td><td className="py-2 font-medium">$100</td></tr>
            <tr><td className="py-2">$5,001 – $7,000</td><td className="py-2 font-medium">$150</td></tr>
            <tr><td className="py-2">$7,000+</td><td className="py-2 font-medium">$200</td></tr>
          </tbody>
        </table>
        <p className="mt-3 text-xs text-slate-400">
          To change these tiers, edit the <code>calc_commission_tier()</code> function in the database
          (see migration 0007). Individual commissions can always be manually overridden on the Commissions page.
        </p>
      </div>

      <div className="card mb-6 p-6">
        <h2 className="mb-3 text-sm font-semibold text-slate-900">Shipping Rates by Country</h2>
        <p className="mb-3 text-sm text-slate-500">Used to auto-calculate shipping cost per shipment.</p>
        <ShippingRatesEditor rates={rates} />
      </div>

      <div className="card mb-6 p-6">
        <h2 className="mb-3 text-sm font-semibold text-slate-900">Integrations</h2>
        <p className="mb-3 text-sm text-slate-500">
          Placeholders for future automation. Keys are stored but not yet used by the app —
          wiring these up is a follow-up development task, not a config-only step.
        </p>
        <div className="space-y-2">
          {integrations.map((integration) => (
            <IntegrationRow key={integration.id} integration={integration} />
          ))}
        </div>
      </div>

      <div className="card p-6">
        <h2 className="mb-3 text-sm font-semibold text-slate-900">Client Phone Privacy</h2>
        <p className="text-sm text-slate-500">
          Phone number visibility is controlled per-lead. Open any lead and use the &quot;Visible / Hidden&quot;
          toggle next to Contact Details to control whether the assigned sales rep can see the client&apos;s
          phone/WhatsApp number.
        </p>
      </div>
    </div>
  );
}
