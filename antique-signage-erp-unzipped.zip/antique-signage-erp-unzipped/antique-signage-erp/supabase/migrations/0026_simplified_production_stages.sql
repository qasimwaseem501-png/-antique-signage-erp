-- =========================================================
-- Phase 5 — Migration 0026
-- Simplified production workflow: add 'acrylic_fabrication' and
-- 'assembly' stages. Existing stages are kept (additive) so no
-- historical project data is affected — the app now presents a
-- curated 10-stage flow for new stage selection while old values
-- remain valid and readable.
-- =========================================================

alter type project_stage add value if not exists 'acrylic_fabrication';
alter type project_stage add value if not exists 'assembly';

