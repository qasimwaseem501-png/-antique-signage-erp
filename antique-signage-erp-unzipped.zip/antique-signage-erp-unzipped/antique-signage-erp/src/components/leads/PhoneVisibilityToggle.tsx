"use client";

import { useTransition } from "react";
import { Eye, EyeOff } from "lucide-react";
import { togglePhoneVisibility } from "@/app/(app)/leads/actions";

export function PhoneVisibilityToggle({ leadId, visible }: { leadId: string; visible: boolean }) {
  const [isPending, startTransition] = useTransition();

  return (
    <button
      onClick={() => startTransition(() => togglePhoneVisibility(leadId, !visible))}
      disabled={isPending}
      title={visible ? "Visible to assigned sales rep — click to hide" : "Hidden from sales rep — click to show"}
      className="flex items-center gap-1 text-xs font-medium text-slate-500 hover:text-slate-900"
    >
      {visible ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}
      {visible ? "Visible" : "Hidden"}
    </button>
  );
}
