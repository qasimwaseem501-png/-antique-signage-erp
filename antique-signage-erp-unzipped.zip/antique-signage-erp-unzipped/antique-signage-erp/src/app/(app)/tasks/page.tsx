import Link from "next/link";
import { Plus } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile, isAdmin } from "@/lib/auth";
import { PriorityBadge, TaskStatusBadge } from "@/components/tasks/TaskBadges";
import type { Profile, Task } from "@/types/database";

export default async function TasksPage() {
  const profile = await getCurrentProfile();
  const admin = isAdmin(profile);
  const supabase = createClient();

  const { data } = await supabase.from("tasks").select("*").order("due_date", { ascending: true, nullsFirst: false });
  const tasks = (data ?? []) as Task[];

  const assigneeIds = Array.from(new Set(tasks.map((t) => t.assigned_to).filter(Boolean))) as string[];
  let assignees: Record<string, Profile> = {};
  if (assigneeIds.length > 0) {
    const { data: profilesData } = await supabase.from("profiles").select("*").in("id", assigneeIds);
    assignees = Object.fromEntries((profilesData ?? []).map((p) => [p.id, p as Profile]));
  }

  const today = new Date().toISOString().slice(0, 10);

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Tasks</h1>
          <p className="text-sm text-slate-500">{admin ? "All tasks" : "Your tasks"}</p>
        </div>
        <Link href="/tasks/new" className="btn-primary">
          <Plus className="h-4 w-4" />
          New Task
        </Link>
      </div>

      <div className="card overflow-hidden overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase text-slate-500">
            <tr>
              <th className="px-4 py-3 font-medium">Task</th>
              <th className="px-4 py-3 font-medium">Assigned To</th>
              <th className="px-4 py-3 font-medium">Priority</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Due Date</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {tasks.map((task) => {
              const overdue = task.due_date && task.due_date < today && task.status !== "done";
              return (
                <tr key={task.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3">
                    <Link href={`/tasks/${task.id}`} className="font-medium text-brand-blue-600 hover:underline">
                      {task.title}
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-slate-600">
                    {task.assigned_to ? assignees[task.assigned_to]?.full_name ?? "—" : "Unassigned"}
                  </td>
                  <td className="px-4 py-3"><PriorityBadge priority={task.priority} /></td>
                  <td className="px-4 py-3"><TaskStatusBadge status={task.status} /></td>
                  <td className={`px-4 py-3 ${overdue ? "font-medium text-red-600" : "text-slate-600"}`}>
                    {task.due_date ?? "—"} {overdue && "(Overdue)"}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {tasks.length === 0 && <div className="p-10 text-center text-sm text-slate-500">No tasks yet.</div>}
      </div>
    </div>
  );
}
