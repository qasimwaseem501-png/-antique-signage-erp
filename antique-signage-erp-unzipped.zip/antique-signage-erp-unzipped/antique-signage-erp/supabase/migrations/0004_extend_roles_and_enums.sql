-- =========================================================
-- Phase 2 — Migration 0004
-- Extend roles + lead source/status enums additively.
-- NOTE: We ADD new enum values rather than replacing the enums,
-- so existing Phase 1 data and code keep working unchanged.
-- Run each ALTER TYPE statement — they must each commit before
-- being referenced by later statements, which is why they are
-- grouped first in this file.
-- =========================================================

-- ---- Roles: add 'admin' (new standard name) and 'packing' ----
-- 'owner' is kept for backward compatibility; is_admin() treats
-- 'owner' and 'admin' as equivalent everywhere in the app.
alter type user_role add value if not exists 'admin';
alter type user_role add value if not exists 'packing';

-- ---- Lead source: add Phase 2 sources ----
alter type lead_source add value if not exists 'facebook_ads';
alter type lead_source add value if not exists 'instagram';

-- ---- Lead status: add Phase 2 pipeline stages ----
alter type lead_status add value if not exists 'quotation_sent';
alter type lead_status add value if not exists 'closed_won';
alter type lead_status add value if not exists 'closed_lost';
alter type lead_status add value if not exists 'repeat_client';
