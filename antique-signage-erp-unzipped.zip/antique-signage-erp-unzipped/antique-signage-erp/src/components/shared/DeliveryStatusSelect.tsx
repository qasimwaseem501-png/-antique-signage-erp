"use client";

import { useTransition } from "react";
import { updateDeliveryStatus } from "@/app/(app)/shipping/actions";

const OPTIONS = ["pending", "in_transit", "customs", "delivered", "delayed"];

export function DeliveryStatusSelect({ shipmentId, status }: { shipmentId: string; status: string }) {
  const [isPending, startTransition] = useTransition();

  return (
    <select
      className="input"
      value={status}
      disabled={isPending}
      onChange={(e) => startTransition(() => updateDeliveryStatus(shipmentId, e.target.value))}
    >
      {OPTIONS.map((opt) => (
        <option key={opt} value={opt}>
          {opt.replace("_", " ")}
        </option>
      ))}
    </select>
  );
}
